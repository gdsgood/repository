---
slug: timeline
title: 3R教室历史事件及时间线
authors: pincman
date: 2023-01-24
tags: [3R教室,TS全栈开发,远程工作,海外外包,自由职业,被动收入]
rf_summary: 这是3R教室的时间线，截止2023年1月24日止，这5个月我到底做了什么？<br />我所经历的一切也许你即将踏入，你所走过的路也许我正在走，让我们共勉!
---

:::success

我所经历的一切也许你即将踏入，你所走过的路也许我正在走，让我们共勉!

:::

import { TRTimeLine } from '@site/src/rowfish/components/timeline';

<TRTimeLine />