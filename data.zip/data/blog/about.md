---
slug: about
title: 关于站长
image: blog/about.png
authors: [pincman]
rf_type: image
rf_summary: 聊一聊生活,谈一谈技术,以及一个好的技术分享网站的诞生
banner: true
rf_noloop: true
rf_comment: false
rf_excerpt: false
rf_paginator: false
order: 1
---

[linux]: https://www.linux.org/
[docker]: https://www.docker.com/
[k8s]: https://kubernetes.io/
[cicd]: https://en.wikipedia.org/wiki/CI/CD
[typescript]: https://www.typescriptlang.org/
[vue]: https://vuejs.org/
[react]: https://reactjs.org/
[react native]: https://reactnative.dev/
[taro]: https://docs.taro.zone/
[node]: https://nodejs.org/
[rust]: https://www.rust-lang.org/
[nestjs]: https://nestjs.com/
[php]: https://www.php.net/
[laravel]: https://laravel.com/
[symfony]: https://symfony.com/
[mysql]: https://www.mysql.com/
[mongodb]: https://www.mongodb.com/
[redis]: https://redis.io/
[rabbitmq]: https://www.rabbitmq.com/
[golang]: https://go.dev/
[nextjs]: https://nextjs.org/
[tailwind]: https://tailwindcss.com/
[fastify]: https://www.fastify.io/
[yargs]: http://yargs.js.org/
[docusaurus]: https://docusaurus.io/
[gatsbyjs]: https://www.gatsbyjs.com/
[threejs]: https://threejs.org/
[spring boot]: https://spring.io/projects/spring-boot
[flutter]: https://flutter.dev/
[qq group]: https://qm.qq.com/cgi-bin/qm/qr?k=niCOKIcM6Zq1aUfqfmDZ1MpJJNAiDJ9p&jump_from=webapi
[qa]: https://v.3rcd.com/forum
[antd]: https://ant.design/index-cn
[arco]: https://arco.design/
[mui]: https://mui.com/zh/
[bootstrap]: https://getbootstrap.com/
[vite]: https://vitejs.dev/
[webpack]: https://webpack.js.org/
[react-dnd]: https://3rcd.com/docs/react-dnd/quick-start/Overview
[mobx]: https://mobx.js.org/README.html
[redux-toolkit]: https://redux-toolkit.js.org/
[zustand]: https://github.com/pmndrs/zustand
[react-router]: https://3rcd.com/docs/react-router/installation
[react-query]: https://react-query.tanstack.com/
[graphql]: https://graphql.org/
[typeorm]: https://typeorm.io/
[cluster]: https://nodejs.org/api/cluster.html
[pm2]: https://pm2.keymetrics.io/
[workerman]:https://www.workerman.net/
[wordpress]: https://cn.wordpress.org/
[recoil]: https://recoiljs.org/
[nuxtjs]:https://nuxtjs.org/
[jquery]:https://jquery.com/
[ci]:https://www.codeigniter.com/
[electron]:https://www.electronjs.org/
[rowfish]: /wiki/rowfish/
[toome]: https://3rcd.com/docs/toome/


:::info
一年多没更新，所以当前介绍看起来比较老，后续有时间更新以西。有项目需求请查看[3R工作室](/workroom)，需要购买会员请查看[3R教室](/classroom)
:::

:::success
我是[3R编码](https://3rcd.com)及[3R社区](https://3rku.com)的站长，也是**3r教室**与**3R工作室**的创始人
—— pincman，一名生活在江南水乡-南浔古镇的88年老码农！ 
:::

我热爱生活和Money，喜爱电影/乐器、昆曲/戏曲、文学/书法/绘画、历史/天文/神秘科学等一切有意思的东西<br />
曾经梦想成为一名文艺青年，但岁月逐渐把我变成了一名长期从事编码工作但又爱搞点营销和折腾的"江湖人"<br />
现在是一名不折不扣的"数字个体户"小微创业者，同时梦想成为一名终生编码者！

## 🙋‍♂️自我介绍

07 年开始接触的编程，一开始接触的是Delphi，开发过当年比较热门的远控软件。
后来从 08-16 年一直从事 PHP 的 Web 项目以及云计算方面的开发，期间主要使用 [Jquery][jquery]，[CI][ci]，[Laravel][laravel]，[Symfony][symfony]，[Bootstrap][bootstrap] 的技术。
17 年开始专注于 [Typescript][typescript] + [React][react] + [Node.js][node] + [Rust][rust] 的编码工作，目前正在学习 [Go][golang] 。

### 🐳网站平台

以下是站长经常去逛逛的网站

#### 🌘主要经营

 - 🌐 [3R编码](https://3rcd.com) 【自营】
 - 🌐 [3R酷](https://3rku.com) 【自营】
 - 🌐 [哔哩哔哩](https://space.bilibili.com/53679018)

#### 👀经常摸鱼

- 🌐 [谷歌](https://google.com)
- 🌐 [github](https://github.com/pincman)
- 🌐 [知乎](https://www.zhihu.com/people/pincman)
- 🌐 [掘金](https://juejin.cn/user/1046390798295816)
- 🌐 [oschina](https://my.oschina.net/pincman)
- 🌐 [youtube](https://www.youtube.com/channel/UCGKcPNULt-DtE_YDw3Ijp7Q)
- 🌐 [stackoverflow](https://stackoverflow.com/)
- 🌐 [思否](https://segmentfault.com/)
- 🌐 [豆瓣](https://douban.com)
- 🌐 [v2ex](https://v2ex.com)


### 🌈技术栈

以下只是展示一些站长个人熟悉或喜欢的技术栈，但是我们[3R工作室](/workroom)团队或者整个[3R教室](/classroom)擅长与各种技术栈甚至财务，营销等非技术性工作，所以我们可承接的项目和服务不仅限于以下技术栈。你把需求交给我们即可放心与安心（**不折腾**）！

#### 🔥主技术栈

- 运维全家桶： [Linux][linux]，[Docker][docker]，[K8S][k8s]，[CICD][cicd]，[Mysql][mysql]，[Mongodb][mongodb]，[Redis][redis]，[RabbitMQ][rabbitmq] 等
- CSS全家桶：[TailwindCSS][tailwind]，[Antd][antd]，[Arco Design][arco]，[Mui][mui]，[Bootstrap][bootstrap] 等
- React全家桶： [Vite][vite]，[Webpack][webpack]，[React][react]，[React Native][react native]，[React Router][react-router]，[React Query][react-query]，[React-DND][React-dnd]，[Mobx][mobx]，[Zustand][zustand]，[Nextjs][nextjs]，[Taro][taro]，[GraphQL][graphql] 等
- Node全家桶： [Electron][electron]，[Fastify][fastify]，[Nestjs][nestjs]，[Typeorm][typeorm]，[Yargs][yargs]，[Cluster][cluster]，[PM2][pm2] 等
- PHP全家桶： [PHP][php]，[Laravel][laravel]，[Symfony][symfony]，[Workerman][workerman]，[wordpress][wordpress] 等

#### 💫其它技能

- 比较熟悉（*也就是只能二开的*）：[Vue.js][vue]，[Nuxtjs][nuxtjs]
- 正在学习：[Golang][golang]
- 感兴趣：[Flutter][flutter]
- 同时也胜任：品牌形象设计，Logo 设计，原型设计，视频剪辑，电脑/手机组装修理等工作

#### 🛠️常用工具

 MacOS，VScode，Ecmas，PHPStorm，Sketch，OmniGraffle.Xmind，Navicat，Redis Manager，Typora，Obsidian，PicGo，Mweb，AI，PS，Final cut pro，Motion，PR，AE，Screenflow，Camtasia，Wordpress，Magento，Hexo，Docusaurus，NextCloud，Gitea，Drone，Oneinstack，Openstack，Discuz 等等


### 🔭关于接单

:::info
~~目前在职的是一份北美的TS全栈开发远程工作，业余时间从事知识付费和在线教学工作，同时也承接志趣相投，价格合理的外包项目~~<br />
目前我的3R教室的部分成员已组成有强大且专业的外包团队-[3R工作室][/workroom]，拥有你想要的各种技术栈开发者，并且有非常规范的接单，开发流程，详情请查看[3R工作室](/workroom)
:::

📣3R工作可以做的: 从产品的原型设计，形象设计，宣传视频，使用文档，到全平台（Macos，Windows，web，ssr，安卓，IOS，各类小程序）的编码开发，测试，构建部署，性能优化，SEO优化等


- 👉 本人接单不爱扯皮，价格和周期合适即可，442 付款
- 👉 客户发需求，客户或本人报价，确认合作后先付 4 成订金
- 👉 项目中期再付 4 成
- 👉 上线或交付源码后付尾款，第一年免费维护，第二年维护费另谈
- 👉 请自行制作原型设计稿或也可以由我推荐设计师(只负责推荐不负责参与设计)，没有设计稿或不愿意做设计稿的包不接


### 📱联系方式

由于站长长年为自己996工作中，为了防止恶意联系浪费时间，防止比如经常会出现加过来就说 **“我是某某大厂程序员，会XXX技术，有外包吗？”** 又或者 **“帮我我找份远程工作”** 等等这种抽象网友的骚扰，站长把微信号根据不同需求放在不同的页面了。
- 如需购买会员(加入3R俱乐部资源互通、学习TS全栈开发，学习远程自由职业等)可以通过[3R教室](/classroom)页面获取站长微信
- 如需招聘开发者或有外包项目找我们做请通过[3R工作室](/workroom)页面获取站长微信

同时，如果微信没有添加你，可能是你没有备注[已购买会员](/classroom),[外包需求](/workroom),[招聘需求](/workroom)等字样。
如果是这种情况，但是你确实已经支付会员费或者确实有外包需要我们团队开发或者有委托我们进行招聘开发者的需求，那么可以通过以下方式联系站长
:::warning
有时候站长生物钟比较紊乱没有及时添加微信的话，可以在[3R教室](/classroom)页面获取`@cloneable`的联系方式，先联系他
:::

- 💬电报号：`@pincman1988` (不保证一定在线)
- 📮邮箱: `pincman@qq.com` 或者 `pincman1988@gmail.com`

也欢迎通过**点击页面上的工具栏**关注我的社交账户哦！👏

## 🍵小站工作
因为 [TS][typescript]，[React][react]，[Node][node] 等技术体系在国内外都不是很卷，并且薪资也不错，使用范围广，语法友好等优点成为站长最爱的技术体系。所以本站以 [Linux][linux] + [Typescript][typescript] + [React][react] + [Node][node] + [服务器运维与CICD][cicd] 这个技术栈为主线来进行教学，成为这个技术栈中的一名布道者

以下 [Typescript][typescript] 或者说 [ES6+](https://es6.ruanyifeng.com/) 能做的事（几乎无所不能）：

-   🍋 使用 [Electron][electron] 可以直接开发桌面应用
-   🍋 使用 [React][react] + 各种UI库可以开发中后台
-   🍋 使用 [Nextjs][nextjs] + [Tailwind][tailwind] 可以开发任何类型的服务端渲染的网站
-   🍋 使用 [Taro][taro] 可以开发各种跨平台小程序
-   🍋 使用 [React Native][react native] 可以开发跨设备移动APP
-   🍋 使用 [Fastify][fastify] 可以开发轻量级API
-   🍋 使用 [Nestjs][nestjs] 可以开发高性能的企业级后端
-   🍋 使用 [Yargs][yargs] 可以构建命令工具
-   🍋 使用 [Docusaurus][docusaurus] 可以构建知识分享网站
-   🍋 使用 [Gatsbyjs][gatsbyjs] 可以构建企业官网
-   🍋 使用 [ThreeJS][threejs] 可以构建3D世界
-   🍋 还有 AI，嵌入式等等的库在日新月异的增加

最让人感到兴奋的是，这套全栈开发的技能国外基本属于主流，类似于国内的 [Spring Boot][spring boot] 和 [Vue][vue]，但是因为不内卷的缘故，远程工作非常好找，薪资也比较可观，**这个目前本人就在做**。并且除此外，国内企业目前招聘岗位也很多，竞争力却不大，也很好找工作。最有价值的是，因为全栈开发，所以甚至可以直接脱离 996 的地狱模式，成为一名真正的自由职业者或独立开发者😄。

同时，为了会员同学有一个更好的技术变现前景。除了[《TS全栈开发》](/classroom/courses/ts)站长还通过自己远程自由职业十几年的经验为基石，运营一个[《远程淘金训练营》](/classroom/courses/profit)，训练营长期更新一套直播教学的[《远程淘金课》](/classroom/courses/profit)。
此课程主要涉及
- 🍋 海外(以及国内)远程外包项目接单渠道拓展和客户洽谈方法
- 🍋 知识付费、应用/系统/作品等售卖、平台经营盈利等被动收入的推广和圈粉方案
- 🍋 远程工作求职指导及职业规划

当然站长认为 [React][react] + [Node][node] 全栈开发也是有一些不足的，但是一些瑕不掩瑜的不足可以忽略，比如 [React Native][react native] 性能对比 [Flutter][flutter] 会差一些等，这些问题是没多大影响的，没必要再去学个 Flutter，除非你自己有兴趣和空余时间。但是有一些还是比较致命的问题，比如 Node 在某些 CPU 密集型或者高并发处理时的表现实在差强人意，对于一些高要求应用显然无法达标，这时候你还可以自学一个简单但非常实用的编程语言 - [Go][golang]。
[Golang][golang] 作为对 [TS][typescript] 体系中 [Node][node] 后端的补足还是非常优秀的，尤其是在构建微服务和处理高性能需求方面很出色。

另外，学习TS全栈开发虽然天花板比较高，但这是个长期的过程。如果中间需要快速找一些技术变现的渠道，那么可以学习一下[wordpress][wordpress]、[strapi](https://strapi.io/)等，这些课程也在我们后续的计划之内。也可以先学习[《远程淘金课》](/classroom/courses/profit)，通过外包差价来实现一部分变现！

出于以上的所有原因，站长搭建了这个由 [Docusaurus][docusaurus] 编写的网站，用于分享和布道 [Linux][linux] + [Typescript][typescript] + [React][react] + [Node][node.js] + [服务器运维与CICD][cicd] 全栈开发的技能。

通过制作视频，编写文档，提供问答服务，开放工作室商业项目源码学习来开始 [3R教室](/classroom) 等全方位探讨与教学，为同学们节省宝贵的学习时间用于干你想干的事

希望大家多多关注本站，关注我的B站或知乎号，站长会很快的更新和制作新的教程，谢谢各位同学的支持。

By the way

*想搭建一个像小站一样的站点来吗？使用本站开发的 [RowFish][rowfish] 开源主题立即可架设一个属于你自己的小站，并可通过知识分享平台引流，通过知识付费或产品出售以及接单盈利！*



