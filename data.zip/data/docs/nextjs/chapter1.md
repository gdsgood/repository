---
title: Nextjs13+Eslint+Stylelint+TailwindCSS+shadcn/ui应用初始化
sidebar_label: Next13+shadcn/ui应用初始化
hide_title: true
sidebar_position: 1
---

# Nextjs13+Eslint+Stylelint+TailwindCSS+shadcn/ui应用初始化

:::caution
本节涉及到非常多的格式化配置,但是对开发应用实际助力不大,所以如果嫌麻烦.
请直接下载[classroom/template](https://git.3rcd.com/classroom/template)模板对着文档学习即可,**不建议手动去配置**
:::

## 创建应用

运行`pnpx create-next-app@latest --typescript  --eslint  --app  --src-dir --use-pnpm --import-alias "@/*"`创建一个nextjs应用

该命令创建的nextjs应用启用了typescript,eslint以及使用pnpm管理依赖。同时启用了`app`目录，并且使代码放在`src`目录下，并进行了路径映射

:::note

运行命令后，shell会卡住，这时可以填入你的应用名称，也就是创建的应用的目录名称

:::

**注意：此处不要启用tailwind，我们待会儿手动安装tailwind**

应用名称我们填入`nextapp`或其它你喜欢的名称

## 配置应用

### TSconfig

创建别名，使`@/*`指向`src/*`方便应用，我们对`tsconfig.json`稍作修改，如下

```json
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "baseUrl": ".",
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": [
    "next-env.d.ts",
    "typings/**/*.d.ts",
    "**/*.ts",
    "**/*.tsx",
    ".next/types/**/*.ts"
  ],
  "exclude": ["node_modules"]
}
```

为了让应用在源码之外支持根目录下的`.eslintrc.js`,`.pretterrc.js`等文件也能被格式化，新增一个`tsconfig.eslint.json`，这是专门用于给eslint使用的ts配置

如下

```json
{
    "extends": "./tsconfig.json",
    "include": [
        "next-env.d.ts",
        "typings/**/*.d.ts",
        "**/*.ts",
        "**/*.tsx",
        ".next/types/**/*.ts",
        "**.js",
        "**.ts"
    ],
    "exclude": ["node_modules"]
}
```

### Eslint配置

这部分更详细的内容请参考Vite章节，不再赘述

首先删除默认的`.eslintrc.json`，添加一个`.eslintrc.js`来配置

运行第三节中的命令安装依赖

在扩展配置部分相对vite多了个`plugin:@next/next/recommended`，另外规则有些许改变，从[此处](https://3rcd.com)查看详细代码

```javascript
module.exports = {
    parserOptions: {
        project: './tsconfig.eslint.json',
    },
    plugins: ['@typescript-eslint', 'prettier', 'unused-imports', 'prettier'],
    extends: [
        // airbnb规范
        // https://github.com/airbnb/javascript/tree/master/packages/eslint-config-airbnb
        'airbnb',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript',
        // react hooks的airbnb规范
        'airbnb/hooks',

        // typescript的eslint插件
        // https://github.com/typescript-eslint/typescript-eslint/blob/master/docs/getting-started/linting/README.md
        // https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/eslint-plugin
        'plugin:@typescript-eslint/recommended',
        'plugin:@typescript-eslint/recommended-requiring-type-checking',

        // nextjs配置
        // https://nextjs.org/docs/app/building-your-application/configuring/eslint#migrating-existing-config
        'plugin:@next/next/recommended',
        // 'next/core-web-vitals',
        // 使用prettier格式化代码
        // https://github.com/prettier/eslint-config-prettier#readme
        'prettier',
        // 整合typescript-eslint与prettier
        // https://github.com/prettier/eslint-plugin-prettier
        'plugin:prettier/recommended',
    ],
    rules: {
        /* ********************************** ES6+ ********************************** */
        'no-console': 0,
        'no-var-requires': 0,
        'no-restricted-syntax': 0,
        'no-continue': 0,
        'no-await-in-loop': 0,
        'no-return-await': 0,
        'no-multi-assign': 0,
        'no-param-reassign': [2, { props: false }],
        'max-classes-per-file': 0,
        'class-methods-use-this': 0,
        'guard-for-in': 0,
        'no-underscore-dangle': 0,
        'no-plusplus': 0,
        'no-lonely-if': 0,
        'no-bitwise': ['error', { allow: ['~'] }],

        /* ********************************** Module Import ********************************** */

        'import/prefer-default-export': 0,
        'import/no-cycle': 0,
        'import/no-dynamic-require': 0,
        'import/no-absolute-path': 0,
        'import/extensions': 0,

        // 一部分文件在导入devDependencies的依赖时不报错
        'import/no-extraneous-dependencies': [
            1,
            {
                devDependencies: [
                    '**/*.test.{ts,js}',
                    '**/*.spec.{ts,js}',
                    'build/**/*.{ts,js}',
                    'mock/**/*.{ts,js}',
                    '**.{ts,js}',
                ],
            },
        ],
        // 模块导入顺序规则
        'import/order': [
            1,
            {
                pathGroups: [
                    {
                        pattern: '@/**',
                        group: 'external',
                        position: 'after',
                    },
                ],
                'newlines-between': 'always-and-inside-groups',
                warnOnUnassignedImports: true,
            },
        ],
        // 自动删除未使用的导入
        // https://github.com/sweepline/eslint-plugin-unused-imports
        'no-unused-vars': 0,
        '@typescript-eslint/no-unused-vars': 0,
        'unused-imports/no-unused-imports': 1,
        'unused-imports/no-unused-vars': [
            'error',
            {
                vars: 'all',
                args: 'none',
                ignoreRestSiblings: true,
            },
        ],

        /* ********************************** Typescript ********************************** */
        '@typescript-eslint/no-empty-interface': 0,
        '@typescript-eslint/no-this-alias': 0,
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/no-use-before-define': 0,
        '@typescript-eslint/explicit-member-accessibility': 0,
        '@typescript-eslint/no-non-null-assertion': 0,
        '@typescript-eslint/no-unnecessary-type-assertion': 0,
        '@typescript-eslint/require-await': 0,
        '@typescript-eslint/no-for-in-array': 0,
        '@typescript-eslint/interface-name-prefix': 0,
        '@typescript-eslint/explicit-function-return-type': 0,
        '@typescript-eslint/no-explicit-any': 0,
        '@typescript-eslint/explicit-module-boundary-types': 0,
        '@typescript-eslint/no-floating-promises': 0,
        '@typescript-eslint/restrict-template-expressions': 0,
        '@typescript-eslint/no-unsafe-assignment': 0,
        '@typescript-eslint/no-unsafe-return': 0,
        '@typescript-eslint/no-unused-expressions': 0,
        '@typescript-eslint/no-misused-promises': 0,
        '@typescript-eslint/no-unsafe-member-access': 0,
        '@typescript-eslint/no-unsafe-call': 0,
        '@typescript-eslint/no-unsafe-argument': 0,

        /* ********************************** React and Hooks ********************************** */
        'react/jsx-uses-react': 1,
        'react/jsx-uses-vars': 1,
        'react/jsx-no-useless-fragment': 0,
        'react/display-name': 0,
        'react/button-has-type': 0,
        'react/prop-types': 0,
        'react/jsx-props-no-spreading': 0,
        'react/destructuring-assignment': 0,
        'react/static-property-placement': 0,
        'react/react-in-jsx-scope': 0,
        'react/require-default-props': 0,
        'react/jsx-filename-extension': [1, { extensions: ['.jsx', '.tsx'] }],
        'react/function-component-definition': 0,
        'react-hooks/exhaustive-deps': 0,

        /* ********************************** jax-a11y ********************************** */
        'jsx-a11y/anchor-is-valid': 0,
        'jsx-a11y/no-static-element-interactions': 0,
        'jsx-a11y/click-events-have-key-events': 0,
        'jsx-a11y/label-has-associated-control': [
            'error',
            {
                required: {
                    some: ['nesting', 'id'],
                },
            },
        ],
    },
};
```

添加`.prettierrc.js`，代码如下

```javascript
/** @format */
module.exports = {
  singleQuote: true,
  trailingComma: "all",
  printWidth: 100,
  proseWrap: "never",
  endOfLine: "auto",
  semi: true,
  tabWidth: 4,
  vueIndentScriptAndStyle: true,
  htmlWhitespaceSensitivity: "strict",
  overrides: [
    {
      files: ".prettierrc",
      options: {
        parser: "json",
      },
    },
    {
      files: "document.ejs",
      options: {
        parser: "html",
      },
    },
  ],
};
```

接着创建`.eslintignore`和`.prettierignore`文件，把需要eslint忽略而不需要格式化的文件放进去

这两个文件的内与react应用初始化那一节课是一样的，请自行参考

修改一下`package.json`中的lint命令改成如下

```json
"scripts": {
  ...
     "lint": "pnpm lint:es",
     "lint:es": "next lint --fix"
},
```

### Stylelint配置

这部分与[react课程的第一节](../react/chapter1.md)的方法一模一样请自行参考

安装依赖然后，复制这节课的`.stylelintrc.js`,`.stylelintignore`进去，修改一下lint命令

```json
  "scripts": {
        ...
        "lint": "pnpm lint:es && pnpm lint:style",
        "lint:es": "next lint --fix",
        "lint:style": "stylelint \"**/*.css\" --fix --cache --cache-location node_modules/.cache/stylelint/"
    },
```

### VSCode

这部分与react应用初始化这节课的方法一模一样请自行参考

复制这节课的`.vscode`目录进去就行了

## 样式与组件

请注意：在nextjs中使用css modules的方法与vite中并不完全一样，在nextjs中蛇形命名的类不会自动转换为驼峰形式，比如`.aaa-bbb`不会自动转化为`aaaBbb`

### Tailwind

tailwind的安装和配置方法与[react课程的第一节](../react/chapter1.md)的方法一样

**请注意**

- 因为前台我们没用到`antd`，所以不需要设置`preflight`
- 因为`tw-`前缀与shadcn/ui冲突，所以不要在`tailwind.config.js`中配置任何前缀**（不过此处我们先不要任何配置，后面等shadcn/ui初始化后再去配置，否则会被覆盖掉）**

现在除了配置一下`postcss.config.js`外，其它什么都不要做，等shadcn/ui初始化后再进行下一步

### shadcn/ui

[shadcn](https://ui.shadcn.com/)是一个整合[radix-ui](https://www.radix-ui.com/)和tailwind的组件库，样式比较舒服，组件也比较全，很适合做前台页面的开发

:::tip

如果感兴趣，也可以尝试一下更加漂亮的[nextui](https://nextui.org/)，如果你喜欢css-in-js，也可以使用更加流行的[mui](https://mui.com/)或更实用的[mantine](https://mantine.dev)

:::

首先，我们安装这个UI库

```bash
pnpx shadcn-ui@latest init
```

所有步骤都默认，最后，在`Write configuration to components.json`是输入`y`即可

接下来做以下操作

一、把`tailwind.config.js`配置换成以下内容，也可以根据你自己的需求进行修改

```javascript
/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: ['class'],
    content: ['./src/app/**/*.{ts,tsx}', './src/components/**/*.{ts,tsx}'],
    theme: {
        container: {
            center: true,
            padding: '2rem',
            screens: {
                xs: '480px',
                sm: '576px',
                md: '768px',
                lg: '992px',
                xl: '1200px',
                '2xl': '1400px',
            },
        },
        extend: {
            fontFamily: {
                standard: 'var(--font-family-standard)',
                firacode: 'var(--font-family-firacode)',
            },
            colors: {
                border: 'hsl(var(--border))',
                input: 'hsl(var(--input))',
                ring: 'hsl(var(--ring))',
                background: 'hsl(var(--background))',
                foreground: 'hsl(var(--foreground))',
                primary: {
                    DEFAULT: 'hsl(var(--primary))',
                    foreground: 'hsl(var(--primary-foreground))',
                },
                secondary: {
                    DEFAULT: 'hsl(var(--secondary))',
                    foreground: 'hsl(var(--secondary-foreground))',
                },
                destructive: {
                    DEFAULT: 'hsl(var(--destructive))',
                    foreground: 'hsl(var(--destructive-foreground))',
                },
                muted: {
                    DEFAULT: 'hsl(var(--muted))',
                    foreground: 'hsl(var(--muted-foreground))',
                },
                accent: {
                    DEFAULT: 'hsl(var(--accent))',
                    foreground: 'hsl(var(--accent-foreground))',
                },
                popover: {
                    DEFAULT: 'hsl(var(--popover))',
                    foreground: 'hsl(var(--popover-foreground))',
                },
                card: {
                    DEFAULT: 'hsl(var(--card))',
                    foreground: 'hsl(var(--card-foreground))',
                },
            },
            borderRadius: {
                lg: 'var(--radius)',
                md: 'calc(var(--radius) - 2px)',
                sm: 'calc(var(--radius) - 4px)',
            },
            keyframes: {
                'accordion-down': {
                    from: { height: 0 },
                    to: { height: 'var(--radix-accordion-content-height)' },
                },
                'accordion-up': {
                    from: { height: 'var(--radix-accordion-content-height)' },
                    to: { height: 0 },
                },
            },
            animation: {
                'accordion-down': 'accordion-down 0.2s ease-out',
                'accordion-up': 'accordion-up 0.2s ease-out',
            },
        },
    },
    plugins: [require('tailwindcss-animate')],
};
```

二、修改css文件

首先，初始化之后把[react课程的第一节](../react/chapter1.md)的`styles`目录复制到`src`目录下，然后在`src/app/layout.tsx`中替换`src/app/global.css`以导入

然后，把在`app/global.css`中生成的css变量复制到`src/styles/tailwind/base.css`中，然后就可以删除`app/global.css`,`src/app/global.css`文件和`app`目录了

:::caution

注意，初始化shadcn/ui时会自动生成一个app目录，这个目录里面的`global.css`的内容复制到`src/styles/tailwind/base.css`后必须删除，否则404错误

:::

如下

```css
/* src/styles/tailwind/base.css */

@layer base {
    html {
        font-family: var(--font-family-base);
        font-size: var(--font-size-base);
    }
}

@layer base {
    :root {
        --background: 0 0% 100%;
        --foreground: 222.2 84% 4.9%;
        --muted: 210 40% 96.1%;
        --muted-foreground: 215.4 16.3% 46.9%;
        --popover: 0 0% 100%;
        --popover-foreground: 222.2 84% 4.9%;
        --card: 0 0% 100%;
        --card-foreground: 222.2 84% 4.9%;
        --border: 214.3 31.8% 91.4%;
        --input: 214.3 31.8% 91.4%;
        --primary: 222.2 47.4% 11.2%;
        --primary-foreground: 210 40% 98%;
        --secondary: 210 40% 96.1%;
        --secondary-foreground: 222.2 47.4% 11.2%;
        --accent: 210 40% 96.1%;
        --accent-foreground: 222.2 47.4% 11.2%;
        --destructive: 0 84.2% 60.2%;
        --destructive-foreground: 210 40% 98%;
        --ring: 215 20.2% 65.1%;
        --radius: 0.5rem;
    }

    .dark {
        --background: 222.2 84% 4.9%;
        --foreground: 210 40% 98%;
        --muted: 217.2 32.6% 17.5%;
        --muted-foreground: 215 20.2% 65.1%;
        --popover: 222.2 84% 4.9%;
        --popover-foreground: 210 40% 98%;
        --card: 222.2 84% 4.9%;
        --card-foreground: 210 40% 98%;
        --border: 217.2 32.6% 17.5%;
        --input: 217.2 32.6% 17.5%;
        --primary: 210 40% 98%;
        --primary-foreground: 222.2 47.4% 11.2%;
        --secondary: 217.2 32.6% 17.5%;
        --secondary-foreground: 210 40% 98%;
        --accent: 217.2 32.6% 17.5%;
        --accent-foreground: 210 40% 98%;
        --destructive: 0 62.8% 30.6%;
        --destructive-foreground: 0 85.7% 97.3%;
        --ring: 217.2 32.6% 17.5%;
    }
}

@layer base {
    * {
        @apply border-border;
    }

    body {
        @apply bg-background text-foreground;
    }
}
```

修改`components.json`配置中的css路径，如下

```json
{
    "$schema": "https://ui.shadcn.com/schema.json",
    "style": "default",
    "rsc": true,
    "tsx": true,
    "tailwind": {
        "config": "tailwind.config.js",
        "css": "src/styles/index.css",
        "baseColor": "slate",
        "cssVariables": true
    },
    "aliases": {
        "components": "@/components",
        "utils": "@/lib/utils"
    }
}
```

对`src/styles/app.css`稍作修改，如下

```css
/* src/styles/app.css */
html,
body,
#app {
    @apply h-[100vh] w-full flex p-0 m-0;
}
```

在`layout.tsx`中导入

```tsx
// src/app/layout.tsx
import type { Metadata } from 'next';

import '@/styles/index.css';

export const metadata: Metadata = {
    title: '3rapp',
    description: '3r教室TS全栈课程',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en">
            <body>{children}</body>
        </html>
    );
}
```

修改`page.tsx`

```tsx
import { FC } from 'react';

import $styles from './page.module.css';

const App: FC = () => {
    return (
        <main id="app">
            <div className={$styles.container}>
                <div className={$styles.block}>
                    欢迎来到3R教室，这是<span>Nextjs课程的开始</span>
                </div>
            </div>
        </main>
    );
};
export default App;

```

修改`page.module.css`内容

```css
.container {
    @apply bg-yellow-300 flex flex-auto items-center justify-center;

    & > .block {
        @apply shadow-md p-5 bg-black text-center text-white text-lg;
    }
}
```

三、尝试

安装以下两个库

```bash
pnpm add clsx tailwind-merge
```

在此之前，由于`shadcn-ui`暂时不支持tw前缀，所以我们使用vscode的替换功能，把所有文件里的`tw-`替换掉

我们添加一个按钮组件测试一下

:::note

这个UI库要用到什么组件需要单独安装

:::

```bash
pnpm dlx shadcn-ui@latest add button
```

然后给button添加一个linkbutton组件，这样就拥有了一个可以添加链接的按钮组件

用以下代码替换最后一行，如果该文件报错，重启一下vscode即可

```tsx
// src/components/ui/button.tsx
export interface LinkProps
    extends React.AnchorHTMLAttributes<HTMLAnchorElement>,
        VariantProps<typeof buttonVariants> {
    asChild?: boolean;
}

const LinkButton = React.forwardRef<HTMLAnchorElement, LinkProps>(
    ({ className, variant, size, asChild = false, ...props }, ref) => {
        const Comp = asChild ? Slot : 'a';
        return (
            <Comp
                className={cn(buttonVariants({ variant, size, className }))}
                ref={ref as any}
                {...props}
            />
        );
    },
);

LinkButton.displayName = 'LinkButton';

export { Button, LinkButton, buttonVariants };
```

现在，我们在`App.tsx`中添加一个按钮来测试一下

```tsx
// src/App.tsx
import { FC } from 'react';

import { LinkButton } from '@/components/ui/button';

import $styles from './page.module.css';

const App: FC = () => {
    return (
        <main id="app">
            <div className={$styles.container}>
                <div className={$styles.block}>
                    欢迎来到3R教室，这是<span>Nextjs课程的开始</span>
                    <LinkButton variant="secondary" href="https://3rcd.com" target="_blank">
                        点此打开
                    </LinkButton>
                </div>
            </div>
        </main>
    );
};
export default App;
```

运行`pnpm dev`看一下效果

![](https://img.pincman.com/media/202308031906839.png)
