---
title: Nestjs+Eslint+SWC应用初始化及断点调试
sidebar_label: 应用初始化及调试
pagination_next: null
pagination_prev: null
sidebar_position: 1
---
# Nestjs+Eslint+SWC应用初始化及断点调试

:::warning
本节涉及到非常多的格式化配置,但是对开发应用实际助力不大,所以如果嫌麻烦.
请直接下载[课程仓库代码](https://git.3rcd.com/classroom/nestjs)(切换到`base`分支)对着文档学习即可,**不建议手动去配置**
:::

## 初始化
安装 [Nest CLI](https://docs.nestjs.com/cli/overview)

```shell
pnpm add @nestjs/cli -g
```

创建项目，我们命名为 `nestapp`

```shell
nest new nestapp
```

创建的时候选择pnpm

![](https://img.pincman.com/media/202309231521958.png)

进入到目录并升级所有包到最新版本

```shell
cd nestapp && pnpm up -latest
```

如果出现如下可选依赖爆出警告

![](https://img.pincman.com/media/202401190743711.png)

直接忽略即可，觉得难看就配置一下根目录下的`package.json`文件屏蔽掉

:::tip

后续"// ..." 代表一个省略未改动部分的代码

:::

```json
{
  "name": "nestapp",
  // ...
  "pnpm": {
    "peerDependencyRules": {
      "allowAny": [
        "reflect-metadata"
      ]
    }
  }
}
```

## tsconfig 配置

在**tsconfig.json**文件中添加 `ESNEXT` 就可以使用最新的 _ES_ 语法，并且添加一个 `@` 作为根目录映射符，并修改或添加一些其它的设置

:::caution

添加 `**.js`  是为了让 `.eslintrc.js`  之类的文件也能被格式化，但是必须要在  `tsconfig.build.json`  中排除

:::

```json
{
  "compilerOptions": {
    "strict": true,
    "alwaysStrict": true,
    "target": "esnext",
    "module": "commonjs",
    "moduleResolution": "Node",
    "declaration": true,
    "declarationMap": true,
    "removeComments": true,
    "emitDecoratorMetadata": true,
    "experimentalDecorators": true,
    "allowSyntheticDefaultImports": true,
    "sourceMap": true,
    "incremental": true,
    "skipLibCheck": true,
    "strictNullChecks": false,
    "noImplicitAny": true,
    "strictBindCallApply": false,
    "forceConsistentCasingInFileNames": true,
    "noFallthroughCasesInSwitch": false,
    "isolatedModules": true,
    "esModuleInterop": true,
    "noUnusedLocals": true,
    "noImplicitReturns": true,
    "pretty": true,
    "resolveJsonModule": true,
    "allowJs": true,
    "importsNotUsedAsValues": "remove",
    "noEmit": false,
    "lib": ["esnext", "DOM", "ScriptHost", "WebWorker"],
    "baseUrl": ".",
    "outDir": "./dist",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src", "test", "typings/**/*.d.ts", "**.js"]
}
```

配置 tsconfig.build.json

```json
{
    "extends": "./tsconfig.json",
    "exclude": ["node_modules", "test", "dist", "**/*spec.ts", "**.js"]
}
```

## 代码风格

### Eslint与Prettier

配置 [airbnb](https://github.com/airbnb/javascript) 的 ESLint 规则并整合 [Prettier](https://prettier.io/)，并且经过一定的客制化同时配合 VSCode 可达到完美的编码体验

```shell
pnpm add typescript \
eslint \
prettier \
@typescript-eslint/parser \
@typescript-eslint/eslint-plugin \
eslint-config-airbnb-base \
eslint-config-airbnb-typescript \
eslint-config-prettier \
eslint-plugin-import \
eslint-plugin-prettier \
eslint-plugin-unused-imports \
eslint-plugin-jest -D
```

修改`.eslintrc`以配置 `eslint` 

```javascript
// .eslintrc.js

module.exports = {
    parser: '@typescript-eslint/parser',
    parserOptions: {
        project: 'tsconfig.json',
        tsconfigRootDir: __dirname,
        ecmaVersion: 'latest',
        sourceType: 'module',
    },
    root: true,
    env: {
        node: true,
        jest: true,
    },
    plugins: ['@typescript-eslint', 'jest', 'prettier', 'import', 'unused-imports'],
    extends: [
        // airbnb规范
        // https://github.com/airbnb/javascript/tree/master/packages/eslint-config-airbnb
        'airbnb-base',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript/base',

        // typescript的eslint插件
        // https://github.com/typescript-eslint/typescript-eslint/blob/master/docs/getting-started/linting/README.md
        // https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/eslint-plugin
        'plugin:@typescript-eslint/recommended',
        'plugin:@typescript-eslint/recommended-requiring-type-checking',

        // 支持jest
        'plugin:jest/recommended',
        // 使用prettier格式化代码
        // https://github.com/prettier/eslint-config-prettier#readme
        'prettier',
        // 整合typescript-eslint与prettier
        // https://github.com/prettier/eslint-plugin-prettier
        'plugin:prettier/recommended',
    ],
    rules: {
        /* ********************************** ES6+ ********************************** */
        'no-console': 0,
        'no-var-requires': 0,
        'no-restricted-syntax': 0,
        'no-continue': 0,
        'no-await-in-loop': 0,
        'no-return-await': 0,
        'no-unused-vars': 0,
        'no-multi-assign': 0,
        'no-param-reassign': [2, { props: false }],
        'import/prefer-default-export': 0,
        'import/no-cycle': 0,
        'import/no-dynamic-require': 0,
        'max-classes-per-file': 0,
        'class-methods-use-this': 0,
        'guard-for-in': 0,
        'no-underscore-dangle': 0,
        'no-plusplus': 0,
        'no-lonely-if': 0,
        'no-bitwise': ['error', { allow: ['~'] }],

        /* ********************************** Module Import ********************************** */

        'import/no-absolute-path': 0,
        'import/extensions': 0,
        'import/no-named-default': 0,
        'no-restricted-exports': 0,

        // 一部分文件在导入devDependencies的依赖时不报错
        'import/no-extraneous-dependencies': [
            1,
            {
                devDependencies: [
                    '**/*.test.{ts,js}',
                    '**/*.spec.{ts,js}',
                    './test/**.{ts,js}',
                    './scripts/**/*.{ts,js}',
                ],
            },
        ],
        // 模块导入顺序规则
        'import/order': [
            1,
            {
                pathGroups: [
                    {
                        pattern: '@/**',
                        group: 'external',
                        position: 'after',
                    },
                ],
                alphabetize: { order: 'asc', caseInsensitive: false },
                'newlines-between': 'always-and-inside-groups',
                warnOnUnassignedImports: true,
            },
        ],
        // 自动删除未使用的导入
        // https://github.com/sweepline/eslint-plugin-unused-imports
        'unused-imports/no-unused-imports': 1,
        'unused-imports/no-unused-vars': [
            'error',
            {
                vars: 'all',
                args: 'none',
                ignoreRestSiblings: true,
            },
        ],
        /* ********************************** Typescript ********************************** */
        '@typescript-eslint/no-unused-vars': 0,
        '@typescript-eslint/no-empty-interface': 0,
        '@typescript-eslint/no-this-alias': 0,
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/no-use-before-define': 0,
        '@typescript-eslint/explicit-member-accessibility': 0,
        '@typescript-eslint/no-non-null-assertion': 0,
        '@typescript-eslint/no-unnecessary-type-assertion': 0,
        '@typescript-eslint/require-await': 0,
        '@typescript-eslint/no-for-in-array': 0,
        '@typescript-eslint/interface-name-prefix': 0,
        '@typescript-eslint/explicit-function-return-type': 0,
        '@typescript-eslint/no-explicit-any': 0,
        '@typescript-eslint/explicit-module-boundary-types': 0,
        '@typescript-eslint/no-floating-promises': 0,
        '@typescript-eslint/restrict-template-expressions': 0,
        '@typescript-eslint/no-unsafe-assignment': 0,
        '@typescript-eslint/no-unsafe-return': 0,
        '@typescript-eslint/no-unused-expressions': 0,
        '@typescript-eslint/no-misused-promises': 0,
        '@typescript-eslint/no-unsafe-member-access': 0,
        '@typescript-eslint/no-unsafe-call': 0,
        '@typescript-eslint/no-unsafe-argument': 0,
        '@typescript-eslint/ban-ts-comment': 0,
    },

    settings: {
        extensions: ['.ts', '.d.ts', '.cts', '.mts', '.js', '.cjs', 'mjs', '.json'],
    },
};

```

#### 一些重要的规则
`eslint-plugin-unused-imports` 用于自动删除未使用的导入

```javascript
 'no-unused-vars': 0,
 '@typescript-eslint/no-unused-vars': 0,
 'unused-imports/no-unused-imports': 1,
 'unused-imports/no-unused-vars': [
    'error',
    {
        vars: 'all',
        args: 'none',
        ignoreRestSiblings: true,
    },
]
```

`import` 插件，`import/order` 可以按照自己的需求配置

```javascript
'import/order': [
     'error',
     {
         pathGroups: [
             {
                 pattern: '@/**',
                 group: 'external',
                 position: 'after',
             },
         ],
         alphabetize: { order: 'asc', caseInsensitive: false },
         'newlines-between': 'always-and-inside-groups',
         warnOnUnassignedImports: true,
     },
],
```

在测试文件中导入的依赖不必一定要在 dependencies 的文件

```javascript
'import/no-extraneous-dependencies': [
    'error',
     {
         devDependencies: [
             '**/*.test.{ts,js}',
             '**/*.spec.{ts,js}',
             './test/**.{ts,js}',
         ],
     },
],
```

接下来需要配置一下 prettier,把`.prettierrc`重命名为`.prettierrc.js`，把内容设置成如下

```javascript
// .prettierrc.js

module.exports = {
  "singleQuote": true,
  "trailingComma": "all",
  "printWidth": 100,
  "proseWrap": "never",
  "endOfLine": "auto",
  "semi": true,
  "tabWidth": 4,
  "overrides": [
    {
      "files": ".prettierrc",
      "options": {
        "parser": "json"
      }
    }
  ]
}
```

并且把一些prettier和eslint需要忽略的目录和文件分别添加到 .eslintignore 和 .prettierignore，这样就可以避免一些不必要的文件被格式化

这两个文件的内容一样，如下

```json
dist
back
node_modules
pnpm-lock.yaml
docker
Dockerfile*
LICENSE
yarn-error.log
.history
.vscode
.docusaurus
.dockerignore
.DS_Store
.eslintignore
.editorconfig
.gitignore
.prettierignore
.eslintcache
*.lock
**/*.svg
**/*.md
**/*.svg
**/*.ejs
**/*.html
**/*.png
**/*.toml
```

现在运行`pnpm lint`即可格式化应用中的代码

### Vscode自动格式化

为了更方便的编写代码，我们配置一下vscode的自动格式化

对于 [Node.js](https://nodejs.org) 和 [TypeScript](https://www.typescriptlang.org/) 等前端技术最好的开发工具，毋庸置疑的就是 [VSCode](https://code.visualstudio.com/)。任何其它选项（包括 Vim、Emacs、Sublime Text、Atom、WebStorm 等等）都有这样那样的问题需要去耗费精力解决，所以建议直接使用 VSCode 进行开发

:::info

VSCode 已经自带同步配置和插件的功能，建议启用

:::

安装 [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) 插件和 [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode) 插件，可在 VSCode 插件中搜索并安装，或者使用如下命令安装

```shell
code --install-extension dbaeumer.vscode-eslint \
  && code --install-extension esbenp.prettier-vscode
```

按 `cmd + ,` 选择偏好设置 -> 工作区，配置 [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) 插件

```json
{
    // 使用eslint+prettier自动格式化
    "editor.formatOnSave": false,
    "editor.codeActionsOnSave": {
        "source.fixAll.eslint": true
    },
    // 导入模块时默认使用相对于项目的路径
    "javascript.preferences.importModuleSpecifier": "project-relative",
    // jsdoc注释时不带return
    "typescript.suggest.jsdoc.generateReturns": false,
    // 只启用项目范围的错误报告
    "typescript.tsserver.experimental.enableProjectDiagnostics": true,
    // 使用项目内部安装的ts的sdk
    "typescript.tsdk": "node_modules/typescript/lib",
    // 默认使用pnpm作为包安装的管理工具
    "npm.packageManager": "pnpm",
}
```

然后按`shift + cmd + p`（windows下使用`ctrl + shift + p`）,输入`reload`,选择重新加载窗口，打开源码按`cmd + s`即可在保存代码的时候自动格式化

![image-20230803001813525](https://img.pincman.com/media/202308030018009.png)

`app.e2e-spec.ts`可能会报错，可以点修复来避免报错

![](https://img.pincman.com/media/202309231528038.png)

## **开发与调试**

### 开发命令

运行`pnpm start`,用浏览器打开[http://localhost:3000](http://localhost:3000)可看到默认控制器输出的`Hello World!`

![image-20230726085852661](https://img.pincman.com/media/202307260858810.png)

但正常情况下我们需要热更新（即：修改代码后自动重启服务器）

这时候，我们需要运行`pnpm start:dev`，此命令也是我们在开发时用得最多的命令

在使用`pnpm start:dev`启动后，我们尝试在控制器中添加一行

![image-20230726090348990](https://img.pincman.com/media/202307260903112.png)

可以看到，服务器会自动热更新

![](https://img.pincman.com/media/202309231530164.png)

### 断点调试

对于有喜欢断点调试习惯的同学可以使用以下方法来进行断点调试开发，如不喜欢直接略过即可

按 `shift + cmd + d` 点"创建lanunch.json文件"，选择Node.js

![](https://img.pincman.com/media/202309231535358.png)

把以下配置替换到默认的`launch.json`

请注意，断点调试和 TDD、E2E 等测试的区别，断点调试只是在一些简单的情况下找出错误，并非测试。关于测试我们将会在后面的课程进行讲解

```json
{
    // 使用 IntelliSense 了解相关属性。
    // 悬停以查看现有属性的描述。
    // 欲了解更多信息，请访问: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "name": "debug 3rapp",
            "request": "launch",
            "runtimeArgs": ["run-script", "start:debug"],
            "autoAttachChildProcesses": true,
            "console": "integratedTerminal",
            "runtimeExecutable": "pnpm",
            "skipFiles": ["<node_internals>/**"],
            "type": "node"
        }
    ]
}
```

打好断点

![](https://img.pincman.com/media/202309231537226.png)

按`F5`，用浏览器打开[http://localhost:3000](http://localhost:3000)，就可以进行调试，可以看到浏览器会卡在那边，并且输出`Hello ! I'm pincman`，直到你按下一步

![](https://img.pincman.com/media/202309231539358.png)

### 使用SWC

为了在开发环境下提高代码热更新的速度，我们可以使用[swc](https://swc.rs/)替代默认的tsc作为编译器来开发和编译

首先，安装以下依赖

```bash
pnpm add @swc/cli @swc/core -D
```

然后修改`nest-cli.json`

```json
{
    "$schema": "https://json.schemastore.org/nest-cli",
    "collection": "@nestjs/schematics",
    "sourceRoot": "src",
    "compilerOptions": {
        "deleteOutDir": true,
        "builder": "swc",
        "typeCheck": true
    }
}
```

再次运行`pnpm start:dev`，然后尝试改动`src/app.controller.ts`中的随意一行代码。比如注释掉`console.log('welcome to')`，就可以看到下图这样热更新速度明显比默认的TSC快，这证明`swc`已经配置成功

![](https://img.pincman.com/media/202309231541321.png)

