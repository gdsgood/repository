---
sidebar_label: Node.js环境搭建
title: Node.js开发环境搭建
pagination_next: null
pagination_prev: null
sidebar_position: 1
---

## 前置操作

:::warning

注意：课程中的Linux系统永远指代windows下的wsl2或者独立的Linux发行版两者,而不仅仅只是独立Linux

:::

课程代码的运行环境与本手册的启动环境是一致的,所以在启动本文档时相信你已经配置好基本环境.如还没有配置好,请查看[3R教室手册的文档部分](https://3rcd.com/classroom/guide#文档)

## ZSH

使用ZSH可以更好的体验命令的乐趣

一、安装并切换到zsh

:::info

mac下已自带zsh，无需安装，此处仅用于linux

:::

```bash
touch ~/.hushlogin  # 禁止欢迎消息
apt-get install -y zsh # 如果是arch或者radhat系的发行版，请自行用pacman/yay或者yum替代
```

使用以下命令切换到zsh

```bash
chsh -s /bin/zsh # 切换
```

关闭命令窗口并重新打开(如果是远程服务器的Linux系统开发则需要先`exit`退出再ssh连接)，可以看到命令行有变化了

二、安装ohmyzsh

如果没有安装`wget`, 先安装一下wget

:::info

Mac下请使用`brew install wget`

:::

```bash
apt-get install -y wget
```

使用以下命令安装ohmyzsh

:::info

如果是没有梯子，可以使用镜像代替：`sh -c "$(wget -O- https://gitee.com/mirrors3r/ohmyzsh/raw/master/tools/install.sh)"`

:::

```bash
sh -c "$(wget -O- https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
```

![image-20230804210443167](https://img.pincman.com/media/202308042104414.png)

三、安装power10k

使用以下命令安装

```bash
git clone --depth=1 https://github.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k
```

如果是国内服务器可以用镜像

```bash
git clone --depth=1 https://gitee.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k
```

在`.zshrc`中设置主题为`powerlevel10k/powerlevel10k`

![image-20230804210135158](https://img.pincman.com/media/202308042101884.png)

运行`source ~/.zshrc`加载配置，然后根据自己的喜好来配置`p10k`

如果下次需要重新配置，只要运行`p10k configure`即可

![image-20230804210708714](https://img.pincman.com/media/202308042107161.png)

四、设置插件

- `autojump`可以使用`j xxx`来跳转到历史目录
- `extract`可以用`x`命令一键解压
- `zsh-autosuggestions`用于命令行自动补全
- `zsh-syntax-highlighting`用于命令代码高亮

```bash
apt-get install -y autojump extract
git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
# 国内服务器可以使用镜像：git clone https://gitee.com/mirrors3r/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
# 国内服务器可以使用镜像：git clone https://gitee.com/mirrors3r/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
```

在`.zshrc`中设置插件为`git autojump extract zsh-autosuggestions zsh-syntax-highlighting`

![](https://img.pincman.com/media/202308042131836.png)

## Node.js

安装与配置 [Node.js](https://nodejs.org/) 环境
建议：我们所有TS课程统一使用 [pnpm](https://pnpm.io/) 作为包管理器（Windows 的同学在学习期间可以使用 Yarn）

### 安装 Node.js

有关开发环境，由于 Windows 对 Node.js 的开发支持并不友好，所以只推荐 Linux (windows下使用[WSL2](https://learn.microsoft.com/zh-cn/windows/wsl/install)亦可获得非常好的用户体验) 与 Macos 作为开发环境。
如果你不想折腾或者想得到一个体验最好，最完美的TS全栈开发环境，MacOS将是不二选择

#### MacOS 中安装

```shell
brew install nodejs
```

#### Linux 中安装

:::info

此处的node版本，可根据情况，自己从 nodejs.org 选择对应的版本，并在下方命令的基础上进行更改

:::

```shell
# 下载并解压node
sudo wget https://nodejs.org/dist/v18.16.0/node-v18.16.0-linux-x64.tar.xz -O /usr/local/src/node18.tar.xz
sudo tar -xf /usr/local/src/node18.tar.xz -C /usr/local/
sudo mv /usr/local/node-v18.16.0-linux-x64 /usr/local/node
# 添加到环境变量
echo "export PATH=/usr/local/node/bin:\$PATH" >> ~/.zshrc && source ~/.zshrc
```

### 配置npm

设置全局库的存放目录，用于防止权限问题

```shell
npm config set prefix $HOME/.node_modules
echo "export PATH=$HOME/.node_modules/bin:\$PATH" >> ~/.zshrc && source ~/.zshrc
```

配置 [npm](https://www.npmjs.com/) 淘宝镜像

```shell
npm config set registry https://registry.npmmirror.com/
```

### 安装与配置pnpm

一、安装 [pnpm](https://pnpm.io/) 以及初始化 pnpm

```shell
npm install -g pnpm
pnpm setup 
```

二、加载pnpm的环境变量

```bash
source ~/.zshrc
```

三、安装源管理工具

```shell
pnpm add nnrm -g
```

四、选择一个国内镜像

```shell
nnrm use taobao
```

### Node版本管理

使用pnpm可直接管理多个Node版本

```shell
# 使用最新版
pnpm env use --global latest
# 使用长期支持版
pnpm env use --global lts
```

另外，如果没有梯子，那么可以使用传统的版本管理工具，比如 [n](https://github.com/tj/n) 或者 [nvm](https://github.com/nvm-sh/nvm)

```shell
pnpm add n -g 
```

为避免权限问题，请执行如下命令

:::warning

因为我们使用普通用户权限进行编程，所以把 n 的目录通过环境变量改成我们可以操作的目录

:::

```bash
echo "\n" >> ~/.zshrc
echo "export N_NODE_MIRROR=https://npmmirror.com/mirrors/node" >> ~/.zshrc
echo "export N_PREFIX=\$HOME/.n" >> ~/.zshrc
echo "export PATH=\$N_PREFIX/bin:\$PATH" >> ~/.zshrc
source ~/.zshrc
```

切换版本的方法如下

```bash
# 安装最新的长期支持版
n lts_latest && node --version
# 切换回最新版
n latest && node --version
```

