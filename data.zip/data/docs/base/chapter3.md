---
sidebar_label: TS基本语法
title: TS基本语法
hide_table_of_contents: true
pagination_next: null
pagination_prev: null
sidebar_position: 3
---

在学习TS全栈开发之前，建议先花少量时间过一遍TS的基础语法。推荐一下几个基础教程，我们选取一两个学习即可！

- 原TS基础课程（包含视频）由`@许竣皓` 同学无偿提供并长期维护更新。目前地址已迁移至他的博客中，请查看[Typescript基础](https://doc.happy-learning.cn/ts/typescript%E5%9F%BA%E7%A1%80/)栏目学习。本文档不再更新！
- [TS入门教程](https://ts.xcatliu.com/)是一套非常好的TS基础语法教程，也是站长的TS入门教程。这套教程是免费的，可以学习一下
- [阮一峰TS教程](https://wangdoc.com/typescript/)是基础变成教学大神"阮一峰"写的TS教程，也非常不错，值得学习