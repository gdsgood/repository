---
sidebar_label: 食用指南
title: 3R教室使用手册
hide_title: true
pagination_next: null
pagination_prev: null
sidebar_position: 1
---

# 食用指南

## 👨‍💻说明
3R教室课程及服务的使用说明已搬迁至[官网](https://3rcd.com)的[3R手册](https://3rcd.com/classroom/guide)，本文档目前仅作为课程文档学习使用

请先按[3R手册](https://3rcd.com/classroom/guide)的流程操作，然后使用本文档开始您的3R之旅吧！

## 🌱课程概览

:::info

本处是课程文档，关于课程的视频(目前仅掘金课有视频)资料获取、学习方法和流程、问答等等一切信息请查看[3R手册](https://3rcd.com/classroom/guide)

:::

3R教室的课程分为五种类型，我们会不断地增加新课

- 基础类型：主要是一些开发环境搭建，基础语法等内容
- 后端类型：包含Node(Nestjs)，.Net/PHP，命令工具构建，爬虫等后端相关技术栈的实战开发
- 前端类型：包含React,Nextjs,React Native,Electron等前端或客户端相关的技术栈的实战开发
- 综合类型：主要包含运维，部署，monorepo等应用组织代码设计，wordpress建站与主题开发等杂项技能
- 运营类型：数字游民，远程工作求职，外包接单渠道与方法，被动收入等实现相关的《远程掘金课》等综合性知识

站长将来会不断地新增更多的好课程给大家！

## 📝知识点

因为学习3R的TS全栈课程，相信您必定已经了解了JS/TS,React以及Node的优势与劣势。正如你所想的，优势是，使用这些技术的供求比很低，也就是职位需求量大，但开发者远远没有达到市场需求的饱和状态，不仅仅是海外远程，国内使用的企业也在快速增多。这与php和.net(仅国内)岗位稀缺的情况或者java岗位虽多如牛毛，但求职者是其岗位的好几倍的情况不同，应该说好得多。但是劣势是生态真的差到极点，nestjs是其中唯一可以看得过去的，那么你要做的就是只能慢慢的打磨nestjs，把他打磨的像其他语言的框架一样顺手。而不是只学习一下官网的基本使用方法，这对接单海外项目和求职远程工作帮助并不大，所以需要投入大量的精力和时间来磨平学习曲线，加油！

我们目前的课程结构大体是这样的：

1. 《Nestjs后端开发实战》课程是先简单地做一个文章管理系统的API
2. 然后就开始构建一个非常好用的弹性可扩展架构和CLI命令这些(这是由于nestjs等一众node.js框架并不像spring boot,laravel或是rails那样是非常成熟的成品框架，他是把各种库通过模块整合的方式集合起来的，这部分对于前端开发者来说稍难，对于后端开发者来说基本没难度，无非就是反射+封装)
3. 接着不断地给这个架构上追加Auth，短信邮件发送，实时通讯，动态权限，流式文件下载等功能来实现一个强大可扩展的Headless CMS（即无头CMS）的API
4. 《React18中后台开发实战》课程则负责为这个强大的CMS框架开发一个完美的管理后台，手动复刻Antd,vben等常用后台面板的优秀功能
5. 《Nextjs全栈开发实战》课程开发一个Nextjs+Primsa的网站来实现一个比较Fushion的现代化Nextjs网站
6. 最后，我们在掌握Nestjs，React，Nextjs这些技能后，可以自行尝试编写电商网站等各种应用（当然在此之前强烈建议学习一下我们的商业外包项目的源码，方法请查看[3R手册](https://3rcd.com/classroom/guide)）
7. 《应用优化与运维实战》主要讲解如何构建前后端一体同构的monorepo应用结构，服务器运维部署，CICD等，不仅让你成为一名工作的开发者，也为成长为一名独立开发者或者自由职业者铺平技术壁垒
8. 而《远程掘金》课是在学习技术课的同时或学习之后，帮助同学们可以更好地利用技术变现，使用学习TS全栈技能来获取更多money，因为学以致用才是最重要的！

## 📚课程目录

本课程带领大家从零基础入门开始，使用Typescript开发一个完整可扩展的无头CMS框架以及一个全栈的Nextjs网站
Nestjs以及React两套课开发的CMS系统框架室一个灵活的Headless CMS，你可以在此之上构建纯展示型的企业网站，社区网站甚至大型电商社交网络等等
当前课程所涉及的内容包括：

- SSR 响应式网站开发
- 中后台管理系统开发
- 后端API开发
- CLI命令行工具开发
- 自动化构建/部署/运维(即CI/CD)
- 使用全栈开发技能赚钱获利
- ...

:::tip
后续我们会添加更多课程，比如 PHP Laravel开发后端，Electron跨平台桌面应用开发，Wordpress建站与主题制作等，敬请期待！
:::

你可以在学习我们课程的同时学习以下相关资料

- Redis,Rabbitmq,Websocket等工具的基础概念，这些在[菜鸟教程](https://www.runoob.com/)上直接搜索就行【后端相关课程】
- [JWT](https://www.ruanyifeng.com/blog/2018/07/json_web_token-tutorial.html)以及[OAuth2.0](https://www.ruanyifeng.com/blog/2014/05/oauth_2_0.html)【所有技术课程】
- [html5与css3手册](https://www.w3cschool.cn/html5css3/)【前端相关课程】

本课程涉及的各个主技术栈版本号

- Node.js: **v20** 
- Nestjs: **v10** 
- React: **v18** 
- Nextjs: **v13**

### 🐣TS基础入门

Node.js与Nestjs开发环境搭建和一些用的基础语法

:::info

代码仓库：[classroom/ts-base](https://git.3rcd.com/classroom/ts-base)

:::

1. [Node.js开发环境搭建](./base/chapter1.md)
2. [Nestjs+Eslint+SWC应用初始化及断点调试](./base/chapter2.md)
3. [TS基本语法](./nestjs/chapter3.md)
4. [装饰器与反射](./nestjs/chapter4.md)


### 🥷Nestjs最佳实践

Nestjs后端API开发及Node.js CLI工具构建等

:::tip
主要涉及: Node.js/Typeorm/Nestjs/Yargs/Fastify/BullMQ/Passport.js/CASL/Redis等
:::

:::info

代码仓库：[classroom/nestjs](https://git.3rcd.com/classroom/nestjs)

:::

![](https://img.pincman.com/media/202307190238072.png)

1. 『基础知识』[Nestjs核心概念](./nestjs/chapter1.md) 【`base`分支】
2. 『内容模块』[Nestjs整合Typeorm实现基本的CRUD操作及分页数据查询](./nestjs/chapter2.md) 【`content`分支】
3. 『内容模块』[请求数据的验证和响应数据的序列化](./nestjs/chapter3.md)
4. 『内容模块』[数据关联与树形嵌套结构的分类和评论的实现](./nestjs/chapter4.md)
5. 『内容模块』[自定义全局的验证管道，拦截器和过滤器](./nestjs/chapter5.md)
6. 『内容模块』[自定义数据验证约束及约束中的依赖注入](./nestjs/chapter6.md)
7. 『内容模块』[批量操作及软删除(回收站)功能使用](./nestjs/chapter7.md)
8. 『内容模块』[使用Mysql,MeilliSearch,ElasticSearch等多种方式实现全文搜索](./nestjs/chapter8.md)
9. 『核心框架』[实现一个CRUD框架以抽象化代码](./nestjs/chapter9.md) 【`framework`分支】
10. 『核心框架』[自建配置系统实现](./nestjs/chapter10.md)
11. 『核心框架』[嵌套路由与Swagger文档实现](./nestjs/chapter11.md)
12. 『CLI工具』[使用Yargs构建命令行工具](./nestjs/chapter12.md) 【`cli`分支】
13. 『CLI工具』[生产环境下静默启动以及PM2 API的使用](./nestjs/chapter13.md) (【兴趣课】[整合bun与pm2实现开发环境与生产环境免编译和自启](./nestjs/chapter13-2.md)）
14. 『CLI工具』[数据迁移功能的实现](./nestjs/chapter14.md)
15. 『CLI工具』[数据填充命令及数据工厂的实现](./nestjs/chapter15.md)
16. 『用户与权限』[用户模块开发以及使用Passport实现JWT认证和无痛刷新](./nestjs/chapter16.md) 【`auth`分支】
17. 『用户与权限』[基于CASL的RBAC动态角色及权限模块实现](./nestjs/chapter17.md)
18. 『用户与权限』数据表动态关联及内容作者
19. 『用户与权限』使用OAuth2实现Github等第三方登录
20. 『文件模块』Fastify驱动下的文件上传下载导出及图片流式加载实现等功能的实现
21. 『文件模块』图片的自动剪裁及压缩实现实现
22. 『云服务』整合腾讯云SDK实现文件的云存储
23. 『云服务』用户注册,登录,找回密码绑定邮箱和手机号等验证功能实现
24. 『高级功能』使用Redis+BullMQ实现基于消息队列的异步短信及邮件验证
25. 『高级功能』websocket实现即时聊天及消息离线存储功能
26. 『高级功能』系统安装包工具开发
27. 『高级功能』整合Log4j2实现日志功能
28. 『运维与测试』Nestjs应用的缓存与性能优化
29. 『性能与运维』使用Jest编写TDD测试以及E2E测试编写

### 🥥React18最佳实践

React18中后台开发

:::tip
主要涉及: Vite/React/TailWindCSS/Antd/Zustand/React Router/websockets等等
:::

:::info

代码仓库：[classroom/react](https://git.3rcd.com/classroom/react)，本课程代码已有基本完整版，查看仓库[classroom/monoapp](https://git.3rcd.com/classroom/monoapp)的`apps/admin`目录

:::

![](https://img.pincman.com/media/202307190242905.png)

1. [Vite+React18+Eslint+Stylelint+TailwindCSS+Antd应用初始化](./react/chapter1.md)
2. [TailwindCSS使用详解](./react/chapter2.md)
3. [常用React Hooks使用详解](./react/chapter3.md)
4. Zustand与Immer的使用以及持久化存储封装（示例: 使用Zustand实现动态暗黑主题，动态皮肤与国际化等配置组件）
5. React Router v6.4+的使用详解
6. Svg组件与基于Ionify的图标组件的封装
7. 多种雪碧加载动画的实现
8. React Router封装及懒加载与Loadding的实现
9. 路由菜单与布局的初步实现
10. 应用右拉设置抽屉实现
11. KeepAlive组件与多标签功能开发
12. 顶栏和左栏布局及响应式移动布局实现
13. 左栏双菜单嵌入式布局实现
14. 使用Axios+Swr.js编写数据加载组件
15. Mock数据服务器实现
16. i18n国际化实现
17. 用户登录页面编写
18. 动态权限路由和菜单实现
19. 面包屑功能实现
20. 使用Antd Charts实现可视化仪表盘
21. React-DND拖动库的使用详解
22. Pro components的表单与表格使用详解
23. 整合Nestjs实文章管理
24. 整合Nestjs实现树形分类，评论管理
25. 整合Nestjs实现用户设置
26. 整合Nestjs实现云接口等系统设置
27. 整合Nestjs实现用户管理
28. 整合Nestjs实现复杂的动态字段权限管理
29. Vitest测试编写

### 🥝Nextjs全栈实践

Nextjs前后端同构网站的全栈开发实战

:::tip
主要涉及: Nextjs/radix-ui/React Spring/websockets/Prisma/Drizzle/Vercel等等
:::

:::info

代码仓库：[classroom/nextjs](https://git.3rcd.com/classroom/nextjs)

:::

1. [Nextjs13+Eslint+Stylelint+TailwindCSS+shadcn/ui应用初始化](./nextjs/chapter1.md)
2. 正在制定中...

### 🚀应用优化与运维实战

:::tip
主要涉及: Monorepo应用构建/Linux服务器与PHP应用搭建/Node和前端应用的CICD自动构建部署等等【本课已完结】
:::

:::note

代码仓库：[classroom/monoapp](https://git.3rcd.com/classroom/monoapp)

:::

1. [无懈可击的Linux服务器构建](./optimization/chapter1.md)
2. [Turborepo+Nestjs+React18+Nextjs13构建monorepo脚手架](./optimization/chapter2.md)
3. [使用Gitea+Drone+PM2自建CICD平台 - 实现自动化运维与部署](./optimization/chapter3.md)
4. Cluster均衡负载及Fork进程详解（本节将在nestjs课更新完成后再制作）

### 💰远程掘金

:::tip
本课程为纯视频课程,录制视频请自行通过网盘（网盘获取方法在[3R手册](https://3rcd.com/classroom/guide)中）获取,并且请尽量参加直播与实践活动
:::

为了帮助同学们使用手上的技术换取更多的报酬和利益，我们特别开展这个课程
以站长十几年的自由职业和创业经验为基石，以3R教室的优秀资源为辅助，帮助更多的同学实现`free`。同时我们会不断地在增加新的创意和提供更多的市场信息
另外，在这个课程上，我们每周会邀请3R会员中的嘉宾来直播课堂，分享他们的经验和经历
目前嘉宾有以下类型的同学

- 拥有高学历和来自大厂的3R会员，对大厂求职有一手资料
- 有来自海外的3R会员，分享欧美澳等海外市场的最新讯息
- 自由职业者或创业者，比如独立开发者或社区营运者等分享被动收入经验，长期接单者可以分享客户渠道拓展经验

由于是期刊直播的课程，所以没有具体的内容，大概涉及到的知识面如下
1. 自由职业与数字游民概念详解
2. 应用软件的订阅制销售渠道和被动收入实践
3. 网课的制作与推广方法详解
4. 海外接单渠道发掘与客户谈判技巧
5. 经营性社区与平台盈利实现
6. 远程工作求职方法与准备

另外，我们还提供了一对一技术变现和职业生涯规划服务，具体查看[3R手册](https://3rcd.com/classroom/guide)

## 🍶后续

### 🦔待上线

- laravel全栈开发实战
- wordpress建站实战
- Electron桌面应用开发实战

### 🐳可能上线

- Flutter/React Native
- .NET

### 🐣彩蛋

对于以下会员同学，您将有机会获取我们的订制礼品作为专属奖励哦！

- 为了尽可能地让同学们少用微信群，多使用QQ和论坛，所以在QQ或者论坛（尤其是论坛发帖）发言比较多的会员我们会提供奖励
- 对于课程的代码BUG或文档提供大量建设性建议的同学
- 提供给3R工作室外包项目或提供给其他会员同学就业机会
- 求职TS相关的远程工作或坐班岗位成功
- 自己通过学习我们的《远程掘金》课，自己成功接单或实现被动收入等（在3R工作室接到单除外）
- ...

![3011691505513_.pic](https://img.pincman.com/media/202308082239417.jpg)

![](https://img.pincman.com/media/202308082240130.jpg)

### 

## 🪡广告

3R提供以下有偿服务

- 3R教室提供外包开发服务，我们提供平价但高质量的外包开发服务，有需要可以联系站长`pincman`
- 如果有购买海外云主机的需求可以访问[这里](https://3rku.com/d/82)，我们有合作方提供廉价高性能无需备案的海外服务器，并且有`5折折扣`
- 如果有广告需求可以联系站长，我们将会在"课程文档、全论坛、QQ群、微信群、飞机、Discord等置顶，论坛会左侧栏会加上图片"，售价为`6k/月`（500多位高质量收费会员+20多位高价外包客户和付费招聘方）
- ~如果有移民需求可以联系站长，我们拥有多家移民合作机构提供服务，目前可提供"芬兰"等北欧诸国（`80w`左右学签，`100w`左右工签），“澳洲”(`120w`左右，只提供学签)两个地区的移民~（本服务已取消合作,如果有需要请自行联系,站长会推微信）

## 🪐合伙人

:::note

暂无多余股份可售卖，谢谢关注！

:::

~~3R教室本身永久没有多余股份出让。目前只有`@pluta`同学有`1%`出让（其他股东不出让）。有需要联系`@pincman`购买即可，价格`13.5w`，谢谢！~~