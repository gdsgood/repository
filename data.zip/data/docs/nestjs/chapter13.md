---
title: 生产环境下静默启动以及PM2 API的使用
sidebar_label: PM2与静默启动
hide_title: true
sidebar_position: 15
---

## 前置工作

### 预先阅读

在学习本节课之前你需要阅读以下文档
- [pm2文档](https://pm2.keymetrics.io/docs/usage/pm2-api/)

### 依赖解析

`pm2`是一个在生产环境下运行后台静默运行node或者其他应用的工具

```bash
pnpm add pm2
```

## 命令编写

目前，在生产环境下我们有以下几种方式启动应用

1. 使用`pnpm start:prod`命令启动应用，其实就是运行`node ./dist/main.js`
2. 如果我们没有把源码部署在服务器上，而只是部署了编译后的`dist`，然后把`package.json`复制到`dist`里这种模式部署的话，是直接运行`node ./main.js`来跑应用
3. 但是以上两种方式只能像开发环境一样跑单个进程且跑起来后卡在那边无法静默运行。一般这种情况，我们无需自己fork进程去编写一个静默运行工具，而是直接使用pm2
4. 要不就是写个`docker-compose.yml`，然后就和mysql,nginx这些一起跑在docker里面。这样也可以，不过不在本课讨论范围之内

pm2不仅实现了静默运行与进程管理，还可以快速的切换`fork`或是`cluster`模式。但是按以上第三种方式的方法来，那么，我们必须要在服务器上为每个应用单独写一个pm2配置，这就显得比较麻烦。所以，我们写一个直接使用应用本身就能启动pm2的命令，这样会更加方便部署

### 类型

添加以下几个类型

- `Pm2Arguments`: 命令参数
- `Pm2Option`: 命令处理选项（排除了几个pm2默认的`StartOptions`类型中的几个属性，因为这些属性我们在应用配置里添加）
- `AppConfig`: 添加一些常用的自定义pm2配置

:::tip

值得注意的是，pm2启动后应用的名称是与应用配置里的名称相同的，所以无须重新配置

:::

```typescript
// src/modules/core/commands/types.ts
export type Pm2Arguments = {
    /**
     * 应用入口文件，默认为dist/main.js
     */
    entry?: string;

    /**
     * 是否监控,所有环境都可以使用(但在非PM2启动的生产环境下此选项无效)
     */
    watch?: boolean;

    /**
     * 是否重启应用(PM2进程)
     */
    restart?: boolean;

    /**
     * 是否执行额外命令
     */
    args?: string[];
};

/**
 * PM2配置
 */
export type Pm2Option = Pick<Pm2Arguments, 'watch' | 'args'> &
    Omit<StartOptions, 'name' | 'cwd' | 'script' | 'args' | 'interpreter' | 'watch'>;


// src/modules/core/types.ts
/**
 * 应用配置
 */
export interface AppConfig {
    // ...

    /**
     * PM2配置
     */
    pm2?: Omit<StartOptions, 'name' | 'cwd' | 'script' | 'args' | 'interpreter' | 'watch'>;
}
```

### 配置

首先，在默认应用配置中添加一下pm2的配置（其实什么也不用加）

```typescript
// src/modules/core/config.ts
/**
 * 默认应用配置
 * @param configure
 */
export const getDefaultAppConfig = (configure: Configure) => ({
    // ...
    pm2: {},
});
```

然后添加一些自定义配置

```typescript
// src/config/app.config.ts
export const app = createAppConfig((configure) => ({
    // ...
    pm2: {
        exec_mode: 'cluster',
    },
}));
```

### 命令

编写一个yargs命令模块

:::tip

别忘了在`index.ts`中导出

:::

- `entry`: 指定启动的入口文件（相对应用执行的根目录，而不是绝对路径）
- `restart`: 重启应用，如果应用的进程不存在则自动启动应用
- `watch`: 是否开启监控模式
- `args`: 可以加一些课外的启动参数（课程中没用到）

```typescript
// src/modules/core/commands/pm2.command.ts
export const createPm2Command: CommandItem<any, Pm2Arguments> = async (app) => ({
    command: ['pm2'],
    describe: 'Start app in prod by pm2',
    builder: {
        entry: {
            type: 'string',
            alias: 'e',
            describe: 'The path of the script to run.',
            default: 'dist/main.js',
        },
        restart: {
            type: 'boolean',
            alias: 'r',
            describe: 'Retart app, pm2 will auto run start if process not exists.',
            default: false,
        },
        watch: {
            type: 'boolean',
            alias: 'w',
            describe: 'Run in watch mode (live-reload).',
            default: false,
        },
        args: {
            type: 'array',
            alias: 'a',
            describe: 'A string or array of strings composed of arguments to pass to the script.',
            default: [],
        },
    },
    handler: async (args: Arguments<Pm2Arguments>) => {
        const { configure } = app;
        pm2Handler(configure, args);
    },
});
```

### 处理器

先编写一个获取pm2配置的函数

1. 先判断入口文件是否存在，不存在则报错
2. 设置默认配置`defaultConfig`：通过一些固定的选项以及从命令行中传入的选项(`option`参数)得出
3. 再用在`app.config.ts`中的自定义pm2配置覆盖合并默认配置以获取最终配置

```typescript
// src/modules/core/commands/pm2.handler.ts
export const getPm2Config = async (
    configure: Configure,
    option: Pm2Option,
    script: string,
): Promise<StartOptions> => {
    if (!existsSync(join(cwdPath, script)))
        panic(chalk.red(`entry script file '${join(cwdPath, script)}' not exists!`));
    const { name, pm2: customConfig = {} } = await configure.get<AppConfig>('app');
    const defaultConfig: StartOptions = {
        name,
        cwd: cwdPath,
        script,
        args: option.args,
        autorestart: true,
        watch: option.watch,
        ignore_watch: ['node_modules'],
        env: process.env,
        exec_mode: 'fork',
    };
    return deepMerge(
        defaultConfig,
        omit(customConfig, ['name', 'cwd', 'script', 'args', 'watch', 'interpreter']),
        'replace',
    );
};
```

处理器函数的逻辑为

:::info 

`cwdPath`代表应用执行的根目录

:::

1. 获取应用名称作为pm2进程
2. 尝试连接pm2，连接失败则报错退出命令进程
3. 连接成功后，根据命令行中是否输入`--restart`或`-r`来确定是启动应用还是重启应用
4. 如果是启动应用，那么尝试启动。启动失败则报错并退出进程，启动成功则断开pm2连接，这时，应用已经静默启动了
5. 如果是重启应用，那么先尝试重启。如果重启成功则断开pm2连接，启动失败则证明应用可能还没有启动，所以会自动尝试启动，也就是重复**步骤2**

```typescript
/**
 * 执行路径(应用根目录)
 */
const cwdPath = resolve(__dirname, '../../../..');

/**
 * PM2静默应用启动处理器
 * @param configure
 * @param args
 */
export const pm2Handler = async (configure: Configure, args: Arguments<Pm2Arguments>) => {
    const { name } = await configure.get<AppConfig>('app');
    const pm2Config = await getPm2Config(configure, pick(args, ['args', 'watch']), args.entry);
    const connectCallback = (error?: any) => {
        if (!isNil(error)) {
            console.error(error);
            process.exit(2);
        }
    };
    const startCallback = (error?: any) => {
        if (!isNil(error)) {
            console.error(error);
            exit(1);
        }
        pm2.disconnect();
    };
    const restartCallback = (error?: any) => {
        if (!isNil(error)) {
            pm2.start(pm2Config, (serr) => startCallback(serr));
        } else {
            pm2.disconnect();
        }
    };

    pm2.connect((cerr) => {
        connectCallback(cerr);
        args.restart
            ? pm2.restart(name, restartCallback)
            : pm2.start(pm2Config, (serr) => startCallback(serr));
    });
};
```

## 使用命令

### 启动应用

需要先编译一下应用，因为pm2是启动编译后的文件

```bash
pnpm build
```

接下来，我们先全局安装一个pm2

```bash
pnpm i -g pm2
```

现在我们把pm2命令加入`package.json`的`scripts`中

```json
   "scripts": {
         "cli": "bun --bun src/console/bin.ts",
        "dev": "pnpm start:dev",
        "prod": "pnpm start:prod",
        "build": "cross-env NODE_ENV=production nest build",
        "pm2": "cross-env NODE_ENV=production pnpm cli pm2",
        // ...
    },
```

运行命令，使用pm2启动应用，并开启监控

```bash
pnpm cli pm2 -w
```

然后查看pm2进程列表，看一下应用是否正常启动

```bash
pm2 ls
```

![](https://img.pincman.com/media/202401290701351.png)

访问[localhost:3100/api/docs](http://localhost:3100/api/docs)，应用正常显示

![](https://img.pincman.com/media/202401290702757.png)

### 删除应用

如果你有兴趣还可以利用[pm2](https://pm2.keymetrics.io/docs/usage/pm2-api/)自行写一些停止应用，删除应用等应用管理的命令。但是，一般情况下，直接使用全局的pm2进行管理即可

:::tip

后续站长时间和精力而定，如果有时间站长就会把这些命令全部写进去。更多pm2的命令请查看其[官方文档](https://pm2.keymetrics.io/docs/usage/quick-start/)

:::

在本地开发环境下，我们不需要启动pm2应用，所以查看到能正常启动后删除pm2进程即可

:::info

应用名称通过pm2 ls查看，可以是自动生成的随机应用名或者你自行在app.config.ts中配置的固定应用名

:::

```bash
pm2 delete NomcqhSli # 把NomcqhSli换成你的应用名称
```

![](https://img.pincman.com/media/202401290708272.png)