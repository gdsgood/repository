---
title: 使用Yargs构建命令行工具
sidebar_label: 使用Yargs构建命令行工具
hide_title: true
sidebar_position: 14
---
## 前置工作

### 预先阅读

在学习本节课之前你需要阅读以下文档

- [yargs官网文档](http://yargs.js.org/docs/)或[3R教室的yargs翻译](https://3rcd.com/wiki/yargs/example)(版本较老，建议尽量看官网英文原版)
- [Bun在TS中的基本使用](https://bun.sh/docs/typescript)

### 依赖解析

- `yargs`是一个构建命令行的工具
- `cross-env`用于跨平台指定环境变量
- `bun`是一个高性能的新型node解析器，能直接快速运行`.ts`源码(在生产环境中亦适用，但只适用于mac,linux等*nix系统)
- `ts-node`是一个**在开发环境**下直接运行`.ts`源码的工具(因为大量吃资源，无法在生产环境中使用，只适用于win平台用于作为替代bun的方案)

如果你是纯windows(非wsl2)下学习本课程，安装以下依赖

:::danger

非常不建议，热更新会超级慢

:::

```bash
pnpm add ts-node -D
```

如果你在*nix(mac,linux,wsl2等)下学习本课程，安装以下依赖

```bash
pnpm add bun
```

其他通用的依赖如下

```bash
pnpm add yargs
pnpm add cross-env @types/yargs bun-types -D
```

## 类型

首先，我们把这节课的所有类型先编写好，这样后续写功能就会比较流畅了

### 命令选项

因为在命令中需要启动一个nestjs实例，对于一些即时运行的命令，比如数据迁移等，需要在运行后退出进程。否则，虽然就算实例关闭了，命令窗口还会卡在那边，因为进程没有结束掉

所以，除了继承yargs默认的`CommandModule`**命令模块**选项外，还需要添加一个`instant`用于设置瞬时命令

```typescript
// src/modules/core/types.ts
export interface CommandOption<T = RecordAny, U = RecordAny> extends CommandModule<T, U> {
    /**
     * 是否为执行后即退出进程的瞬时应用
     */
    instant?: boolean;
}
```

### 命令构造器

该类型是命令构造函数的类型，这个函数在执行后将生成一个yargs命令模块，在参数中传入`app`，它包含了

- 当前运行的nest实例:`container`
- 配置模块实例: `configure`
- 以及所有的命令模块: `commands`

```typescript
// src/modules/core/types.ts
export type CommandItem<T = Record<string, any>, U = Record<string, any>> = (
    app: Required<App>,
) => Promise<CommandOption<T, U>>;
```

### 命令选项

这是命令构造器的列表数组类型

```typescript
// src/modules/core/types.ts
export type CommandCollection = Array<CommandItem<any, any>>;
```

### 应用创建选项

改造一下应用创建参数类型，加个构造器列表生成函数类型

```typescript
// src/modules/core/types.ts
/**
 * 创建应用的选项参数
 */
export interface CreateOptions {
    /**
     * 应用命令
     */
    commands: () => CommandCollection;
    // ...
}
```

### App类型

同样地，给APP类型也添加一个命令类型，当然这边的命令是已经同构命令构造函数生成可直接传入yargs使用的命令模块

```typescript
// src/modules/core/types.ts
/**
 * App对象类型
 */
export type App = {
    /**
     * 应用容器实例
     */
    container?: NestFastifyApplication;
    /**
     * 配置类实例
     */
    configure: Configure;
    /**
     * 命令列表
     */
    commands: CommandModule<RecordAny, RecordAny>[];
};
```

### 修复应用

我们分别给应用创建选项`CreateOptions`和应用`App`两个类型添加了`commands`，会看到代码报错了。需要修复一下

```typescript
// src/options.ts
export const createOptions: CreateOptions = {
    commands: () => [],
    // ...
};

// src/modules/core/helpers/app.ts
/**
 * app实例常量
 */
export const app: App = { configure: new Configure(), commands: [] };
```

因为**bun**自身存在一些esm相关问题，所以我们需要更改几个类型的导入为`import type`

```typescript
// src/modules/content/entities/category.entity.ts
// src/modules/content/entities/tag.entity.ts
// src/modules/content/entities/post.entity.ts
// src/modules/content/entities/comment.entity.ts
import type { Relation } from 'typeorm';

// src/modules/content/services/post.service.ts
import type { SearchType } from '../types';

// src/modules/meilisearch/meilli.service.ts
import type { MelliConfig } from './types';
```

## 函数

下面我们开始为我们的Nest应用添加自定义命令功能

### 创建命令

1. 根据传入的命令构建函数生成函数获取命令构造器列表
2. 执行所有的命令构造器函数，并为每个函数传入`app`参数，获取所有的yargs命令模块
3. 遍历这些命令模块，改造执行器函数。首先关闭container实例，然后执行命令执行器，最后判断如果是瞬时命令就退出进程

```typescript
// src/modules/core/helpers/command.ts
/**
 * 创建命令
 * @param factory
 * @param app
 */
export async function createCommands(
    factory: () => CommandCollection,
    app: Required<App>,
): Promise<CommandModule<any, any>[]> {
    const collection: CommandCollection = [...factory()];
    const commands = await Promise.all(collection.map(async (command) => command(app)));
    return commands.map((command) => ({
        ...command,
        handler: async (args: Arguments<RecordAny>) => {
            await app.container.close();
            await command.handler(args);
            if (command.instant) process.exit();
        },
    }));
}
```

### 解析命令

在app创建后把命令解析出来

```typescript
// src/modules/core/helpers/app.ts
export const createApp = (options: CreateOptions) => async (): Promise<App> => {
    // ...
    app.commands = await createCommands(options.commands, app as Required<App>);
    return app;
};
```

### CLI构建

该函数用于构建CLI命令，使用生成的命令模块绑定yargs即可

```typescript
// src/modules/core/helpers/command.ts
/**
 * 构建yargs cli
 * @param creator
 */
export async function buildCli(creator: () => Promise<App>) {
    const app = await creator();
    const bin = yargs(hideBin(process.argv));
    app.commands.forEach((command) => bin.command(command));
    bin.usage('Usage: $0 <command> [args]')
        .scriptName('cli')
        .demandCommand(1, '')
        .fail((msg, err, y) => {
            if (!msg && !err) {
                bin.showHelp();
                process.exit();
            }
            if (msg) console.error(chalk.red(msg));
            if (err) console.error(chalk.red(err.message));
            process.exit();
        })
        .strict()
        .alias('v', 'version')
        .help('h')
        .alias('h', 'help')
        .parse();
}
```

### 演示命令

我们编写一个模拟命令来看一下效果

```typescript
// src/modules/core/commands/types.ts
export type DemoCommandArguments = {
    sleep?: boolean;
};

// src/modules/core/commands/demo.command.ts
export const DemoCommand: CommandItem<any, DemoCommandArguments> = async (app) => ({
    command: ['demo', 'd'],
    describe: 'A demo command',
    builder: {
        sleep: {
            type: 'boolean',
            alias: 's',
            describe: ' App will sleep?',
            default: false,
        },
    },
    handler: async (args: Arguments<DemoCommandArguments>) => {
        const { configure } = app;
        const appName = await configure.get<string>('app.name');
        const sleep = args.sleep ? ' will to sleep' : '';
        console.log(`It's just a demo command, My app ${appName}${sleep}`);
    },
});

// src/modules/core/commands/index.ts
export * from './demo.command';
```

### 导入命令

命令编写完后需要导入后才能生效，这边我们直接把命令放在`createCommands`

:::info

后续非`CoreModule`核心命令的其他模块命令可以在外部的应用创建时传入

:::

```typescript
// src/modules/core/helpers/command.ts
export async function createCommands(
    factory: () => CommandCollection,
    app: Required<App>,
): Promise<CommandModule<any, any>[]> {
    const collection: CommandCollection = [...factory(), ...Object.values(coreCommands)];
    // ...
}
```

## 运行时

要让命令跑起来，我们还需要编写一个运行命令的bin文件

### 编写BIN

这里的`#!/usr/bin/env node`用于在应用编译后，直接可以通过文件使用`./dist/console/bin.js`去运行命令，而不需要`node ./dist/console/bin.js`或者`bun ./dist/console/bin.js`去运行。不过我们后面都是用bun直接运行ts源码命令，所以在此处作用不大

这个文件用于创建一个app的创建器，并传入`buildCli`，这样就可以使用yargs构建一个命令工具了

***nix系统下如下编写**

```typescript
// src/console/bin.ts
import { createOptions } from '@/options';

import { buildCli, createApp } from '../modules/core/helpers';

buildCli(createApp(createOptions));
```

**win系统下如下编写(使用`ts-node`加载ts文件)**

:::danger

再次提醒：强烈不建议使用裸win开发node.js应用，请尽量使用wsl2

:::

:::tip

注意: win下是`.js`文件，不是`bin.ts`

:::

```javascript
// src\console\bin.js

#!/usr/bin/env node
/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable import/no-extraneous-dependencies */
const { existsSync } = require('fs');
const { resolve } = require('path');

const projectPath = resolve(__dirname, '../../tsconfig.build.json');
if (existsSync(projectPath)) {
    require('ts-node').register({
        files: true,
        transpileOnly: true,
        project: projectPath,
    });
}

const { createOptions } = require('../constants');

const { buildCli, createApp } = require('../modules/core/helpers');

buildCli(createApp(createOptions));

```

### 添加脚本

在win下我们把所有脚本添加好，而*nix下的开发启动和编译等命令请看下一节课

#### *nix系统

最后在`package.json`中添加一个脚本命令，使用`bun`来直接运行`bin.ts`

:::tip

注意: 这里的`--bun`参数用于透传bun运行时，因为如果运行编译后带有`#!/usr/bin/env node`的js文件可能会自动切换到node运行时。所以为了使用bun运行，必须加上这个参数。但是在此处直接运行ts文件，则不会有任何影响

:::

:::note

经测试后，最新版的bun运行nestjs代码无任何问题

:::

```typescript
{
  "scripts": {
        "cli": "./node_modules/bun/bin/bun --bun ./console/bin.ts",
        // ...
    },
}
```

#### windows系统

```typescript
{
    "scripts": {
        "cli": "cross-env NODE_ENV=development node ./src/console/bin.js",
         // ...
    },
}
```

## 效果

运行`pnpm cli -h`可以看到我们刚才添加的命令已经存在了

![](https://img.pincman.com/media/202401280739534.png)

运行`pnpm cli demo`或`pnpm demo s`输出应用名称

![](https://img.pincman.com/media/202401280739334.png)

