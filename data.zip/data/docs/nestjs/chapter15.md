---
title: 数据填充命令实现
sidebar_label: 数据填充命令实现
hide_title: true
sidebar_position: 17
---

## 前置准备

本功能用于对数据库注入一些数据以方便前端展示和API测试，思路来源: Laravel的[数据填充](https://learnku.com/docs/laravel/10.x/seeding/14886)和[数据工厂](https://learnku.com/docs/laravel/10.x/eloquent-factories/14894)

### 依赖解析

- `dayjs`: 一个时间库，具体使用方法可查阅其[官网文档](https://day.js.org/zh-CN/)
- `faker`: 一个假数据生成库，具体使用方法可查阅其[官网文档](https://fakerjs.dev/guide/)

```bash
pnpm add @faker-js/faker dayjs
```

## 核心模块

我们需要对核心模块进行一些修改

### 类型

为`AppConfig`添加时区和国际化配置类型

```typescript
// src/modules/core/types.ts
export interface AppConfig {
    // ...
    /**
     * 时区,默认Asia/Shanghai
     */
    timezone: string;
    /**
     * 语言,默认zh-cn
     */
    locale: string;
    /**
     * 备用语言
     */
    fallback_locale: string;
}
```

### 默认配置

设置默认的时区和国际化配置

```typescript
// src/modules/core/config.ts
export const getDefaultAppConfig = (configure: Configure) => ({
    // ...
    timezone: configure.env.get('APP_TIMEZONE', 'Asia/Shanghai'),
    locale: configure.env.get('APP_LOCALE', 'zh_CN'),
    fallbackLocale: configure.env.get('APP_FALLBACK_LOCALE', 'en'),
});
```

### 时间函数

为了可以快捷的获取`dayjs`的时间对象，我们添加一个时间函数
首先定义一个时间参数选项类型

- `date`: 时间属性，如果不传入则获取当前属性
- `format`: 输出时间格式，具体可以参考dayjs的文档
- `locale`: 语言，如果不传入则使用`app`配置中设置的默认语言
- `strict`: 是否开启严格模式
- `zonetime`: 时区。如果不传入则使用`app`配置中设置的默认时区

```typescript
// src/modules/core/types.ts
import dayjs from 'dayjs';

export interface TimeOptions {
    date?: dayjs.ConfigType;
    format?: dayjs.OptionType;
    locale?: string;
    strict?: boolean;
    zonetime?: string;
}
```

函数接收一个选项参数并最终返回一个dayjs对象，执行逻辑如下

1. 从传入的选项参数中获取必要的属性
2. 获取应用配置中的默认时区及语言相关配置
3. 克隆一个新的dayjs对象
4. 返回该对象并设置时区

```typescript
// src/modules/core/helpers/time.ts
import dayjs from 'dayjs';

import 'dayjs/locale/en';
import 'dayjs/locale/zh-cn';
import 'dayjs/locale/zh-tw';

import advancedFormat from 'dayjs/plugin/advancedFormat';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import dayOfYear from 'dayjs/plugin/dayOfYear';
import localeData from 'dayjs/plugin/localeData';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';

import { Configure } from '@/modules/config/configure';

import { AppConfig, TimeOptions } from '../types';

dayjs.extend(localeData);
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(advancedFormat);
dayjs.extend(customParseFormat);
dayjs.extend(dayOfYear);

/**
 * 获取一个dayjs时间对象
 * @param configure
 * @param options
 */
export const getTime = async (configure: Configure, options?: TimeOptions) => {
    const { date, format, locale, strict, zonetime } = options ?? {};
    const config = await configure.get<AppConfig>('app');
    // 每次创建一个新的时间对象
    // 如果没有传入local或timezone则使用应用配置
    const now = dayjs(date, format, locale ?? config.locale, strict).clone();
    return now.tz(zonetime ?? config.timezone);
};
```

## 数据填充

### 类型

编写之前我们先添加以下类型
`SeederOptions`是数据填充处理器选项

- `connection`类型为数据库连接名称
- `transaction`用于设置是否通过事务来运行填充
- `ignorelock`是否忽略已经被执行过的填充类

`SeederLoadParams`用于设置`load`方法的（填充数据逻辑方法）的参数类型，其属性如下

- `connection`：连接名称
- `dataSource`: 数据连接池
- `em`:  EntityManager实例
- `configure`: 配置类实例
- `ignorelock`是否忽略已经被执行过的填充类

`Seeder`为`BaseSeeder`类的接口，必须实现`load`方法

`SeederConstructor`为`call`方法的参数类型，用于传入Seed子类来运行填充

```typescript
// src/modules/database/commands/types.ts
/**
 * 数据填充处理器选项
 */
export interface SeederOptions {
    connection?: string;
    transaction?: boolean;
    ignorelock?: boolean;
}

/**
 * 数据填充类接口
 */
export interface SeederConstructor {
    new (spinner: Ora, args: SeederOptions): Seeder;
}

/**
 * 数据填充类方法对象
 */
export interface Seeder {
    load: (params: SeederLoadParams) => Promise<void>;
}

/**
 * 数据填充类的load函数参数
 */
export interface SeederLoadParams {
    /**
     * 数据库连接名称
     */
    connection: string;
    /**
     * 数据库连接池
     */
    dataSource: DataSource;

    /**
     * EntityManager实例
     */
    em: EntityManager;

    /**
     * 项目配置类
     */
    configure: Configure;

    /**
     * 是否忽略锁定
     */
    ignoreLock: boolean;
}
```

### 基础类

#### 属性

以下是该类的属性

- `dataSource`属性: 数据连接池
- `em`属性: entity manager
- `configure`属性: 配置类的实例
- `truncates`属性: 在执行Seed时需要清空的数据表对应的模型类
- `ignoreLock`属性: 本次执行是否忽略已执行过的填充类，如果忽略，将清空该次执行的填充类设置的模型对应的表数据

#### `load`方法

该方法的执行逻辑为

1. 设置数据库连接名，连接池，em，配置类实例
2. 判断当前运行环境是否为生产环境
3. 如果不是在生产环境下，则在运行填充之前先根据`truncates`属性把原来的数据表中的数据给清空掉
4. 调用`run`方法运行迁移

#### `run`方法

这里放置填充数据的具体执行逻辑，目前只接收`dataSource`和`em`两个参数，下面我们也会添加`factories`参数,用于获取数据工厂

#### `call`方法

在此方法内调用子Seeder

```typescript
// src/modules/database/base/seeder.ts
/**
 * 数据填充基类
 */
export abstract class BaseSeeder implements Seeder {
    protected dataSource: DataSource;

    protected em: EntityManager;

    protected connection = 'default';

    protected configure: Configure;

    protected ignoreLock = false;

    protected truncates: EntityTarget<ObjectLiteral>[] = [];

    constructor(
        protected readonly spinner: Ora,
        protected readonly args: SeederOptions,
    ) {}

    /**
     * 清空原数据并重新加载数据
     * @param params
     */
    async load(params: SeederLoadParams): Promise<any> {
        const { dataSource, em, connection, configure, ignoreLock } = params;
        this.connection = connection;
        this.dataSource = dataSource;
        this.em = em;
        this.configure = configure;
        this.ignoreLock = ignoreLock;
        if (this.ignoreLock) {
            for (const truncate of this.truncates) {
                await this.em.clear(truncate);
            }
        }

        const result = await this.run(this.dataSource);
        return result;
    }

    protected async getDbConfig() {
        const { connections = [] }: DbConfig = await this.configure.get<DbConfig>('database');
        const dbConfig = connections.find(({ name }) => name === this.connection);
        if (isNil(dbConfig)) panic(`Database connection named ${this.connection} not exists!`);
        return dbConfig;
    }

    /**
     * 运行seeder的关键方法
     * @param factorier
     * @param dataSource
     */
    protected abstract run(dataSource?: DataSource, em?: EntityManager): Promise<any>;

    /**
     * 运行子seeder
     * @param SubSeeder
     */
    protected async call(SubSeeder: SeederConstructor) {
        const subSeeder: Seeder = new SubSeeder(this.spinner, this.args);
        await subSeeder.load({
            connection: this.connection,
            dataSource: this.dataSource,
            em: this.em,
            configure: this.configure,
            ignoreLock: this.ignoreLock,
        });
    }
}
```

### 入口类

入口类一般是唯一的，用于调用其它编写具体逻辑的Seeder类来进行数据填充，其逻辑如下

1. 获取需要运行的数据连接下的所有Seeder类
2. 首先读取项目的外层目录下的`seed-lock.yml`文件内容（如果不存在的话则创建一个）
3. 接着读取该yaml文件的内容到一个对象并把它赋值给`locked`
4. 该对象的结构为`{连接名: [已经执行过的seeder类名]}`
5. 获取当前连接下已经执行过的seeder类并赋值给`lockNames`
6. 判断当前环境是否忽略锁定（是否有`-i`或`--ignoreLock`参数）
7. 如果是，则从当前待执行的seeder类数组中过滤掉`lockNames`中的seeder类并赋值给`seeders`数组变量，防止这些seeder类被重复执行
8. 遍历执行`seeders`数组中的seeder类
9. 全部执行完毕后把`seeders`数组中的类添加到`locked`变量
10. 最后把新的`locked`写入`seed-lock.yml`

```typescript
// src/modules/database/resolver/seed.runner.ts
/**
 * 默认的Seed Runner
 */
export class SeedRunner extends BaseSeeder {
    /**
     * 运行一个连接的填充类
     * @param _dataSource
     * @param _em
     */
    async run(_factory: DbFactory, _dataSource: DataSource, _em: EntityManager): Promise<any> {
        let seeders: Type<any>[] = ((await this.getDbConfig()) as any).seeders ?? [];
        const seedLockFile = resolve(__dirname, '../../../..', 'seed-lock.yml');
        ensureFileSync(seedLockFile);
        const yml = YAML.parse(readFileSync(seedLockFile, 'utf8'));
        const locked = isNil(yml) ? {} : yml;
        const lockNames = get<string[]>(locked, this.connection, []);
        if (!this.ignoreLock) {
            seeders = seeders.filter((s) => !lockNames.includes(s.name));
        }
        for (const seeder of seeders) {
            await this.call(seeder);
        }
        set(
            locked,
            this.connection,
            !this.ignoreLock
                ? [...lockNames, ...seeders.map((s) => s.name)]
                : seeders.map((s) => s.name),
        );
        writeFileSync(seedLockFile, JSON.stringify(locked, null, 4));
    }
}
```

### 忽略外键

在mysql下，运行指定了清空数据表的填充类时需要忽略外键

```typescript
// src/modules/database/helpers.ts
/**
 * 忽略外键
 * @param em EntityManager实例
 * @param type 数据库类型
 * @param disabled 是否禁用
 */
export async function resetForeignKey(
    em: EntityManager,
    type = 'mysql',
    disabled = true,
): Promise<EntityManager> {
    let key: string;
    let query: string;
    if (type === 'sqlite') {
        key = disabled ? 'OFF' : 'ON';
        query = `PRAGMA foreign_keys = ${key};`;
    } else {
        key = disabled ? '0' : '1';
        query = `SET FOREIGN_KEY_CHECKS = ${key};`;
    }
    await em.query(query);
    return em;
}
```

### 填充函数

该函数是数据填充命令的核心执行函数，接收以下参数

- `Clazz`: 传入的入口填充类，用于执行填充子类
- `args`: 填充命令的选项参数
- `spinner`: Ora对象，展示“执行中”的雪碧进度动画
- `configure`: `Configure`类的实例
- `dbConfig`: 本次数据库连接的配置

执行逻辑如下

1. 创建入口填充类的实例
2. 获取当前数据库连接的配置
3. 根据配置创建当前数据库连接的连接池
4. 初始化数据库连接池
5. 遍历数据工厂函数生成数据工厂列表对象，格式为`{模型名: {模型类,处理器}}`
6. 如果不启用事务，则直接运行填充类实例的`load`方法填充数据（注意，需要忽略外键）
7. 如果启用事务(默认启用)，则通过事务的方式去填充数据（同样需要忽略外键）
8. 销毁本次数据库连接实例

```typescript
// src/modules/database/helpers.ts
/**
 * 数据填充函数
 * @param Clazz 填充类
 * @param args 填充命令参数
 * @param spinner Ora雪碧图标
 * @param configure 配置对象
 * @param dbConfig 当前数据库连接池的配置
 */
export async function runSeeder(
    Clazz: SeederConstructor,
    args: SeederOptions,
    spinner: Ora,
    configure: Configure,
    dbConfig: TypeormOption,
): Promise<DataSource> {
    const seeder: Seeder = new Clazz(spinner, args);
    const dataSource = new DataSource({ ...dbConfig } as DataSourceOptions);

    await dataSource.initialize();
    if (typeof args.transaction === 'boolean' && !args.transaction) {
        const em = await resetForeignKey(dataSource.manager, dataSource.options.type);
        await seeder.load({
            dataSource,
            em,
            configure,
            connection: args.connection ?? 'default',
            ignoreLock: args.ignorelock,
        });
        await resetForeignKey(em, dataSource.options.type, false);
    } else {
        // 在事务中运行
        const queryRunner = dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            const em = await resetForeignKey(queryRunner.manager, dataSource.options.type);
            await seeder.load({
                dataSource,
                em,
                configure,
                connection: args.connection ?? 'default',
                ignoreLock: args.ignorelock,
            });
            await resetForeignKey(em, dataSource.options.type, false);
            // 提交事务
            await queryRunner.commitTransaction();
        } catch (err) {
            console.log(err);
            // 遇到错误则回滚
            await queryRunner.rollbackTransaction();
        } finally {
            // 执行事务
            await queryRunner.release();
        }
    }
    if (dataSource.isInitialized) await dataSource.destroy();
    return dataSource;
}
```

### 默认配置

在原来的`DbAdditionalOption`类型中添加一个`seedRunner`类型，用于在配置中指定自定义的填充入口类，添加一个`seeders`类型用于设置填充类列表

再给默认数据库的公共配置添加一下这两个属性

```typescript
// src/modules/database/types.ts
type DbAdditionalOption = {
     /**
     * 数据填充入口类
     */
    seedRunner?: SeederConstructor;
    /**
     * 数据填充类列表
     */
    seeders?: SeederConstructor[];
    //...
};

// src/modules/database/config.ts
/**
 * 数据库配置构造器创建
 * @param register
 */
export const createDbConfig: (
    register: ConfigureRegister<RePartial<DbConfig>>,
) => ConfigureFactory<DbConfig, DbOptions> = (register) => ({
    register,
    hook: (configure, value) => createDbOptions(value),
    defaultRegister: () => ({
        common: {
            charset: 'utf8mb4',
            logging: ['error'],
            seedRunner: SeedRunner,
            seeders: [],
        },
        connections: [],
    }),
});
```

### 命令处理器

命令处理器非常简单

1. 判断在当前数据库连接的配置中有自定义的填充入口类，没有则使用默认的`SeedRunner`类
2. 使用`runSeeder`运行填充

```typescript
// src/modules/database/commands/seed.handler.ts
export const SeedHandler = async (configure: Configure, args: SeederOptions) => {
    const cname = args.connection ?? 'default';
    const { connections = [] }: DbOptions = await configure.get<DbOptions>('database');
    const dbConfig = connections.find(({ name }) => name === cname);
    if (isNil(dbConfig)) panic(`Database connection named ${cname} not exists!`);
    const runner = dbConfig.seedRunner;
    const spinner = ora('Start run seeder');
    try {
        spinner.start();
        await runSeeder(runner, args, spinner, configure, dbConfig);
        spinner.succeed(`\n 👍 ${chalk.greenBright.underline(`Finished Seeding`)}`);
    } catch (error) {
        panic({ spinner, message: `Run seeder failed`, error });
    }
};
```

### 命令编写

填充命令接收四个参数

- `clear`: 是否根据填充类中定义的`truncated`属性清除数据表（生产环境下不可用）
- `connection`: 需要运行填充的数据库连接名（默认`default`）
- `transaction`: 是否在事务模式下运行
- `ignorelock`: 是否忽略锁定

```typescript
// src/modules/database/commands/types.ts
export type SeederArguments = TypeOrmArguments & SeederOptions;

// src/modules/database/commands/seed.command.ts
export const SeedCommand: CommandItem<any, SeederArguments> = async ({ configure }) => ({
    command: ['db:seed', 'dbs'],
    describe: 'Runs all seeds data.',
    builder: {
        clear: {
            type: 'boolean',
            alias: 'r',
            describe: 'Clear which tables will truncated specified by seeder class.',
            default: true,
        },
        connection: {
            type: 'string',
            alias: 'c',
            describe: 'Connection name of typeorm to connect database.',
        },
        transaction: {
            type: 'boolean',
            alias: 't',
            describe: 'If is seed data in transaction,default is true',
            default: true,
        },
        ignorelock: {
            type: 'boolean',
            alias: 'i',
            describe: 'Ignore seed lock and reset all seeds, not do it in production',
            default: false,
        },
    } as const,

    handler: async (args: Arguments<SeederArguments>) => SeedHandler(configure, args),
});
```

## 数据工厂

在运行迁移时，可能我们手头的真实数据不够多，这时使用数据工厂生成一条或多条模拟的假数据是非常不错的办法

### 工厂定义

编写一个工厂定义函数`defineFactory`，该函数接收两个参数，分别为模型类和其绑定的工厂函数，其中工厂函数用于编写生成模拟数据的逻辑
`defineFactory`函数的返回值是一个函数，该值函数的作用就在于执行时会生成一个模型和工厂函数的对象

- `defineFactory`函数的类型为`DefineFactory`
- `defineFactory`的`handler`参数（工厂函数）的类型为`DbFactoryHandler`，该函数接收两个参数，`configure`配置实例以及自定义选项，并返回一个赋值模拟数据后的模型对象
- `defineFactory`的返回值函数执行后的返回值为`DbFactoryOption`类型，他是一个拥有`entity`模型类以及`handler`工厂函数的对象

```typescript
// src/modules/database/types.ts
export type DefineFactory = <E, O>(
    entity: ObjectType<E>,
    handler: DbFactoryHandler<E, O>,
) => () => DbFactoryOption<E, O>;

export type DbFactoryHandler<E, O> = (configure: Configure, options: O) => Promise<E>;

export type DbFactoryOption<E, O> = {
    entity: ObjectType<E>;
    handler: DbFactoryHandler<E, O>;
};
```

函数的编写非常简单，如下

```typescript
// src/modules/database/helpers.ts
/**
 * 定义factory用于生成数据
 * @param entity 模型
 * @param handler 处理器
 */
export const defineFactory: DefineFactory = (entity, handler) => () => ({
    entity,
    handler,
});
```

有了该函数后，就能通过以下方式来绑定模型和工厂函数了

```typescript
// src/database/factories/content.factory.ts
export const ContentFactory = defineFactory(
    PostEntity,
    async (configure: Configure, options: IPostFactoryOptions) => {
        const faker = new fakerjs.Faker({
            locale: await getFakerLocales(configure),
        });
        const post = new PostEntity();
        // ...
        return post;
    },
);
```

### 数据生产

数据生产用来生产模拟数据

`FactoryOverride`类型

该类型用于定义Factory自定义参数覆盖

```typescript
// src/modules/database/types.ts
export type FactoryOverride<Entity> = {
    [Property in keyof Entity]?: Entity[Property];
};
```

#### `mapFunction`属性

`mapFunction`属性用于设置当前需要执行的模型的工厂函数

#### 构造方法

构造方法接收四个参数

- `name`为模型的类名称
- `configure`为配置实例
- `entity`为模型类
- `em`为entityManager实例
- `factory`为该模型绑定的factory执行函数（即模拟数据生成器）
- `settings`为设置选项，其类型为`DbFactoryOption`

#### `map`方法

默认的执行函数是定义后在`database`的配置里设置了的，但有时我们可以不想使用默认的模型绑定的工厂函数，可以通过`map`方法为该模型临时换绑一个工厂函数

#### `make`方法

`make`方法用于临时创建一批模拟数据以备后续使用，但不是马上就存储到数据库

:::info

`this.factory`由构造函数传入，它就是通过上面的`defineFactory`函数返回的函数再执行后返回的对象中的`handler`工厂函数，比如`async (configure: Configure, options: IPostFactoryOptions) => {... return post}`，具体怎么得到这个函数，我们接下去看，这里先不管

:::

该方法的逻辑如下

1. 首先通过`this.factory`得出赋值模拟数据后的模型对象
2. 在把你要通过`overrideParams`参数自定义覆盖的模型字段值设置一下
3. 最后返回该模型实例

`create`方法非常简单，就是先调用`make`方法生成模型对象，再通过entityManger获取该对象默认的Repository对象，然后使用`save`方法保存该对象。
于此同时，我们还可以通过传入一个`existsCheck`来判断数据库中是否存在当前模型实例的某个字段值的数据，如果不存在才创建！

#### 多条数据

通过`makeMany`与`createMany`方法可以遍历地模拟及创建多条数据，数据的数量可通过`amount`参数来指定

#### 代码

```typescript
// src/modules/database/resolver/data.factory.ts
export class DataFactory<Entity, Settings> {
    private mapFunction!: (entity: Entity) => Promise<Entity>;

    constructor(
        public name: string,
        public configure: Configure,
        public entity: EntityTarget<Entity>,
        protected em: EntityManager,
        protected factory: DbFactoryHandler<Entity, Settings>,
        protected settings: Settings,
    ) {}

    map(mapFunction: (entity: Entity) => Promise<Entity>): DataFactory<Entity, Settings> {
        this.mapFunction = mapFunction;
        return this;
    }

    async make(overrideParams: FactoryOverride<Entity> = {}): Promise<Entity> {
        if (this.factory) {
            let entity: Entity = await this.resolveEntity(
                await this.factory(this.configure, this.settings),
            );
            if (this.mapFunction) entity = await this.mapFunction(entity);
            for (const key in overrideParams) {
                if (overrideParams[key]) {
                    entity[key] = overrideParams[key]!;
                }
            }
            return entity;
        }
        throw new Error('Could not found entity');
    }

    async create(
        overrideParams: FactoryOverride<Entity> = {},
        existsCheck?: string,
    ): Promise<Entity> {
        try {
            const entity = await this.make(overrideParams);
            if (!isNil(existsCheck)) {
                const repo = this.em.getRepository(this.entity);
                const value = (entity as any)[existsCheck];
                if (!isNil(value)) {
                    const item = await repo.findOneBy({ [existsCheck]: value } as any);
                    if (isNil(item)) return await this.em.save(entity);
                    return item;
                }
            }
            return await this.em.save(entity);
        } catch (error) {
            const message = 'Could not save entity';
            panic({ message, error });
            throw new Error(message);
        }
    }

    async makeMany(
        amount: number,
        overrideParams: FactoryOverride<Entity> = {},
    ): Promise<Entity[]> {
        const list = [];
        for (let index = 0; index < amount; index += 1) {
            list[index] = await this.make(overrideParams);
        }
        return list;
    }

    async createMany(
        amount: number,
        overrideParams: FactoryOverride<Entity> = {},
        existsCheck?: string,
    ): Promise<Entity[]> {
        const list = [];
        for (let index = 0; index < amount; index += 1) {
            list[index] = await this.create(overrideParams, existsCheck);
        }
        return list;
    }

    private async resolveEntity(entity: Entity): Promise<Entity> {
        for (const attribute in entity) {
            if (entity[attribute]) {
                if (isPromise(entity[attribute])) {
                    entity[attribute] = await Promise.resolve(entity[attribute]);
                }

                if (typeof entity[attribute] === 'object' && !(entity[attribute] instanceof Date)) {
                    const subEntityFactory = entity[attribute];
                    try {
                        if (typeof (subEntityFactory as any).make === 'function') {
                            entity[attribute] = await (subEntityFactory as any).make();
                        }
                    } catch (error) {
                        const message = `Could not make ${(subEntityFactory as any).name}`;
                        panic({ message, error });
                        throw new Error(message);
                    }
                }
            }
        }
        return entity;
    }
}
```

### 工厂函数

`entityName`函数比较简单，就是通过模型的类名或函数名来获取这个模型的名称
`factoryBuilder`函数用于返回一个二级柯里化的函数，返回的函数最终生成一个用于生产数据的`DataFactory`实例。它接收三个参数，即`configure`(应用配置实例)、`dataSource`(数据连接池)以及`factories`(数据工程列表，在执行填充命令时由命令处理器传入)

:::warning

请务必通过`../resolver/data.factory`导入`DataFactory`而不是`../resolver`，以防止循环导入

:::

```typescript
// src/modules/database/commands/types.ts
import { DataFactory } from '../resolver/data.factory';

/**
 * Factory解析器
 */
export interface DbFactory {
    <Entity>(
        entity: EntityTarget<Entity>,
    ): <Options>(options?: Options) => DataFactory<Entity, Options>;
}

/**
 * 数据填充函数映射对象
 */
export type FactoryOptions = {
    [entityName: string]: DbFactoryOption<any, any>;
};

/**
 * Factory构造器
 */
export type DbFactoryBuilder = (
    configure: Configure,
    dataSource: DataSource,
    factories: {
        [entityName: string]: DbFactoryOption<any, any>;
    },
) => DbFactory;


// src/modules/database/helpers.ts
/**
 * 获取Entity类名
 * @param entity
 */
export function entityName<T>(entity: EntityTarget<T>): string {
    if (entity instanceof Function) return entity.name;
    if (!isNil(entity)) return new (entity as any)().constructor.name;
    throw new Error('Enity is not defined');
}

/**
 * Factory构建器
 * @param configure 配置对象
 * @param dataSource Factory构建器
 * @param factories factory函数组
 */
export const factoryBuilder: DbFactoryBuilder =
    (configure, dataSource, factories) => (entity) => (settings) => {
        const name = entityName(entity);
        if (!factories[name]) {
            throw new Error(`has none factory for entity named ${name}`);
        }
        return new DataFactory(
            name,
            configure,
            entity,
            dataSource.createEntityManager(),
            factories[name].handler,
            settings,
        );
    };
```

### 结合Seeder

模拟数据的生成最终目的是提供给数据填充使用，所以我们需要修改seeder相关的一些东西才可以使用数据工厂

#### 类型

修改`SeederLoadParams`类型，以使Seeder类的`load`函数的参数能接收数据工厂的解析器和工厂列表

```typescript
// src/modules/database/commands/types.ts
export interface SeederLoadParams {
     // ...

    /**
     * Factory解析器
     */
    factorier?: DbFactory;
    /**
     * Factory函数列表
     */
    factories: FactoryOptions;
}
```

#### 填充基类

修改`BaseSeeder`，在每个子Seeder中传入数据生产类`DataFactory`类的实例，以便能生产假数据

```typescript
// src/modules/database/base/seeder.ts
export abstract class BaseSeeder implements Seeder {
    // ...
    protected factories: {
        [entityName: string]: DbFactoryOption<any, any>;
    };

    async load(params: SeederLoadParams): Promise<any> {
        const { factorier, factories, dataSource, em, connection, configure, ignoreLock } = params;
        // ...
        this.factories = factories;
        const result = await this.run(factorier, this.dataSource);
        return result;
    }


    protected abstract run(
        factorier?: DbFactory,
        dataSource?: DataSource,
        em?: EntityManager,
    ): Promise<any>;
  
    protected async call(SubSeeder: SeederConstructor) {
        const subSeeder: Seeder = new SubSeeder(this.spinner, this.args);
        await subSeeder.load({
            connection: this.connection,
            factorier: factoryBuilder(this.configure, this.dataSource, this.factories),
            factories: this.factories,
            dataSource: this.dataSource,
            em: this.em,
            configure: this.configure,
            ignoreLock: this.ignoreLock,
        });
    }
}
```

#### 填充运行器

修改`SeedRunner`的`run`方法，作用与`BaseSeeder`对应

```typescript
// src/modules/database/resolver/seed.runner.ts
export class SeedRunner extends BaseSeeder {
    async run(_factory: DbFactory, _dataSource: DataSource, _em: EntityManager): Promise<any> {
        //...
    }
}
```

#### 默认配置

为数据连接配置添加一个`factories`属性用于定义数据工厂列表

```typescript
// src/modules/database/types.ts
type DbAdditionalOption = {
    // ...
    factories?: (() => DbFactoryOption<any, any>)[];
};

// src/modules/database/config.ts
export const createDbConfig: (
    register: ConfigureRegister<RePartial<DbConfig>>,
) => ConfigureFactory<DbConfig, DbOptions> = (register) => ({
    // ...
            seeders: [],
            factories: [],
        },
        connections: [],
    }),
});
```

#### 填充函数

在入口填充类的`load`方法中传入数据工厂类的实例`factorier`以及工厂函数列表`factories`

```typescript
// src/modules/database/helpers.ts
export async function runSeeder(
    Clazz: SeederConstructor,
    args: SeederOptions,
    spinner: Ora,
    configure: Configure,
    dbConfig: TypeormOption,
): Promise<DataSource> {
    const seeder: Seeder = new Clazz(spinner, args);
    const dataSource = new DataSource({ ...dbConfig } as DataSourceOptions);

    await dataSource.initialize();
    const factoryMaps: FactoryOptions = {};
    for (const factory of dbConfig.factories) {
        const { entity, handler } = factory();
        factoryMaps[entity.name] = { entity, handler };
    }
    if (typeof args.transaction === 'boolean' && !args.transaction) {
        const em = await resetForeignKey(dataSource.manager, dataSource.options.type);
        await seeder.load({
            factorier: factoryBuilder(configure, dataSource, factoryMaps),
            factories: factoryMaps,
            dataSource,
            em,
            configure,
            connection: args.connection ?? 'default',
            ignoreLock: args.ignorelock,
        });
        await resetForeignKey(em, dataSource.options.type, false);
    } else {
        // 在事务中运行
        const queryRunner = dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            const em = await resetForeignKey(queryRunner.manager, dataSource.options.type);
            await seeder.load({
                factorier: factoryBuilder(configure, dataSource, factoryMaps),
                factories: factoryMaps,
                dataSource,
                em,
                configure,
                connection: args.connection ?? 'default',
                ignoreLock: args.ignorelock,
            });
          // ...
}
```

### Faker本地化

模拟数据的生成可以根据我们的配置输出本地化假数据

```typescript
// src/modules/database/helpers.ts
import * as fakerjs from '@faker-js/faker';

export const getFakerLocales = async (configure: Configure) => {
    const app = await configure.get<AppConfig>('app');
    const locales: fakerjs.LocaleDefinition[] = [];
    const locale = app.locale as keyof typeof fakerjs;
    const fallbackLocale = app.fallbackLocale as keyof typeof fakerjs;
    if (!isNil(fakerjs[locale])) locales.push(fakerjs[locale] as fakerjs.LocaleDefinition);
    if (!isNil(fakerjs[fallbackLocale]))
        locales.push(fakerjs[fallbackLocale] as fakerjs.LocaleDefinition);
    return locales;
};
```

## 功能使用

下面我们来编写一下内容模块几个数据表的数据填充，顺带测试一下本节课的功能是否完善

### 辅助函数

在此之前我们先编写几个有用的辅助工具函数

```typescript
// src/modules/core/helpers/utils.ts
/**
 * 获取小于N的随机整数
 * @param count
 */
export const getRandomIndex = (count: number) => Math.floor(Math.random() * count);

/**
 * 从列表中获取一个随机项
 * @param list
 */
export const getRandItemData = <T extends Record<string, any>>(list: T[]) => {
    return list[getRandomIndex(list.length)];
};

/**
 * 从列表中获取多个随机项组成一个新列表
 * @param list
 */
export const getRandListData = <T extends Record<string, any>>(list: T[]) => {
    const result: T[] = [];
    for (let i = 0; i < getRandomIndex(list.length); i++) {
        const random = getRandItemData<T>(list);
        if (!result.find((item) => item.id === random.id)) {
            result.push(random);
        }
    }
    return result;
};
```

### 模拟数据

然后编写一些想要的预定义数据

#### 类型

- `PostData`: 文章数据类型
- `CategoryData`: 分类数据类型
- `TagData`: 标签数据类型
- `ContentConfig`

```typescript
// src/database/factories/content.data.ts
export interface PostData {
    title: string;
    contentFile: string;
    summary?: string;
    category?: string;
    tags?: string[];
}

export interface CategoryData {
    name: string;
    children?: CategoryData[];
}

export interface TagData {
    name: string;
}

export interface ContentConfig {
    fixture?: {
        categories: CategoryData[];
        posts: PostData[];
    };
}
```

#### 内容

复制你克隆下来的本科源码的`src/assets/posts`目录到对应的目录中

![](https://img.pincman.com/media/202311170520701.png)

为了在编译后自动复制`src/assets`目录中的静态文件到`dist/assets`目录中，并且在开发环境中同时监测这些镜头文件的改变，需要修改一下`nest-cli.json`

```json
{
    "$schema": "https://json.schemastore.org/nest-cli",
    "collection": "@nestjs/schematics",
    "sourceRoot": "src",
    "compilerOptions": {
        "assets": ["assets/**/*"],
        "watchAssets": true,
        // ...
    }
}
```

#### 数据

添加一些明确的数据

```typescript
// src/database/factories/content.data.ts
export const posts: PostData[] = [
    {
        title: '基于角色和属性的Node.js访问控制',
        contentFile: 'rbac.md',
        category: '后端',
        tags: ['node'],
    },
    {
        title: 'docker简介',
        contentFile: 'docker-introduce.md',
        category: '运维',
        tags: ['devops'],
    },
    {
        title: 'go协程入门',
        contentFile: 'goroutings.md',
        category: '后端',
        tags: ['go'],
    },
    {
        title: '基于lerna.js构建monorepo',
        contentFile: 'lerna.md',
        category: '后端',
        tags: ['ts'],
    },
    {
        title: '通过PHP理解IOC编程',
        contentFile: 'php-di.md',
        category: '后端',
        tags: ['php'],
    },
    {
        title: '玩转React Hooks',
        contentFile: 'react-hooks.md',
        category: '前端',
        tags: ['react'],
    },
    {
        title: 'TypeORM fixtures cli中文说明',
        contentFile: 'typeorm-fixtures-cli.md',
        category: '后端',
        tags: ['ts', 'node'],
    },
    {
        title: '使用yargs构建node命令行(翻译)',
        contentFile: 'yargs.md',
        category: '后端',
        tags: ['ts', 'node'],
    },
    {
        title: 'Typescript装饰器详解',
        summary:
            '装饰器用于给类,方法,属性以及方法参数等增加一些附属功能而不影响其原有特性。其在Typescript应用中的主要作用类似于Java中的注解,在AOP(面向切面编程)使用场景下非常有用',
        contentFile: 'typescript-decorator.md',
        category: '基础',
        tags: ['ts'],
    },
];

export const categories: CategoryData[] = [
    {
        name: '技术文档',
        children: [
            {
                name: '基础',
            },
            {
                name: '前端',
            },
            {
                name: '后端',
            },
            {
                name: '运维',
            },
        ],
    },
    {
        name: '随笔记忆',
        children: [
            {
                name: '工作历程',
            },
            {
                name: '网站收藏',
            },
        ],
    },
];

export const tags: TagData[] = [
    {
        name: 'ts',
    },
    {
        name: 'react',
    },
    {
        name: 'node',
    },
    {
        name: 'go',
    },
    {
        name: 'php',
    },
    {
        name: 'devops',
    },
];
```

### 数据工厂

分类和标签不做数据工厂，我们为模块只定义一个文章表的数据工厂即可

```typescript
// src/database/factories/content.factory.ts
export type IPostFactoryOptions = Partial<{
    title: string;
    summary: string;
    body: string;
    isPublished: boolean;
    category: CategoryEntity;
    tags: TagEntity[];
    comments: CommentEntity[];
}>;
export const ContentFactory = defineFactory(
    PostEntity,
    async (configure: Configure, options: IPostFactoryOptions) => {
        const faker = new fakerjs.Faker({
            locale: await getFakerLocales(configure),
        });
        const post = new PostEntity();
        const { title, summary, body, category, tags } = options;
        post.title = title ?? faker.lorem.sentence(Math.floor(Math.random() * 10) + 6);
        if (summary) {
            post.summary = options.summary;
        }
        post.body = body ?? faker.lorem.paragraph(Math.floor(Math.random() * 500) + 1);
        post.publishedAt = (await getTime(configure)).toDate();
        if (Math.random() >= 0.5) {
            post.deletedAt = (await getTime(configure)).toDate();
        }
        if (category) {
            post.category = category;
        }
        if (tags) {
            post.tags = tags;
        }
        return post;
    },
);
```

### 填充实现

- `truncates`: 用于指定忽略锁定状态下会被清空的数据表模型
- `loadCategories`: 用于注入分类模拟数据
- `loadTags`: 用于注入标签模拟数据
- `loadPosts`: 用于注入文章模拟数据

注入文章模拟数据的步骤如下

1. 查出所有的分类和标签数据

2. 遍历预定义的文章数据
3. 以`body`的值为文件名称去读取对应的markdown文件中的文章内容，读取后作为`body`字段的内容
4. 查询出关联的分类和标签，然后使用工厂实例去创建这篇文章
5. 接着，通过`genRandomComments`为这边文章生成一些数据随机评论
6. 在预定义文章之外我们使用数据工厂生成几十条随机的文章

```typescript
// src/database/seeders/content.seeder.ts

export default class ContentSeeder extends BaseSeeder {
    protected truncates = [PostEntity, TagEntity, CategoryEntity, CommentEntity];

    protected factorier: DbFactory;

    async run(_factorier: DbFactory, _dataSource: DataSource, _em: EntityManager): Promise<any> {
        this.factorier = _factorier;
        await this.loadCategories(categories);
        await this.loadTags(tags);
        await this.loadPosts(posts);
    }

    private async genRandomComments(post: PostEntity, count: number, parent?: CommentEntity) {
        const comments: CommentEntity[] = [];
        for (let i = 0; i < count; i++) {
            const comment = new CommentEntity();
            comment.body = faker.lorem.paragraph(Math.floor(Math.random() * 18) + 1);
            comment.post = post;
            if (parent) comment.parent = parent;
            comments.push(await this.em.save(comment));
            if (Math.random() >= 0.8) {
                comment.children = await this.genRandomComments(
                    post,
                    Math.floor(Math.random() * 2),
                    comment,
                );
                await this.em.save(comment);
            }
        }
        return comments;
    }

    private async loadCategories(data: CategoryData[], parent?: CategoryEntity): Promise<void> {
        let order = 0;
        for (const item of data) {
            const category = new CategoryEntity();
            category.name = item.name;
            category.customOrder = order;
            if (parent) category.parent = parent;
            await this.em.save(category);
            order++;
            if (item.children) {
                await this.loadCategories(item.children, category);
            }
        }
    }

    private async loadTags(data: TagData[]): Promise<void> {
        for (const item of data) {
            const tag = new TagEntity();
            tag.name = item.name;
            await this.em.save(tag);
        }
    }

    private async loadPosts(data: PostData[]) {
        const allCategories = await this.em.find(CategoryEntity);
        const allTags = await this.em.find(TagEntity);
        for (const item of data) {
            const filePath = path.join(__dirname, '../../assets/posts', item.contentFile);
            if (!existsSync(filePath)) {
                panic({
                    spinner: this.spinner,
                    message: `post content file ${filePath} not exits!`,
                });
            }
            const options: IPostFactoryOptions = {
                title: item.title,
                body: fs.readFileSync(filePath, 'utf8'),
                isPublished: true,
            };
            if (item.summary) {
                options.summary = item.summary;
            }
            if (item.category) {
                options.category = await getCustomRepository(
                    this.dataSource,
                    CategoryRepository,
                ).findOneBy({ id: item.category });
            }
            if (item.tags) {
                options.tags = await getCustomRepository(this.dataSource, TagRepository).find({
                    where: { name: In(item.tags) },
                });
            }
            const post = await this.factorier(PostEntity)(options).create();

            await this.genRandomComments(post, Math.floor(Math.random() * 8));
        }
        await this.factorier(PostEntity)<IPostFactoryOptions>({
            tags: getRandListData(allTags),
            category: getRandItemData(allCategories),
        }).createMany(10);
    }
}
```

### 配置添加

最后，把我们的数据工厂类和数据填充类添加到数据库连接中即可

```typescript
// src/config/database.config.ts
export const database = createDbConfig((configure) => ({
    common: {
    },
    connections: [
        {
            //...
            factories: [ContentFactory],
            seeders: [ContentSeeder],
        },
    ],
}));
```

### 运行命令

尝试运行命令，看一下是否能注入模拟数据

![](https://img.pincman.com/media/202401301406413.png)

![](https://img.pincman.com/media/202401301407236.png)

从现在开始，我们不需要再使用`back`目录里的数据库文件了，需要与课程代码的数据同步，只需要运行

```bash
pnpm cli dbmr # 或者pnpm cli dbmg -r
pnpm cli dbs -i # i用于已锁定的迁移过的填充表，清空所有数据表重新生成
```

