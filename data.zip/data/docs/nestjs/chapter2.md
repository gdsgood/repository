---
title: 整合Typeorm实现CRUD
sidebar_label: Nestjs整合Typeorm实现基本的CRUD操作及分页数据查询
hide_title: true
sidebar_position: 4
---

:::tip
本课程在[Nestjs核心概念](./chapter1.md)这节课的基础上讲解,请务必先学习这节课
:::

## 预准备
在学习本节课之前请一定要阅读完毕以下文档，文档中写详细的内容不会再课程里重复

- [Typescript装饰器详解](https://3rcd.com/wiki/decorator)或[装饰器（旧语法）](https://wangdoc.com/typescript/decorator-legacy)(Nestjs目前暂不支持最新装饰器语法)
- [Typeorm官网文档](https://typeorm.io/)或者[Typeorm最新版中文文档](https://www.typeorm.org/)

## 学习目标
- 实现自定义Repoistory类
- 整合 Typeorm 与 Mysql 实现 Nestjs 对数据库的 CRUD 操作
- 实现数据分页查询

## 前置准备

### 依赖库

:::warning
前面部分的课程为了简单方便，使用sqlite数据库，后续换成mysql
:::

- typeorm一个TS编写的node.js ORM
- @nestjs/typeorm Nestjs的TypeOrm整合模块
- mysql2是Node的Mysql操作库
- [sanitize-html](https://github.com/apostrophecms/sanitize-html)过滤`html`标签,防注入攻击
- deepmerge是用于深度合并对象的一个库

```bash
pnpm add lodash better-sqlite3 typeorm @nestjs/typeorm sanitize-html deepmerge
pnpm add @types/sanitize-html -D
```

### 文件结构

```bash
├── app.module.ts
├── config
│   ├── database.config.ts
│   └── index.ts
├── main.ts
└── modules
    ├── content
    │   ├── constants.ts
    │   ├── content.module.ts
    │   ├── controllers
    │   │   ├── index.ts
    │   │   └── post.controller.ts
    │   ├── entities
    │   │   ├── index.ts
    │   │   └── post.entity.ts
    │   ├── repositories
    │   │   ├── index.ts
    │   │   └── post.repository.ts
    │   ├── services
    │   │   ├── index.ts
    │   │   ├── post.service.ts
    │   │   └── sanitize.service.ts
    │   └── subscribers
    │       ├── index.ts
    │       └── post.subscriber.ts
    ├── core
    │   ├── core.module.ts
    │   └── helpers
    │       ├── index.ts
    │       └── utils.ts
    └── database
        ├── constants.ts
        ├── database.module.ts
        ├── decorators
        │   ├── index.ts
        │   └── repository.decorator.ts
        ├── helpers.ts
        └── types.ts
```

### 请求周期图

一个简单的数据库操作的Nestjs应用从请求到响应的流程图如下

![](https://img.pincman.com/media/202306141920318.png)

## 代码编写

删除原来`CoreModule`和`ExampleModule`和其它一些无用的文件，并重新创建一个新的`CoreModule`，然后创建一个`DatabaseModule`

```bash
rm -rf src/modules/core src/modules/example src/modules/content/types.ts src/modules/content/dtos src/app.controller.spec.ts src/app.controller.ts src/app.service.ts
nest g mo modules/core
nest g mo modules/database
```

### 核心编码
修改模块代码如下

```typescript
// src/modules/core/core.module.ts
@Module({})
export class CoreModule {
    static forRoot(): DynamicModule {
        return {
            module: CoreModule,
            global: true,
            providers: [],
            exports: [],
        };
    }
}

// src/main.ts
import { ContentModule } from './modules/content/content.module';
import { CoreModule } from './modules/core/core.module';
import { DatabaseModule } from './modules/database/database.module';

@Module({
    imports: [ContentModule, CoreModule.forRoot(), DatabaseModule],
})
export class AppModule {}
```

添加几个有用的工具函数

```typescript
// src/modules/core/helpers/utils.ts
import deepmerge from 'deepmerge';
import { isNil } from 'lodash';

/**
 * 用于请求验证中的boolean数据转义
 * @param value
 */
export function toBoolean(value?: string | boolean): boolean {
    if (isNil(value)) return false;
    if (typeof value === 'boolean') return value;
    try {
        return JSON.parse(value.toLowerCase());
    } catch (error) {
        return value as unknown as boolean;
    }
}

/**
 * 用于请求验证中转义null
 * @param value
 */
export function toNull(value?: string | null): string | null | undefined {
    return value === 'null' ? null : value;
}

/**
 * 深度合并对象
 * @param x 初始值
 * @param y 新值
 * @param arrayMode 对于数组采取的策略,`replace`为直接替换,`merge`为合并数组
 */
export const deepMerge = <T1, T2>(
    x: Partial<T1>,
    y: Partial<T2>,
    arrayMode: 'replace' | 'merge' = 'merge',
) => {
    const options: deepmerge.Options = {};
    if (arrayMode === 'replace') {
        options.arrayMerge = (_d, s, _o) => s;
    } else if (arrayMode === 'merge') {
        options.arrayMerge = (_d, s, _o) => Array.from(new Set([..._d, ...s]));
    }
    return deepmerge(x, y, options) as T2 extends T1 ? T1 : T1 & T2;
};
```

在 index.ts 中导出 utils.ts里面的函数，因为目前我们使用的是 CommonJS 模式(nestjs目前不支持ESM)。所以后续直接可以使用导入`helpers`目录的方法来导入这些在子文件中导出的东西

:::warning

注意：后续课程大部分TS文件都是遵循从其相邻的`index.ts`中导出以方便其它地方通过目录路径导入的规则，不会再重复提示，除非一些特殊情况不能这样做才会指明

:::

```typescript
// src/modules/core/helpers/index.ts
export * from './utils';
```

### 数据库模块
本模块就是用来连接数据库以及编写一些数据库操作需要的东西

### 创建数据库

因为我们使用的是`sqlite`，所以需要创建一个数据库文件

```bash
touch database.db
```

为了数据调试方便，建议把我在课程中已经生成好数据的数据库文件(在`back`目录下)搬迁到根目录下，并重命名为`database.db`

:::tip

`database4.db`代表从第四节课（比如本节课是`database2.db`）开始的数据库，如果后续课程有新数据，比如第六节有新的数据结构，则会有`database6.db`。但前后两节课数据相同，比如第四节如果和第五节相同，就不会有`dabtabase5.db`，继续沿用第四节的就行。另外，后续课程从全文搜索开始的章节切换到mysql，所以不再有此文件

:::

:::info
请在每次复制课程代码中的`databasex.db`到你自己的应用时，务必执行`pnpm rebuild`，否则无法启动应用
:::

![](https://img.pincman.com/media/202309231639904.png)

#### 数据库连接

首先我们写一些接口和类型，先不必去管他干嘛用的，后面会用到，看注释知道个大概

```typescript
// src/modules/database/types.ts
import { ObjectLiteral, SelectQueryBuilder } from 'typeorm';

export type QueryHook<Entity> = (
    qb: SelectQueryBuilder<Entity>,
) => Promise<SelectQueryBuilder<Entity>>;

/**
 * 分页原数据
 */
export interface PaginateMeta {
    /**
     * 当前页项目数量
     */
    itemCount: number;
    /**
     * 项目总数量
     */
    totalItems?: number;
    /**
     * 每页显示数量
     */
    perPage: number;
    /**
     * 总页数
     */
    totalPages?: number;
    /**
     * 当前页数
     */
    currentPage: number;
}

/**
 * 分页选项
 */
export interface PaginateOptions {
    /**
     * 当前页数
     */
    page?: number;
    /**
     * 每页显示数量
     */
    limit?: number;
}

/**
 * 分页返回数据
 */
export interface PaginateReturn<E extends ObjectLiteral> {
    meta: PaginateMeta;
    items: E[];
}
```

接下来我们编写`DatabaseModule`模块，用来连接数据库
这里我们通过动态模块的方式来传入配置，可以看到我们使用了传入配置函数的方式而不是直接传入配置。这是因为直接传入静态配置会导致出现很多问题，比如后面的环境变量读取等，这对我们后续的配置系统这些课程会有一个理解上的帮助

```typescript
// src/modules/database/database.module.ts
import { DynamicModule, Module } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';

@Module({})
export class DatabaseModule {
    static forRoot(configRegister: () => TypeOrmModuleOptions): DynamicModule {
        return {
            global: true,
            module: DatabaseModule,
            imports: [TypeOrmModule.forRoot(configRegister())],
        };
    }
}
```

接下来我们编写一个配置文件，请注意

- 配置中必须设置`synchronize`为`true`，因为我们目前没有涉及到数据迁移的命令编写，所以必须在启动数据库时自动根据加载的模型(Entity)来同步数据表到数据库
- 配置中必须设置`autoLoadEntities`为`true`，这样我们就不需要把每个模块的`Entity`逐个定死地添加到配置中的`entities`数组中了，因为你可以在每个模块中使用`TypeOrmModule.forFeature`来动态的加入`Entity`

:::tip

再一次提醒：为了方便导入，请创建`src/config/index.ts`文件，并在该文件中编写导出`export * from './database.config';`

:::

```typescript
// src/config/database.config.ts
/**
 * 数据库配置
 */
import { resolve } from 'path';

import { TypeOrmModuleOptions } from '@nestjs/typeorm';

export const database = (): TypeOrmModuleOptions => ({
    type: 'better-sqlite3',
    database: resolve(__dirname, '../../database.db'),
    synchronize: true,
    autoLoadEntities: true,
});
```

然后我们在`AppModule`中通过`forRoot`传入配置并注册数据库模块即可，这样应用在启动时会根据模块(Entity)自动同步数据结构并连接数据库

```typescript
// src/app.module.ts
// ...
import { database } from './config';

@Module({
    imports: [
        ContentModule,
        CoreModule.forRoot(),
        DatabaseModule.forRoot(database),
    ],
    providers: [],
})
export class AppModule {}
```

#### 自定义Repository
因为我们使用的是**DataMapper**(类似symfony框架使用的Doctrine或者Java的Hibernate)与**ActiveRecord**(类似laravel的Eloquent或者ROR)混合的方式来编写数据操作。
Typeorm也支持两种方式随意切换，所以我们需要把Typeorm v0.3 以后版本取消掉的通过类自定义方法来自定义`Repository`的模式给复现出来，有了类我们才能把自定义的`Repository`注入到服务等其它地方进行数据操作
首先定义一个常量，用于存储自定义的Repository绑定的模型

```typescript
// src/modules/database/constants.ts
export const CUSTOM_REPOSITORY_METADATA = 'CUSTOM_REPOSITORY_METADATA';
```

在`DatabaseModule`中编写一个静态方法，用于把自定义的Repository类注册为提供者

- 这个静态函数将会接受一个自定义的Repository类列表以及数据库连接名称(我们目前只有一个连接,所以不需要传入,因为默认就连`default`)
- 遍历每个自定义的Repository类判断是否有通过`CUSTOM_REPOSITORY_METADATA`常量存储的模型，如果没有则忽略，因为这个类不是自定义Repository
- 如果有，那么首先我们获取数据库连接实例，然后注入到`useFactory`里面生成一个自定义的Repository实例并返回为提供者，其内部是先通过数据库连接实例(`dataSource`)生成这个模型的默认`Repsitory`实例，然后默认Repository的构造函数需要的参数通过默认的Repository实例获取，并传入到你自定义的Repository类的构造函数中以生成新的实例(自定义的Repository必须继承默认Repository，所以它们的构造函数参数是相同的)
- 最后把返回的所有自定义Repository类实例全部注册为`DatabaseModule`的提供者并通过`exports`导出

```typescript
// src/modules/database/database.module.ts

@Module({})
export class DatabaseModule {
    // ...
    static forRepository<T extends Type<any>>(
        repositories: T[],
        dataSourceName?: string,
    ): DynamicModule {
        const providers: Provider[] = [];

        for (const Repo of repositories) {
            const entity = Reflect.getMetadata(CUSTOM_REPOSITORY_METADATA, Repo);

            if (!entity) {
                continue;
            }

            providers.push({
                inject: [getDataSourceToken(dataSourceName)],
                provide: Repo,
                useFactory: (dataSource: DataSource): InstanceType<typeof Repo> => {
                    const base = dataSource.getRepository<ObjectType<any>>(entity);
                    return new Repo(base.target, base.manager, base.queryRunner);
                },
            });
        }
        return {
            exports: providers,
            module: DatabaseModule,
            providers,
        };
    }
}
```

为了通过常量`CUSTOM_REPOSITORY_METADATA`来存储模型，我们还需要写一个装饰器来放置metadata

```typescript
// src/modules/database/decorators/repository.decorator.ts
export const CustomRepository = <T>(entity: ObjectType<T>): ClassDecorator =>
    SetMetadata(CUSTOM_REPOSITORY_METADATA, entity);
```

#### 分页函数
定义一个使用queryBuilder的分页函数，用于对文章进行分页

函数实现如下:
因为`offset`+`limit`会出现一些问题(比如导致一些查找对象消失等)，所以我们使用`take`+`skip`来实现分页。关于`QueryBuilder`的使用请自行查看typeorm的官方文档，这里就不做过多赘述了

```typescript
// src/modules/database/helpers.ts
/**
 * 分页函数
 * @param qb queryBuilder实例
 * @param options 分页选项
 */
export const paginate = async <E extends ObjectLiteral>(
    qb: SelectQueryBuilder<E>,
    options: PaginateOptions,
): Promise<PaginateReturn<E>> => {
    const limit = isNil(options.limit) || options.limit < 1 ? 1 : options.limit;
    const page = isNil(options.page) || options.page < 1 ? 1 : options.page;
    const start = page >= 1 ? page - 1 : 0;
    const totalItems = await qb.getCount();
    qb.take(limit).skip(start * limit);
    const items = await qb.getMany();
    const totalPages =
        totalItems % limit === 0
            ? Math.floor(totalItems / limit)
            : Math.floor(totalItems / limit) + 1;
    const remainder = totalItems % limit !== 0 ? totalItems % limit : limit;
    const itemCount = page < totalPages ? limit : remainder;
    return {
        items,
        meta: {
            totalItems,
            itemCount,
            perPage: limit,
            totalPages,
            currentPage: page,
        },
    };
};
```

### 内容模块
下面我们还是编写我们本节课的功能代码
编写流程如下

:::info

后续大多数数据操作模块的编码流程类似

:::

1. 编写Entity模型
2. 编写Repository
3. 编写订阅者(如果有需要)
4. 编写DTO验证类(本节课没有涉及)
5. 编写服务类用于数据操作
6. 编写控制器
7. 在逻辑模块中注册提供者(包括服务类，订阅者等)以及控制器，Entity，Repository
8. 在`AppModule`中导入逻辑模块
#### 常量
在编写正式代码之前我们先添加几个常量

```typescript
// src/modules/content/constants.ts
 /**
 * 文章内容类型
 */
export enum PostBodyType {
    HTML = 'html',
    MD = 'markdown',
}

/**
 * 文章排序类型
 */
export enum PostOrderType {
    CREATED = 'createdAt',
    UPDATED = 'updatedAt',
    PUBLISHED = 'publishedAt',
    CUSTOM = 'custom',
}
```

#### 模型

:::caution

删除原来的`types.ts`文件，因为里面写了个虚拟的`PostEntity`类型

:::

TypeORM中模型就是所谓的Entity类，编写方法如下

- `@Entity`装饰器中的`'content_posts'`代表数据表的名称
- `@CreateDateColumn`与`@UpdateDateColumn`是由TypeORM自动维护的字段，用于数据创建和更新时间，我们后面讲到软删除还会使用到`@DeleteDateColumn`，这也是有TypeORM自动维护的
- 其它字段可以参考`comment`中的注释

```typescript
// src/modules/content/entities/post.entity.ts
@Entity('content_posts')
export class PostEntity extends BaseEntity {
    @PrimaryColumn({ type: 'varchar', generated: 'uuid', length: 36 })
    id: string;

    @Column({ comment: '文章标题' })
    title: string;

    @Column({ comment: '文章内容', type: 'text' })
    body: string;

    @Column({ comment: '文章描述', nullable: true })
    summary?: string;

    @Expose()
    @Column({ comment: '关键字', type: 'simple-array', nullable: true })
    keywords?: string[];

    @Column({
        comment: '文章类型',
        type: 'varchar',
        // 如果是mysql或者postgresql你可以使用enum类型
        // enum: PostBodyType,
        default: PostBodyType.MD,
    })
    type: PostBodyType;

    @Column({
        comment: '发布时间',
        type: 'varchar',
        nullable: true,
    })
    publishedAt?: Date | null;

    @Column({ comment: '自定义文章排序', default: 0 })
    customOrder: number;

    @CreateDateColumn({
        comment: '创建时间',
    })
    createdAt: Date;

    @UpdateDateColumn({
        comment: '更新时间',
    })
    updatedAt: Date;
}
```

#### Repostitory
前面我们编写了自定义Repository的注册函数，下面我们就编写一个自定义的Repository

```typescript
// src/modules/content/repositories/post.repository.ts
@CustomRepository(PostEntity)
export class PostRepository extends Repository<PostEntity> {
    buildBaseQB() {
        return this.createQueryBuilder('post');
    }
}
```

可以看到非常简单，我们的自定义Repository继承自默认的Repository，并为默认的Repository传入模型作为泛型，并且在顶部加上了前面编写的`CustomRepository`装饰器以存储`PostEntity`模型
同时我们添加了一个用户构建基础的查询器的`buildBaseQB`方法，此方法将会在后续课程发挥更大的作用
#### **防注入处理**

:::tip

一般站长个人编写的应用不喜欢纯HTML的内容，只用Markdown。所以这部分内容后续可能删除，但是此处请务必学习！

:::

为了数据安全，我们编写一个额外的服务，使用[sanitize-html](https://github.com/apostrophecms/sanitize-html)对危险的html标签进行过滤，用来防止xss(跨站脚本)攻击

```typescript
// src/modules/content/services/sanitize.service.ts
import sanitizeHtml from 'sanitize-html';

import { deepMerge } from '@/modules/core/helpers';

@Injectable()
export class SanitizeService {
    protected config: sanitizeHtml.IOptions = {};

    constructor() {
        this.config = {
            allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img', 'code']),
            allowedAttributes: {
                ...sanitizeHtml.defaults.allowedAttributes,
                '*': ['class', 'style', 'height', 'width'],
            },
            parser: {
                lowerCaseTags: true,
            },
        };
    }

    sanitize(body: string, options?: sanitizeHtml.IOptions) {
        return sanitizeHtml(body, deepMerge(this.config, options ?? {}, 'replace'));
    }
}
```

#### 订阅者
订阅者的作用在于可以在CRUD(创建,查询,更新,删除)数据时创建一个钩子方法来执行额外的操作
比如这个`PostSubscriber`钩子可以让我们在查询文章时对HTML类型的文章内容进行防注入处理

- 在订阅制中需要使用到依赖注入，不需要额外添加`@Injectable()`装饰器。只要把它放到模块的`providers`里面即可
- 这里加了`dataSource.subscribers.push(this)`是因为需要把我们的订阅者类放入数据库连接池才会生效

```typescript
// src/modules/content/subscribers/post.subscriber.ts
@EventSubscriber()
export class PostSubscriber {
    constructor(
        protected dataSource: DataSource,
        protected sanitizeService: SanitizeService,
        protected postRepository: PostRepository,
    ) {
        dataSource.subscribers.push(this);
    }

    listenTo() {
        return PostEntity;
    }

    /**
     * 加载文章数据的处理
     * @param entity
     */
    async afterLoad(entity: PostEntity) {
        if (entity.type === PostBodyType.HTML) {
            entity.body = this.sanitizeService.sanitize(entity.body);
        }
    }
}
```

#### 服务类

修改原来的`PostService`

我们一般不会通过控制器来直接操作数据，而是通过服务来通过DataMapper或ActiveRecord模式对数据进行操作
可以看到我们前面定义的`IPaginateDto`接口在此处查询分页的方法中就可以作为类型提示了，另外通过`QueryHook`类型提示的`callback`回调函数参数还能用于添加自定义的`query`查询链，下面逐个分析一下

- `paginate`方法用于查询文章列表,并以分页的形式返回数据
- `detail`方法用于查询一篇文章的详情
- `create`,`update`,`delete`方法分别用于创建，更新和删除文章

这里我们重点来看一下`buildListQuery`这个非公开方法，此方法的作用在于

- 如果传入的`isPublished`值是一个布尔值(默认为`undefined`)则会根据是否为真来确定是否只查询发布或未发布的文章,默认查询所有文章
- 添加一个排序功能，可以根据自定义的`customOrder`字段排序，也可以根据文章的创建时间，更新时间或发布时间排序，默认为综合排序
- 同时如果有传入自定义的查询回调，还回执行以下查询回调返回一个新的查询器

```typescript
// src/modules/content/services/post.service.ts
@Injectable()
export class PostService {
    constructor(protected repository: PostRepository) {}

    /**
     * 获取分页数据
     * @param options 分页选项
     * @param callback 添加额外的查询
     */
    async paginate(options: PaginateOptions, callback?: QueryHook<PostEntity>) {
        const qb = await this.buildListQuery(this.repository.buildBaseQB(), options, callback);
        return paginate(qb, options);
    }

    /**
     * 查询单篇文章
     * @param id
     * @param callback 添加额外的查询
     */
    async detail(id: string, callback?: QueryHook<PostEntity>) {
         let qb = this.repository.buildBaseQB();
        qb.where(`post.id = :id`, { id });
        qb = !isNil(callback) && isFunction(callback) ? await callback(qb) : qb;
        const item = await qb.getOne();
        if (!item) throw new EntityNotFoundError(PostEntity, `The post ${id} not exists!`);
        return item;
    }

    /**
     * 创建文章
     * @param data
     */
    async create(data: Record<string, any>) {
        const item = await this.repository.save(data);

        return this.detail(item.id);
    }

    /**
     * 更新文章
     * @param data
     */
    async update(data: Record<string, any>) {
        await this.repository.update(data.id, omit(data, ['id']));
        return this.detail(data.id);
    }

    /**
     * 删除文章
     * @param id
     */
    async delete(id: string) {
        const item = await this.repository.findOneByOrFail({ id });
        return this.repository.remove(item);
    }

    /**
     * 构建文章列表查询器
     * @param qb 初始查询构造器
     * @param options 排查分页选项后的查询选项
     * @param callback 添加额外的查询
     */
    protected async buildListQuery(
        qb: SelectQueryBuilder<PostEntity>,
        options: Record<string, any>,
        callback?: QueryHook<PostEntity>,
    ) {
        const { orderBy, isPublished } = options;
        if (typeof isPublished === 'boolean') {
            isPublished
                ? qb.where({
                      publishedAt: Not(IsNull()),
                  })
                : qb.where({
                      publishedAt: IsNull(),
                  });
        }
        this.queryOrderBy(qb, orderBy);
        if (callback) return callback(qb);
        return qb;
    }

    /**
     *  对文章进行排序的Query构建
     * @param qb
     * @param orderBy 排序方式
     */
    protected queryOrderBy(qb: SelectQueryBuilder<PostEntity>, orderBy?: PostOrderType) {
        switch (orderBy) {
            case PostOrderType.CREATED:
                return qb.orderBy('post.createdAt', 'DESC');
            case PostOrderType.UPDATED:
                return qb.orderBy('post.updatedAt', 'DESC');
            case PostOrderType.PUBLISHED:
                return qb.orderBy('post.publishedAt', 'DESC');
            case PostOrderType.CUSTOM:
                return qb.orderBy('customOrder', 'DESC');
            default:
                return qb
                    .orderBy('post.createdAt', 'DESC')
                    .addOrderBy('post.updatedAt', 'DESC')
                    .addOrderBy('post.publishedAt', 'DESC');
        }
    }
}
```

#### 控制器

修改原来的`PostController`,**这里我们暂时先不用《核心概念》这一节讲的DTO验证，后续课程再重新加上**

本节的控制器非常简单，只要注入服务类并调用里面的方法即可

```typescript
// src/modules/content/controllers/post.controller.ts
@Controller('posts')
export class PostController {
    constructor(protected service: PostService) {}

    @Get()
    async list(
        @Query()
        options: PaginateOptions,
    ) {
        return this.service.paginate(options);
    }

    @Get(':id')
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }

    @Post()
    async store(
        @Body()
        data: Record<string, any>,
    ) {
        return this.service.create(data);
    }

    @Patch()
    async update(
        @Body()
        data: Record<string, any>,
    ) {
        return this.service.update(data);
    }

    @Delete(':id')
    async delete(@Param('id', new ParseUUIDPipe()) id: string) {
        return this.service.delete(id);
    }
}
```

#### 模块编写

- 在`imports`通过`TypeOrmModule.forFeature`方法加载Entity，正如前面所配置的`synchronize`和`autoLoadEntities`属性预想的那样，这就可以生成并不断同步我们的数据表结构
- 在`imports`中使用我们前面定义的`forRepository`静态方法来注册我们自定义的Repository为提供者
- 把控制器放入`controllers`中
- 把`PostService`以及`PostSubscriber`注册成为提供者
- 最后在`exports`中导出`PostService`以及`DatabaseModule.forRepository([PostRepository])`(一定要包着模块导出，因为他是在`DatabaseModule`中注册的提供者)，以备其它模块导入使用

```typescript
// src/modules/content/content.module.ts
// ...
import { PostController } from './controllers';
import { PostEntity } from './entities';
import { PostRepository } from './repositories';
import { PostService, SanitizeService } from './services';
import { PostSubscriber } from './subscribers';

@Module({
    imports: [
        TypeOrmModule.forFeature([PostEntity]),
        DatabaseModule.forRepository([PostRepository]),
    ],
    controllers: [PostController],
    providers: [PostService, PostSubscriber, SanitizeService],
    exports: [PostService, DatabaseModule.forRepository([PostRepository])],
})
export class ContentModule {}
```

最后把`ContentModule`导入到`AppModule`即可启动应用进行调试

## 调试应用

:::tip

除了[insomnia](https://insomnia.rest/download)外，其它的接口测试工具有很多，比如vscode的[thunder client](https://www.thunderclient.com/)插件、[hoppscotch.io](https://hoppscotch.io/)、国产的[foxapi](https://apifox.com/)等。根据你自己的喜好选择即可！

:::

一、通过`pnpm start:dev`命令启动应用

二、下载[insomnia](https://insomnia.rest/download)

三、把`back`目录中的`insomnia-2.json`（与课程的关联规则与`database{x}.db`一样）导入到`insomnia`中即可测试应用的接口

![image-20230823131115565](https://img.pincman.com/media/202308231311865.png)

![](https://img.pincman.com/media/202309231714062.png)
