---
title: 基于CASL的RBAC动态角色及权限系统实现
sidebar_label: 动态角色及权限系统实现
hide_title: true
sidebar_position: 19
---

## 前置准备

### 学习目标

- 实现模型间的动态关联
- 掌握TypeORM事务构建
- 深入了解Nestjs模块的生命周期以及ModuleRef的灵活运用
- 编写一个用于存储动态权限与角色的RBAC模块
- 实现websocket和Http的权限验证守卫
- 实现CRUD框架的RBAC装饰器
- 实现基于CASL的动态权限验证
- 分离应用的前后台API

### 流程图

![](https://img.pincman.com/media202210101700584.png)

### 依赖解析

```typescript
pnpm add @casl/ability
```

### 文件结构

## RBAC模块

### 模型

#### 权限模型

```typescript
// src/modules/rbac/entities/permission.entity.ts
@Exclude()
@Entity('rbac_permissions')
export class PermissionEntity<
    A extends AbilityTuple = AbilityTuple,
    C extends MongoQuery = MongoQuery,
> {
    @Expose()
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Expose()
    @Column({ comment: '权限名称' })
    name: string;

    @Expose()
    @Column({ comment: '权限显示名', nullable: true })
    label?: string;

    @Expose()
    @Column({
        comment: '权限描述',
        type: 'text',
        nullable: true,
    })
    description?: string;

    @Expose()
    @Column({ type: 'simple-json', comment: '权限规则' })
    rule: Omit<RawRuleFrom<A, C>, 'conditions'>;

    @Expose({ groups: ['permission-list', 'permission-detail'] })
    @ManyToMany((type) => RoleEntity, (role) => role.permissions)
    @JoinTable()
    roles: Relation<RoleEntity>[];

    @ManyToMany(() => UserEntity, (user: any) => user.permissions)
    @JoinTable()
    users: Relation<UserEntity>[];
}
```

#### 角色模型

```typescript
// src/modules/rbac/entities/role.entity.ts
@Exclude()
@Entity('rbac_roles')
export class RoleEntity extends BaseEntity {
    @Expose()
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Expose()
    @Column({
        comment: '角色名称',
    })
    name: string;

    @Expose()
    @Column({ comment: '显示名称', nullable: true })
    label?: string;

    @Expose()
    @Column({
        comment: '角色描述',
        type: 'text',
        nullable: true,
    })
    description?: string;

    @Column({ comment: '是否为不可更改的系统权限', default: false })
    systemed?: boolean;

    @Expose({ groups: ['role-detail', 'role-list'] })
    @Expose()
    @Type(() => Date)
    @DeleteDateColumn({
        comment: '删除时间',
    })
    deletedAt: Date;

    @Expose({ groups: ['role-detail'] })
    @Type(() => PermissionEntity)
    @ManyToMany(() => PermissionEntity, (permission) => permission.roles, {
        cascade: true,
        eager: true,
    })
    permissions: Relation<PermissionEntity>[];

    @ManyToMany(() => UserEntity, (user: any) => user.roles, { deferrable: 'INITIALLY IMMEDIATE' })
    @JoinTable()
    users: Relation<UserEntity>[];
}
```

#### 用户关联

```typescript
// src/modules/user/entities/user.entity.ts
/**
 * 用户模型
 */
@Exclude()
@Entity('users')
export class UserEntity {
    // ...

    @Expose()
    @ManyToMany(() => RoleEntity, (role) => role.users, { cascade: true })
    roles: Relation<RoleEntity>[];

    @Expose()
    @ManyToMany(() => PermissionEntity, (permisson) => permisson.users, {
        cascade: true,
    })
    permissions: Relation<PermissionEntity>[];
}
```

### 存储类

```typescript
// src/modules/rbac/repositories/permission.repository.ts
@CustomRepository(PermissionEntity)
export class PermissionRepository extends BaseRepository<PermissionEntity> {
    protected _qbName = 'permission';

    buildBaseQuery() {
        return this.createQueryBuilder(this.qbName).leftJoinAndSelect(
            `${this.qbName}.roles`,
            'roles',
        );
    }
}

// src/modules/rbac/repositories/role.repository.ts
@CustomRepository(RoleEntity)
export class RoleRepository extends BaseRepository<RoleEntity> {
    protected _qbName = 'role';

    buildBaseQuery() {
        return this.createQueryBuilder(this.qbName).leftJoinAndSelect(
            `${this.qbName}.permissions`,
            'permssions',
        );
    }
}
```

### 订阅者

```typescript
// src/modules/rbac/subscribers/permission.subscriber.ts
@EventSubscriber()
export class PermssionSubscriber extends BaseSubscriber<PermissionEntity> {
    protected entity = PermissionEntity;

    async afterLoad(entity: PermissionEntity) {
        if (isNil(entity.label)) {
            entity.label = entity.name;
        }
    }
}

// src/modules/rbac/subscribers/role.subscriber.ts
@EventSubscriber()
export class RoleSubscriber extends BaseSubscriber<RoleEntity> {
    protected entity = RoleEntity;

    async afterLoad(entity: RoleEntity) {
        if (isNil(entity.label)) {
            entity.label = entity.name;
        }
    }
}
```

### 数据验证

#### 权限操作

```typescript
// src/modules/rbac/dtos/permission.dto.ts
@DtoValidation({ type: 'query' })
export class QueryPermssionDto extends PaginateDto {
    /**
     * 角色ID:通过角色过滤权限列表
     */
    @IsDataExist(RoleEntity, {
        groups: ['update'],
        message: '指定的角色不存在',
    })
    @IsUUID(undefined, { message: '角色ID格式错误' })
    @IsOptional()
    role?: string;
}
```

#### 角色操作

```typescript
// src/modules/rbac/dtos/role.dto.ts
export class QueryRoleDto extends PaginateWithTrashedDto {
    /**
     * 用户ID:通过用户过滤角色列表
     */
    @IsDataExist(UserEntity, {
        groups: ['update'],
        message: '指定的用户不存在',
    })
    @IsUUID(undefined, { message: '用户ID格式错误' })
    @IsOptional()
    user?: string;
}

@DtoValidation({ groups: ['create'] })
export class CreateRoleDto {
    /**
     * 权限名称
     */
    @MaxLength(100, {
        always: true,
        message: '名称长度最大为$constraint1',
    })
    @IsNotEmpty({ groups: ['create'], message: '名称必须填写' })
    @IsOptional({ groups: ['update'] })
    name: string;

    /**
     * 权限标识:如果没有设置则在查询后为权限名称
     */
    @MaxLength(100, {
        always: true,
        message: 'Label长度最大为$constraint1',
    })
    @IsOptional({ always: true })
    label?: string;

    /**
     * 关联权限ID列表:一个角色可以关联多个权限,一个权限也可以属于多个角色
     */
    @IsDataExist(PermissionEntity, {
        each: true,
        always: true,
        message: '权限不存在',
    })
    @IsUUID(undefined, {
        each: true,
        always: true,
        message: '权限ID格式不正确',
    })
    @IsOptional({ always: true })
    permissions?: string[];
}

@DtoValidation({ groups: ['update'] })
export class UpdateRoleDto extends PartialType(CreateRoleDto) {
    /**
     * 待更新的角色ID
     */
    @IsUUID(undefined, { groups: ['update'], message: 'ID格式错误' })
    @IsDefined({ groups: ['update'], message: 'ID必须指定' })
    id: string;
}
```

### 服务类

#### 权限服务

```typescript
type FindParams = {
    [key in keyof Omit<QueryPermssionDto, 'limit' | 'page'>]: QueryPermssionDto[key];
};

@Injectable()
export class PermissionService extends BaseService<
    PermissionEntity,
    PermissionRepository,
    FindParams
> {
    constructor(protected permissionRepository: PermissionRepository) {
        super(permissionRepository);
    }

    protected async buildListQuery(
        queryBuilder: SelectQueryBuilder<PermissionEntity>,
        options: FindParams,
        callback?: QueryHook<PermissionEntity>,
    ) {
        const qb = await super.buildListQB(queryBuilder, options, callback);
        if (!isNil(options.role)) {
            qb.andWhere('roles.id IN (:...roles)', {
                roles: [options.role],
            });
        }
        return qb;
    }
}
```

#### 角色服务

```typescript
@Injectable()
export class RoleService extends BaseService<RoleEntity, RoleRepository> {
    protected enable_trash = true;

    constructor(
        protected roleRepository: RoleRepository,
        protected permissionRepository: PermissionRepository,
    ) {
        super(roleRepository);
    }

    async create(data: CreateRoleDto) {
        const createRoleDto = {
            ...data,
            permissions: data.permissions
                ? await this.permissionRepository.findBy({
                      id: In(data.permissions),
                  })
                : [],
        };
        const item = await this.repository.save(createRoleDto);
        return this.detail(item.id);
    }

    async update(data: UpdateRoleDto) {
        const role = await this.detail(data.id);
        if (data.permissions) {
            await this.repository
                .createQueryBuilder('role')
                .relation(RoleEntity, 'permissions')
                .of(role)
                .addAndRemove(data.permissions, role.permissions ?? []);
        }
        await this.repository.update(data.id, omit(data, ['id', 'permissions']));
        return this.detail(data.id);
    }

    /**
     * 删除数据
     * @param items
     * @param trash
     */
    async delete(items: string[], trash = true) {
        const roles = await this.repository.find({
            where: { id: In(items) },
            withDeleted: true,
        });
        for (const role of roles) {
            if (role.systemed) {
                throw new ForbiddenException('can not remove systemed role!');
            }
        }
        if (!trash) this.repository.remove(roles);
        const directs = roles.filter((item) => !isNil(item.deletedAt));
        const softs = roles.filter((item) => isNil(item.deletedAt));

        return [
            ...(await this.repository.remove(directs)),
            ...(await this.repository.softRemove(softs)),
        ];
    }

    protected async buildListQuery(
        queryBuilder: SelectQueryBuilder<RoleEntity>,
        options: QueryRoleDto,
        callback?: QueryHook<RoleEntity>,
    ) {
        const qb = await super.buildListQB(queryBuilder, options, callback);
        qb.leftJoinAndSelect(`${this.repository.qbName}.users`, 'users');
        if (!isNil(options.user)) {
            qb.andWhere('users.id IN (:...users)', {
                roles: [options.user],
            });
        }
        return qb;
    }
}
```

### 同步处理器

#### 常量

```typescript
// src/modules/rbac/constants.ts
export enum SystemRoles {
    USER = 'user',
    SUPER_ADMIN = 'super-admin',
}
```

#### 类型

```typescript
// src/modules/rbac/types.ts
export type Role = Pick<ClassToPlain<RoleEntity>, 'name' | 'label' | 'description'> & {
    permissions: string[];
};
export type PermissionType<A extends AbilityTuple, C extends MongoQuery> = Pick<
    ClassToPlain<PermissionEntity<A, C>>,
    'name'
> &
    Partial<Pick<ClassToPlain<PermissionEntity<A, C>>, 'label' | 'description'>> & {
        rule: Omit<RawRuleFrom<A, C>, 'conditions'> & {
            conditions?: (user: ClassToPlain<UserEntity>) => Record<string, any>;
        };
    };

```

#### 处理类

```typescript
// src/modules/rbac/rbac.resolver.ts
const getSubject = <S extends SubjectType>(subject: S) => {
    if (typeof subject === 'string') return subject;
    if (subject.modelName) return subject;
    return subject.name;
};
@Injectable()
export class RbacResolver<A extends AbilityTuple = AbilityTuple, C extends MongoQuery = MongoQuery>
    implements OnApplicationBootstrap
{
    protected setuped = false;

    protected options: AbilityOptions<A, C>;

    protected _roles: Role[] = [
        {
            name: SystemRoles.USER,
            label: '普通用户',
            description: '新用户的默认角色',
            permissions: [],
        },
        {
            name: SystemRoles.SUPER_ADMIN,
            label: '超级管理员',
            description: '拥有整个系统的管理权限',
            permissions: [],
        },
    ];

    protected _permissions: PermissionType<A, C>[] = [
        {
            name: 'system-manage',
            label: '系统管理',
            description: '管理系统的所有功能',
            rule: {
                action: 'manage',
                subject: 'all',
            } as any,
        },
    ];

    constructor(
        protected dataSource: DataSource,
        protected configure: Configure,
    ) {}

    setOptions(options: AbilityOptions<A, C>) {
        if (!this.setuped) {
            this.options = options;
            this.setuped = true;
        }
        return this;
    }

    get roles() {
        return this._roles;
    }

    get permissions() {
        return this._permissions;
    }

    addRoles(data: Role[]) {
        this._roles = [...this.roles, ...data];
    }

    addPermissions(data: PermissionType<A, C>[]) {
        this._permissions = [...this.permissions, ...data].map((item) => {
            let subject: typeof item.rule.subject;
            if (isArray(item.rule.subject)) subject = item.rule.subject.map((v) => getSubject(v));
            else subject = getSubject(item.rule.subject);
            const rule = { ...item.rule, subject };
            return { ...item, rule };
        });
    }

    async onApplicationBootstrap() {
        if (!this.dataSource.isInitialized) return null;
        const queryRunner = this.dataSource.createQueryRunner();

        await queryRunner.connect();
        await queryRunner.startTransaction();

        try {
            await this.syncRoles(queryRunner.manager);
            await this.syncPermissions(queryRunner.manager);
            await this.syncSuperAdmin(queryRunner.manager);
            await queryRunner.commitTransaction();
        } catch (err) {
            console.log(err);
            await queryRunner.rollbackTransaction();
        } finally {
            await queryRunner.release();
        }
        return true;
    }

    /**
     * 同步角色
     * @param manager
     */
    async syncRoles(manager: EntityManager) {
        this._roles = this.roles.reduce((o, n) => {
            if (o.map(({ name }) => name).includes(n.name)) {
                return o.map((e) => (e.name === n.name ? deepMerge(e, n, 'merge') : e));
            }
            return [...o, n];
        }, []);
        for (const item of this.roles) {
            let role = await manager.findOne(RoleEntity, {
                relations: ['permissions'],
                where: {
                    name: item.name,
                },
            });

            if (isNil(role)) {
                role = await manager.save(
                    manager.create(RoleEntity, {
                        name: item.name,
                        label: item.label,
                        description: item.description,
                        systemed: true,
                    }),
                    {
                        reload: true,
                    },
                );
            } else {
                await manager.update(RoleEntity, role.id, { systemed: true });
            }
        }

        // 清理已经不存在的系统角色
        const systemRoles = await manager.findBy(RoleEntity, { systemed: true });
        const toDels: string[] = [];
        for (const sRole of systemRoles) {
            if (isNil(this.roles.find(({ name }) => sRole.name === name))) toDels.push(sRole.id);
        }
        if (toDels.length > 0) await manager.delete(RoleEntity, toDels);
    }

    /**
     * 同步权限
     * @param manager
     */
    async syncPermissions(manager: EntityManager) {
        const permissions = await manager.find(PermissionEntity);
        const roles = await manager.find(RoleEntity, {
            relations: ['permissions'],
            where: { name: Not(SystemRoles.SUPER_ADMIN) },
        });
        const roleRepo = manager.getRepository(RoleEntity);
        // 合并并去除重复权限
        this._permissions = this.permissions.reduce(
            (o, n) => (o.map(({ name }) => name).includes(n.name) ? o : [...o, n]),
            [],
        );
        const names = this.permissions.map(({ name }) => name);

        /** *********** 同步权限  ************ */

        for (const item of this.permissions) {
            const permission = omit(item, ['conditions']);
            const old = await manager.findOneBy(PermissionEntity, {
                name: permission.name,
            });
            if (isNil(old)) {
                await manager.save(manager.create(PermissionEntity, permission));
            } else {
                await manager.update(PermissionEntity, old.id, permission);
            }
        }

        // 删除冗余权限
        const toDels: string[] = [];
        for (const item of permissions) {
            if (!names.includes(item.name) && item.name !== 'system-manage') toDels.push(item.id);
        }
        if (toDels.length > 0) await manager.delete(PermissionEntity, toDels);

        /** *********** 同步普通角色  ************ */
        for (const role of roles) {
            const rolePermissions = await manager.findBy(PermissionEntity, {
                name: In(this.roles.find(({ name }) => name === role.name).permissions),
            });
            await roleRepo
                .createQueryBuilder('role')
                .relation(RoleEntity, 'permissions')
                .of(role)
                .addAndRemove(
                    rolePermissions.map(({ id }) => id),
                    (role.permissions ?? []).map(({ id }) => id),
                );
        }

        /** *********** 同步超级管理员角色  ************ */

        // 查询出超级管理员角色
        const superRole = await manager.findOneOrFail(RoleEntity, {
            relations: ['permissions'],
            where: { name: SystemRoles.SUPER_ADMIN },
        });

        const systemManage = await manager.findOneOrFail(PermissionEntity, {
            where: { name: 'system-manage' },
        });
        // 添加系统管理权限到超级管理员角色
        await roleRepo
            .createQueryBuilder('role')
            .relation(RoleEntity, 'permissions')
            .of(superRole)
            .addAndRemove(
                [systemManage.id],
                (superRole.permissions ?? []).map(({ id }) => id),
            );
    }

    /**
     * 同步超级管理员
     * @param manager
     */
    async syncSuperAdmin(manager: EntityManager) {
        const superRole = await manager.findOneOrFail(RoleEntity, {
            relations: ['permissions'],
            where: { name: SystemRoles.SUPER_ADMIN },
        });

        const superUsers = await manager
            .createQueryBuilder(UserEntity, 'user')
            .leftJoinAndSelect('user.roles', 'roles')
            .where('roles.id IN (:...ids)', { ids: [superRole.id] })
            .getMany();
        if (superUsers.length < 1) {
            const userRepo = manager.getRepository(UserEntity);
            if ((await userRepo.count()) < 1) {
                throw new InternalServerErrorException(
                    'Please add a super-admin user first before run server!',
                );
            }
            const firstUser = await userRepo.findOneByOrFail({ id: undefined });
            await userRepo
                .createQueryBuilder('user')
                .relation(UserEntity, 'roles')
                .of(firstUser)
                .addAndRemove(
                    [superRole.id],
                    ((firstUser.roles ?? []) as RoleEntity[]).map(({ id }) => id),
                );
        }
    }
}
```

### 装饰器

#### 常量

```typescript
// src/modules/rbac/constants.ts
export const PERMISSION_CHECKERS = 'permission_checkers';
```

#### 类型

```typescript
// src/modules/rbac/types.ts
import { FastifyRequest as Request } from 'fastify';

export type PermissionChecker = (
    ability: MongoAbility,
    ref?: ModuleRef,
    request?: Request,
) => Promise<boolean>;
```

#### 函数

```typescript
// src/modules/rbac/decorators/permission.decorator.ts
export const Permission = (...checkers: PermissionChecker[]) =>
    SetMetadata(PERMISSION_CHECKERS, checkers);
```

### 守卫

#### 类型

```typescript
export type CheckerParams = {
    resolver: RbacResolver;
    repository: UserRepository;
    checkers: PermissionChecker[];
    moduleRef?: ModuleRef;
    request?: any;
};
```

#### 守卫类

```typescript
@Injectable()
export class RbacGuard extends JwtAuthGuard {
    constructor(
        protected reflector: Reflector,
        protected resolver: RbacResolver,
        protected tokenService: TokenService,
        protected userRepository: UserRepository,
        protected moduleRef: ModuleRef,
    ) {
        super(reflector, tokenService);
    }

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const authCheck = await super.canActivate(context);
        // const request = context.switchToHttp().getRequest();
        // const requestToken = ExtractJwt.fromAuthHeaderAsBearerToken()(request);
        if (!authCheck) throw new ForbiddenException();
        // if (authCheck && isNil(requestToken)) return true;
        const checkers = this.reflector.getAllAndOverride<PermissionChecker[]>(
            PERMISSION_CHECKERS,
            [context.getHandler(), context.getClass()],
        );
        if (isNil(checkers) || checkers.length <= 0) return true;
        const result = await checkPermissions({
            resolver: this.resolver,
            repository: this.userRepository,
            checkers,
            moduleRef: this.moduleRef,
            request: context.switchToHttp().getRequest(),
        });
        if (!result) {
            throw new ForbiddenException();
        }
        return true;
    }
}

export const checkPermissions = async ({
    checkers,
    moduleRef,
    resolver,
    repository,
    request,
}: CheckerParams) => {
    if (isNil(request.user)) return false;
    const user = await repository.findOneOrFail({
        relations: ['roles.permissions', 'permissions'],
        where: {
            id: request.user.id,
        },
    });
    let permissions = user.permissions as PermissionEntity[];
    for (const role of user.roles) {
        permissions = [...permissions, ...role.permissions];
    }
    permissions = permissions.reduce((o, n) => {
        if (o.find(({ name }) => name === n.name)) return o;
        return [...o, n];
    }, []);
    const ability = createMongoAbility(
        permissions.map(({ rule, name }) => {
            const resolve = resolver.permissions.find((p) => p.name === name);
            if (!isNil(resolve) && !isNil(resolve.rule.conditions)) {
                return { ...rule, conditions: resolve.rule.conditions(user) };
            }
            return rule;
        }),
    );
    const results = await Promise.all(
        checkers.map(async (checker) => checker(ability, moduleRef, request)),
    );
    return results.every((r) => !!r);
};
```

#### 替换守卫

```typescript
// src/options.ts
export const createOptions: CreateOptions = {
    globals: {
        guard: RbacGuard,
    },
    // ...
};
```

### 权限检查

```typescript
// src/modules/rbac/helpers.ts
/**
 * 验证是否是数据拥有者
 * @param ability
 * @param options
 */
export const checkOwnerPermission = async <E extends ObjectLiteral>(
    ability: MongoAbility,
    options: {
        request: Request;
        key?: string;
        getData: (items: string[]) => Promise<E[]>;
        permission?: string;
    },
) => {
    const { request, key, getData, permission } = options;
    const models = await getData(getRequestData(key, request));
    return models.every((model) => ability.can(permission ?? PermissionAction.OWNER, model));
};
```

### 模块

```typescript
// src/modules/rbac/rbac.module.ts
@Module({})
export class RbacModule {
    static async forRoot(configure: Configure): Promise<DynamicModule> {
        return {
            module: RbacModule,
            imports: [
                forwardRef(() => UserModule),
                addEntities(configure, Object.values(entities)),
                DatabaseModule.forRepository(Object.values(repositories)),
            ],
            providers: [
                ...Object.values(services),
                ...(await addSubscribers(configure, Object.values(subscribers))),
                RbacGuard,
                {
                    provide: RbacResolver,
                    useFactory: async (dataSource: DataSource) => {
                        const resolver = new RbacResolver(dataSource, configure);
                        resolver.setOptions({});
                        return resolver;
                    },
                    inject: [getDataSourceToken()],
                },
            ],
            exports: [
                RbacResolver,
                ...Object.values(services),
                DatabaseModule.forRepository(Object.values(repositories)),
            ],
        };
    }
}
```

### 控制器与路由

#### 常量

```typescript
// src/modules/rbac/constants.ts
export enum PermissionAction {
    CREATE = 'create',
    READ = 'read',
    UPDATE = 'update',
    DELETE = 'delete',
    MANAGE = 'manage',
    OWNER = 'onwer',
}
```

#### 角色查询

```typescript
// src/modules/rbac/controllers/role.controller.ts
@ApiTags('角色查询')
@Depends(RbacModule)
@Controller('roles')
export class RoleController {
    constructor(protected service: RoleService) {}

    /**
     * 角色列表查询
     * @param options
     */
    @Get()
    @SerializeOptions({ groups: ['role-list'] })
    @Guest()
    async list(
        @Query()
        options: PaginateWithTrashedDto,
    ) {
        return this.service.paginate(options);
    }

    /**
     * 角色详解查询
     * @param id
     */
    @Get(':id')
    @SerializeOptions({ groups: ['role-detail'] })
    @Guest()
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }
}
```

#### 权限查询

```typescript
const permission: PermissionChecker = async (ab) =>
    ab.can(PermissionAction.MANAGE, PermissionEntity.name);

@ApiTags('权限查询')
@ApiBearerAuth()
@Depends(RbacModule)
@Controller('permissions')
export class PermissionController {
    constructor(protected service: PermissionService) {}

    /**
     * 分页列表查询
     * @param options
     */
    @Get()
    @SerializeOptions({ groups: ['permssion-list'] })
    @Permission(permission)
    async list(
        @Query()
        options: PaginateWithTrashedDto,
    ) {
        return this.service.paginate(options);
    }

    /**
     * 分页详解查询
     * @param id
     */
    @Get(':id')
    @SerializeOptions({ groups: ['permssion-detail'] })
    @Permission(permission)
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }
}
```

#### 角色查询

```typescript
// src/modules/rbac/controllers/manage/role.controller.ts
const permission: PermissionChecker = async (ab) =>
    ab.can(PermissionAction.MANAGE, RoleEntity.name);

@ApiTags('角色管理')
@ApiBearerAuth()
@Depends(RbacModule)
@Controller('roles')
export class RoleController {
    constructor(protected service: RoleService) {}

    /**
     * 新增角色
     * @param data
     */
    @Post()
    @SerializeOptions({ groups: ['role-detail'] })
    @Permission(permission)
    async store(
        @Body()
        data: CreateRoleDto,
    ) {
        return this.service.create(data);
    }

    /**
     * 更新角色
     * @param data
     */
    @Patch()
    @SerializeOptions({ groups: ['role-detail'] })
    @Permission(permission)
    async update(
        @Body()
        data: UpdateRoleDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除角色
     * @param data
     */
    @Delete()
    @SerializeOptions({ groups: ['role-list'] })
    @Permission(permission)
    async delete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }

    /**
     * 批量恢复角色
     * @param data
     */
    @Patch('restore')
    @SerializeOptions({ groups: ['role-list'] })
    @Permission(permission)
    async restore(
        @Body()
        data: RestoreDto,
    ) {
        const { ids } = data;
        return this.service.restore(ids);
    }
}
```

#### 路由

```typescript
// src/modules/rbac/routes.ts
import * as controllers from './controllers';
import * as manageControllers from './controllers/manage';

export const createRbacApi = () => {
    const routes: Record<'app' | 'manage', RouteOption[]> = {
        app: [
            {
                name: 'app.rbac',
                path: 'rbac',
                controllers: Object.values(controllers),
            },
        ],
        manage: [
            {
                name: 'manage.rbac',
                path: 'rbac',
                controllers: Object.values(manageControllers),
            },
        ],
    };
    const tags: Record<'app' | 'manage', Array<string | TagOption>> = {
        app: [{ name: '角色查询', description: '查询角色信息' }],
        manage: [
            { name: '角色管理', description: '管理角色信息' },
            { name: '权限信息', description: '查询权限信息' },
        ],
    };
    return { routes, tags };
};
```

## 用户模块

### 存储类

```typescript
// src/modules/user/repositories/user.repository.ts
@CustomRepository(UserEntity)
export class UserRepository extends BaseRepository<UserEntity> {
    protected _qbName = 'user';

    buildBaseQB() {
        return this.createQueryBuilder(this.qbName)
            .orderBy(`${this.qbName}.createdAt`, 'DESC')
            .leftJoinAndSelect(`${this.qbName}.roles`, 'roles')
            .leftJoinAndSelect(`${this.qbName}.permissions`, 'permissions');
    }
}
```

### 订阅者

```typescript
// src/modules/user/subscribers/user.subscriber.ts
/**
 * 用户模型监听器
 */
@EventSubscriber()
export class UserSubscriber extends BaseSubscriber<UserEntity> {
    // ...

    /**
     * 当密码更改时加密密码
     * @param event
     */
    async beforeUpdate(event: UpdateEvent<UserEntity>) {
        if (this.isUpdated('password', event)) {
            event.entity.password = await encrypt(this.configure, event.entity.password);
        }
    }

    async afterLoad(entity: UserEntity): Promise<void> {
        let permissions = (entity.permissions ?? []) as PermissionEntity[];
        for (const role of entity.roles ?? []) {
            const roleEntity = await RoleEntity.findOneOrFail({
                relations: ['permissions'],
                where: { id: role.id },
            });
            permissions = [...permissions, ...(roleEntity.permissions ?? [])];
        }
        entity.permissions = permissions.reduce((o, n) => {
            if (o.find(({ name }) => name === n.name)) return o;
            return [...o, n];
        }, []);
    }
}
```

### 数据验证

```typescript
// src/modules/user/dtos/user.dto.ts
/**
 * 创建用的请求数据验证
 */
@DtoValidation({ groups: [UserValidateGroups.USER_CREATE] })
export class CreateUserDto extends PickType(UserCommonDto, [
    'username',
    'nickname',
    'password',
    'phone',
    'email',
]) {
    /**
     * 用户关联的角色ID列表
     */
    @IsDataExist(RoleEntity, {
        each: true,
        always: true,
        message: '角色不存在',
    })
    @IsUUID(undefined, {
        each: true,
        always: true,
        message: '角色ID格式不正确',
    })
    @IsOptional({ always: true })
    roles?: string[];

    /**
     * 用户直接关联的权限ID列表
     */
    @IsDataExist(PermissionEntity, {
        each: true,
        always: true,
        message: '权限不存在',
    })
    @IsUUID(undefined, {
        each: true,
        always: true,
        message: '权限ID格式不正确',
    })
    @IsOptional({ always: true })
    permissions?: string[];
}

/**
 * 更新用户
 */
@DtoValidation({ groups: [UserValidateGroups.USER_UPDATE] })
export class UpdateUserDto extends PartialType(CreateUserDto) {
    /**
     * 待更新的用户ID
     */
    @IsUUID(undefined, { groups: [UserValidateGroups.USER_UPDATE], message: '用户ID格式不正确' })
    @IsDefined({ groups: ['update'], message: '用户ID必须指定' })
    id: string;
}

/**
 * 查询用户列表的Query数据验证
 */
@DtoValidation({ type: 'query' })
export class QueryUserDto extends PaginateWithTrashedDto {
    /**
     * 角色ID:根据角色来过滤用户
     */
    @IsDataExist(RoleEntity, {
        message: '角色不存在',
    })
    @IsUUID(undefined, { message: '角色ID格式错误' })
    @IsOptional()
    role?: string;

    /**
     * 权限ID:根据权限来过滤用户(权限包含用户关联的所有角色的权限以及直接关联的权限)
     */
    @IsDataExist(PermissionEntity, {
        message: '权限不存在',
    })
    @IsUUID(undefined, { message: '权限ID格式错误' })
    @IsOptional()
    permission?: string;

    /**
     * 排序规则:可指定用户列表的排序规则,默认为按创建时间降序排序
     */
    @IsEnum(UserOrderType)
    orderBy?: UserOrderType;
}

/**
 * 客户端查询用户
 */
@DtoValidation({ type: 'query' })
export class FrontendQueryUserDto extends OmitType(QueryUserDto, ['trashed']) {}
```

### 服务类

```typescript
// src/modules/user/services/user.service.ts
/**
 * 用户管理服务
 */
@Injectable()
export class UserService extends BaseService<UserEntity, UserRepository> {
    protected enable_trash = true;

    constructor(
        protected configure: Configure,
        protected dataSource: DataSource,
        protected userRepository: UserRepository,
        protected roleRepository: RoleRepository,
    ) {
        super(userRepository);
    }
  
    // ...
}
```

#### 添加角色

```typescript
@Injectable()
export class UserService extends BaseService<UserEntity, UserRepository> {
    // ...
    protected async addUserRole(user: UserEntity) {
        const roleRelation = this.userRepository.createQueryBuilder().relation('roles').of(user);
        const roleNames = (user.roles ?? []).map(({ name }) => name);
        const noneUserRole = roleNames.length <= 0 || !roleNames.includes(SystemRoles.USER);
        if (noneUserRole) {
            const userRole = await this.roleRepository.findOne({
                relations: ['users'],
                where: { name: SystemRoles.USER },
            });
            if (!isNil(userRole)) await roleRelation.add(userRole);
        }
    }
}
```

#### 用户查询

```typescript
@Injectable()
export class UserService extends BaseService<UserEntity, UserRepository> {
    // ...
    protected async buildListQB(
        queryBuilder: SelectQueryBuilder<UserEntity>,
        options: QueryUserDto,
        callback?: QueryHook<UserEntity>,
    ) {
        const { orderBy } = options;
        const qb = await super.buildListQB(queryBuilder, options, callback);
        if (!isNil(options.role)) {
            qb.andWhere('roles.id IN (:...roles)', {
                roles: [options.role],
            });
        }
        if (!isNil(options.permission)) {
            qb.andWhere('permissions.id IN (:...permissions)', {
                permissions: [options.permission],
            });
        }
        if (isNil(orderBy)) qb.orderBy(`${this.repository.qbName}.${orderBy}`, 'ASC');
        return qb;
    }
}
```

#### 创建用户

```typescript
@Injectable()
export class UserService extends BaseService<UserEntity, UserRepository> {
    // ...
    async create({ roles, permissions, ...data }: CreateUserDto) {
        const user = await this.userRepository.save(data, { reload: true });
        if (isArray(roles) && roles.length > 0) {
            await this.userRepository
                .createQueryBuilder('user')
                .relation('roles')
                .of(user)
                .add(roles);
        }
        if (isArray(permissions) && permissions.length > 0) {
            await this.userRepository
                .createQueryBuilder('user')
                .relation('permissions')
                .of(user)
                .add(permissions);
        }
        await this.addUserRole(await this.detail(user.id));
        return this.detail(user.id);
    }
}
```

#### 更新用户

```typescript
@Injectable()
export class UserService extends BaseService<UserEntity, UserRepository> {
    // ...
    async update({ roles, permissions, ...data }: UpdateUserDto) {
        const updated = await this.userRepository.save(data, { reload: true });
        const user = await this.detail(updated.id);
        if ((isNil(roles) || roles.length < 0) && (isNil(permissions) || permissions.length < 0))
            return user;
        if (isArray(roles) && roles.length > 0) {
            await this.userRepository
                .createQueryBuilder('user')
                .relation('roles')
                .of(user)
                .addAndRemove(roles, user.roles ?? []);
        }
        if (isArray(permissions) && permissions.length > 0) {
            await this.userRepository
                .createQueryBuilder('user')
                .relation('permissions')
                .of(user)
                .addAndRemove(permissions, user.permissions ?? []);
        }
        await this.addUserRole(await this.detail(user.id));
        return this.detail(user.id);
    }
}
```

### 控制器与路由

#### 用户查询

```typescript
// src/modules/user/controllers/user.controller.ts
@ApiTags('用户查询')
@Depends(UserModule)
@Controller('users')
export class UserController {
    constructor(protected service: UserService) {}

    /**
     * 用户列表
     */
    @Get()
    @Guest()
    @SerializeOptions({ groups: ['user-list'] })
    async list(
        @Query()
        options: FrontendQueryUserDto,
    ) {
        return this.service.list({
            ...options,
            trashed: SelectTrashMode.NONE,
        });
    }

    /**
     * 获取用户信息
     * @param id
     */
    @Get(':id')
    @Guest()
    @SerializeOptions({ groups: ['user-detail'] })
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id, async (qb) => qb.andWhere({ deletedAt: Not(IsNull()) }));
    }
}
```

#### 用户管理

```typescript
// src/modules/user/controllers/manage/user.controller.ts
const permission: PermissionChecker = async (ab) =>
    ab.can(PermissionAction.MANAGE, UserEntity.name);

@ApiTags('用户管理')
@ApiBearerAuth()
@Depends(UserModule)
@Controller('users')
export class UserController {
    constructor(protected service: UserService) {}

    /**
     * 用户列表
     */
    @Get()
    @Permission(permission)
    @SerializeOptions({ groups: ['user-list'] })
    async list(
        @Query()
        options: QueryUserDto,
    ) {
        return this.service.list(options);
    }

    /**
     * 获取用户信息
     * @param id
     */
    @Get(':id')
    @Permission(permission)
    @SerializeOptions({ groups: ['user-detail'] })
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }

    /**
     * 新增用户
     * @param data
     */
    @Post()
    @Permission(permission)
    @SerializeOptions({ groups: ['user-detail'] })
    async store(
        @Body()
        data: CreateUserDto,
    ) {
        return this.service.create(data);
    }

    /**
     * 更新用户
     * @param data
     */
    @Patch()
    @Permission(permission)
    @SerializeOptions({ groups: ['user-detail'] })
    async update(
        @Body()
        data: UpdateUserDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除用户
     * @param data
     */
    @Delete()
    @Permission(permission)
    @SerializeOptions({ groups: ['user-list'] })
    async delete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }

    /**
     * 批量恢复用户
     * @param data
     */
    @Patch('restore')
    @Permission(permission)
    @SerializeOptions({ groups: ['user-list'] })
    async restore(
        @Body()
        data: RestoreDto,
    ) {
        const { ids } = data;
        return this.service.restore(ids);
    }
}
```

#### 路由

```typescript
// src/modules/user/routes.ts
import * as controllers from './controllers';
import * as manageControllers from './controllers/manage';

export const createUserApi = () => {
    const routes: Record<'app' | 'manage', RouteOption[]> = {
        app: [
            {
                name: 'app.user',
                path: 'user',
                controllers: Object.values(controllers),
            },
        ],
        manage: [
            {
                name: 'manage.user',
                path: 'user',
                controllers: Object.values(manageControllers),
            },
        ],
    };
    const tags: Record<'app' | 'manage', (string | TagOption)[]> = {
        app: [
            { name: '用户查询', description: '查询用户列表和用户信息' },
            { name: '账户操作', description: '注册登录、查看修改账户信息、修改密码等' },
        ],
        manage: [{ name: '用户管理', description: '管理用户信息' }],
    };
    return { routes, tags };
};
```

## 内容模块

### 权限提供者

```typescript
// src/modules/content/rbac.ts
@Injectable()
export class ContentRbac implements OnModuleInit {
    constructor(private moduleRef: ModuleRef) {}

    onModuleInit() {
        const resolver = this.moduleRef.get(RbacResolver, { strict: false });
        resolver.addPermissions([
            {
                name: 'post.create',
                rule: {
                    action: PermissionAction.CREATE,
                    subject: PostEntity,
                },
            },
            {
                name: 'post.owner',
                rule: {
                    action: PermissionAction.OWNER,
                    subject: PostEntity,
                    conditions: (user) => ({
                        'author.id': user.id,
                    }),
                },
            },
            {
                name: 'comment.create',
                rule: {
                    action: PermissionAction.CREATE,
                    subject: CommentEntity,
                },
            },
            {
                name: 'comment.owner',
                rule: {
                    action: PermissionAction.OWNER,
                    subject: CommentEntity,
                    conditions: (user) => ({
                        'author.id': user.id,
                    }),
                },
            },
            {
                name: 'post.manage',
                rule: {
                    action: PermissionAction.MANAGE,
                    subject: PostEntity,
                },
            },
            {
                name: 'tag.manage',
                rule: {
                    action: PermissionAction.MANAGE,
                    subject: TagEntity,
                },
            },
            {
                name: 'category.manage',
                rule: {
                    action: PermissionAction.MANAGE,
                    subject: CategoryEntity,
                },
            },
            {
                name: 'comment.manage',
                rule: {
                    action: PermissionAction.MANAGE,
                    subject: CommentEntity,
                },
            },
        ]);
        resolver.addRoles([
            {
                name: SystemRoles.USER,
                permissions: [
                    'post.read',
                    'post.create',
                    'post.owner',
                    'comment.create',
                    'comment.owner',
                ],
            },
            {
                name: 'content-manage',
                label: '内容管理员',
                description: '管理内容模块',
                permissions: ['post.manage', 'category.manage', 'tag.manage', 'comment.manage'],
            },
        ]);
    }
}

// src/modules/content/content.module.ts
@Module({})
export class ContentModule {
    static async forRoot(configure: Configure) {
        const config = await configure.get<ContentConfig>('content', defaultContentConfig);
        const providers: ModuleMetadata['providers'] = [
            ContentRbac,
            // ...
}
```

### 控制器与路由

#### 分类查询

```typescript
@ApiTags('分类查询')
@Depends(ContentModule)
@Controller('categories')
export class CategoryController {
    constructor(protected service: CategoryService) {}

    /**
     * 查询分类树
     * @param options
     */
    @Get('tree')
    @SerializeOptions({ groups: ['category-tree'] })
    @Guest()
    async tree() {
        return this.service.findTrees();
    }

    /**
     * 分页查询分类列表
     * @param options
     */
    @Get()
    @SerializeOptions({ groups: ['category-list'] })
    @Guest()
    async list(@Query() options: PaginateDto) {
        return this.service.paginate(options);
    }

    /**
     * 分页详解查询
     * @param id
     */
    @Get(':id')
    @SerializeOptions({ groups: ['category-detail'] })
    @Guest()
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }
}
```

#### 分类管理

```typescript
// src/modules/content/controllers/manage/category.controller.ts
@ApiTags('分类管理')
@ApiBearerAuth()
@Depends(ContentModule)
@Controller('categories')
export class CategoryController {
    constructor(protected service: CategoryService) {}

    /**
     * 查询分类列表
     * @param options
     */
    @Get()
    @Permission(permission)
    @SerializeOptions({ groups: ['category-list'] })
    async list(@Query() options: PaginateDto) {
        return this.service.paginate(options);
    }

    /**
     * 分页详解查询
     * @param id
     */
    @Get(':id')
    @Permission(permission)
    @SerializeOptions({ groups: ['category-detail'] })
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }

    /**
     * 新增分类
     * @param data
     */
    @Post()
    @Permission(permission)
    @SerializeOptions({ groups: ['category-detail'] })
    async store(@Body() data: CreateCategoryDto) {
        return this.service.create(data);
    }

    /**
     * 更新分类
     * @param data
     */
    @Patch()
    @Permission(permission)
    @SerializeOptions({ groups: ['category-detail'] })
    async update(
        @Body()
        data: UpdateCategoryDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除分类
     * @param data
     */
    @Delete()
    @Permission(permission)
    @SerializeOptions({ groups: ['category-list'] })
    async delete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }
}
```

#### 标签查询

```typescript
@ApiTags('标签查询')
@Depends(ContentModule)
@Controller('tags')
export class TagController {
    constructor(protected service: TagService) {}

    /**
     * 分页查询标签列表
     * @param options
     */
    @Get()
    @SerializeOptions({})
    @Guest()
    async list(
        @Query()
        options: PaginateDto,
    ) {
        return this.service.paginate(options);
    }

    /**
     * 查询标签详情
     * @param id
     */
    @Get(':id')
    @SerializeOptions({})
    @Guest()
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }
}
```

#### 标签管理

```typescript
// src/modules/content/controllers/manage/tag.controller.ts
const permission: PermissionChecker = async (ab) => ab.can(PermissionAction.MANAGE, TagEntity.name);

@ApiTags('标签管理')
@ApiBearerAuth()
@Depends(ContentModule)
@Controller('tags')
export class TagController {
    constructor(protected service: TagService) {}

    /**
     * 分页查询标签列表
     * @param options
     */
    @Get()
    @SerializeOptions({})
    @Permission(permission)
    async list(
        @Query()
        options: PaginateDto,
    ) {
        return this.service.paginate(options);
    }

    /**
     * 查询标签详情
     * @param id
     */
    @Get(':id')
    @SerializeOptions({})
    @Permission(permission)
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }

    /**
     * 添加新标签
     * @param data
     */
    @Post()
    @SerializeOptions({})
    @Permission(permission)
    async store(
        @Body()
        data: CreateTagDto,
    ) {
        return this.service.create(data);
    }

    /**
     * 更新标签
     * @param data
     */
    @Patch()
    @SerializeOptions({})
    @Permission(permission)
    async update(
        @Body()
        data: UpdateTagDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除标签
     * @param data
     */
    @Delete()
    @SerializeOptions({})
    @Permission(permission)
    async delete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }
}
```

#### 文章数据验证

```typescript
// src/modules/content/dtos/post.dto.ts
/**
 * 文章分页查询验证
 */
@DtoValidation({ type: 'query' })
export class QueryPostDto extends PaginateWithTrashedDto {
    /**
     * 全文搜索
     */
    @MaxLength(100, {
        always: true,
        message: '搜索字符串长度不得超过$constraint1',
    })
    @IsOptional({ always: true })
    search?: string;

    /**
     * 是否查询已发布(全部文章:不填、只查询已发布的:true、只查询未发布的:false)
     */
    @Transform(({ value }) => toBoolean(value))
    @IsBoolean()
    @IsOptional()
    isPublished?: boolean;

    /**
     * 查询结果排序,不填则综合排序
     */
    @IsEnum(PostOrderType, {
        message: `排序规则必须是${Object.values(PostOrderType).join(',')}其中一项`,
    })
    @IsOptional()
    orderBy?: PostOrderType;

    /**
     * 根据分类ID查询此分类及其后代分类下的文章
     */
    @IsDataExist(CategoryEntity, {
        always: true,
        message: '分类不存在',
    })
    @IsUUID(undefined, { message: 'ID格式错误' })
    @IsOptional()
    category?: string;

    /**
     * 根据标签ID查询
     */
    @IsDataExist(TagEntity, {
        always: true,
        message: '标签不存在',
    })
    @IsUUID(undefined, { message: 'ID格式错误' })
    @IsOptional()
    tag?: string;

    /**
     * 根据文章作者ID查询
     */
    @IsDataExist(UserEntity, {
        message: '指定的用户不存在',
    })
    @IsUUID(undefined, { message: '用户ID格式错误' })
    @IsOptional()
    author?: string;
}

/**
 * 文章创建验证
 */
@DtoValidation({ groups: ['create'] })
export class CreatePostDto {
    /**
     * 文章标题
     */
    @MaxLength(255, {
        always: true,
        message: '文章标题长度最大为$constraint1',
    })
    @IsNotEmpty({ groups: ['create'], message: '文章标题必须填写' })
    @IsOptional({ groups: ['update'] })
    title: string;

    /**
     * 文章内容
     */
    @IsNotEmpty({ groups: ['create'], message: '文章内容必须填写' })
    @IsOptional({ groups: ['update'] })
    body: string;

    /**
     * 文章描述
     */
    @MaxLength(500, {
        always: true,
        message: '文章描述长度最大为$constraint1',
    })
    @IsOptional({ always: true })
    summary?: string;

    /**
     * 是否发布(发布时间)
     */
    @IsDateString({ strict: true }, { always: true })
    @IsOptional({ always: true })
    @ValidateIf((value) => !isNil(value.publishedAt))
    @Transform(({ value }) => (value === 'null' ? null : value))
    publishedAt?: Date;

    /**
     * SEO关键字
     */
    @MaxLength(20, {
        each: true,
        always: true,
        message: '每个关键字长度最大为$constraint1',
    })
    @IsOptional({ always: true })
    keywords?: string[];

    /**
     * 自定义排序
     */
    @Transform(({ value }) => toNumber(value))
    @Min(0, { always: true, message: '排序值必须大于0' })
    @IsNumber(undefined, { always: true })
    @IsOptional({ always: true })
    customOrder?: number = 0;

    /**
     * 所属分类ID
     */
    @IsDataExist(CategoryEntity, {
        message: '分类不存在',
    })
    @IsUUID(undefined, {
        each: true,
        always: true,
        message: 'ID格式不正确',
    })
    @IsOptional({ groups: ['update'] })
    category: string;

    /**
     * 关联标签ID
     */
    @IsDataExist(TagEntity, {
        each: true,
        always: true,
        message: '标签不存在',
    })
    @IsUUID(undefined, {
        each: true,
        always: true,
        message: 'ID格式不正确',
    })
    @IsNotEmpty({ groups: ['create'], message: '分类必须设置' })
    @IsOptional({ always: true })
    tags?: string[];

    /**
     * 文章作者ID:可用于在管理员发布文章时分配给其它用户,如果不设置,则作者为当前管理员
     */
    @IsDataExist(UserEntity, {
        always: true,
        message: '用户不存在',
    })
    @IsUUID(undefined, {
        always: true,
        message: '用户ID格式不正确',
    })
    @IsOptional({ always: true })
    author?: string;
}

/**
 * 文章更新验证
 */
@DtoValidation({ groups: ['update'] })
export class UpdatePostDto extends PartialType(CreatePostDto) {
    /**
     * 待更新ID
     */
    @IsUUID(undefined, { groups: ['update'], message: '文章ID格式错误' })
    @IsDefined({ groups: ['update'], message: '文章ID必须指定' })
    id: string;
}

/**
 * 客户端查询文章列表验证
 */
@DtoValidation({ type: 'query' })
export class FrontendQueryPostDto extends OmitType(QueryPostDto, ['isPublished', 'trashed']) {}

/**
 * 客户端创建文章验证
 */
@DtoValidation({ groups: ['create'] })
export class FrontendCreatePostDto extends OmitType(CreatePostDto, ['author', 'customOrder']) {
    /**
     * 用户侧排序:文章在用户的文章管理而非后台中,列表的排序规则
     */
    @Transform(({ value }) => toNumber(value))
    @Min(0, { always: true, message: '排序值必须大于0' })
    @IsNumber(undefined, { always: true })
    @IsOptional({ always: true })
    userOrder?: number = 0;
}

/**
 * 用户文章更新验证
 */
@DtoValidation({ groups: ['update'] })
export class OnwerUpdatePostDto extends OmitType(UpdatePostDto, ['author', 'customOrder']) {
    /**
     * 用户侧排序:文章在用户的文章管理而非后台中,列表的排序规则
     */
    @Transform(({ value }) => toNumber(value))
    @Min(0, { always: true, message: '排序值必须大于0' })
    @IsNumber(undefined, { always: true })
    @IsOptional({ always: true })
    userOrder?: number = 0;
}

/**
 * 用户查询自己的文章列表验证
 */
@DtoValidation({ type: 'query' })
export class OwnerQueryPostDto extends OmitType(QueryPostDto, ['author']) {}
```

#### 文章服务

```typescript
// src/modules/content/services/post.service.ts
@Injectable()
export class PostService extends BaseService<PostEntity, PostRepository, FindParams> {
    // ...
    /**
     * 创建文章
     * @param data
     * @param author
     */
    async create(data: CreatePostDto | FrontendCreatePostDto, author: ClassToPlain<UserEntity>) {
        let publishedAt: Date | null;
        if (!isNil(data.publish)) {
            publishedAt = data.publish ? new Date() : null;
        }
        const authorId = isNil((data as CreatePostDto).author)
            ? author.id
            : (data as CreatePostDto).author;
        const createPostDto = {
            ...omit(data, ['publish', 'author']),
            // 文章作者
            author: await this.userRepository.findOneByOrFail({ id: authorId }),
        // ...
    }

     /**
     * 更新文章
     * @param data
     */
    async update(data: UpdatePostDto) {
        let publishedAt: Date | null;
        if (!isNil(data.publish)) {
            publishedAt = data.publish ? new Date() : null;
        }
        const post = await this.detail(data.id);
        if (!isNil((data as UpdatePostDto).author)) {
            const author = await this.userRepository.findOneByOrFail({
                id: (data as UpdatePostDto).author,
            });
            post.author = author;
            await this.repository.save(author, { reload: true });
        }
       // ...
        await this.repository.update(data.id, {
            ...omit(data, ['id', 'tags', 'category', 'publish', 'author']),
            publishedAt,
        });
        const result = await this.detail(data.id);
        if (!isNil(this.searchService)) await this.searchService.update([result]);
        return result;
    }
}
```

#### 文章操作

```typescript
// src/modules/content/controllers/post.controller.ts
const permissions: Record<'create' | 'owner', PermissionChecker> = {
    create: async (ab) => ab.can(PermissionAction.CREATE, PostEntity.name),
    owner: async (ab, ref, request) =>
        checkOwnerPermission(ab, {
            request,
            getData: async (items) =>
                ref.get(PostRepository, { strict: false }).find({
                    relations: ['author'],
                    where: { id: In(items) },
                }),
        }),
};

@ApiTags('文章操作')
@Depends(ContentModule)
@Controller('posts')
export class PostController {
    constructor(protected service: PostService) {}

    /**
     * 查询文章列表
     * @param options
     */
    @Get()
    @SerializeOptions({ groups: ['post-list'] })
    @Guest()
    async list(
        @Query()
        options: FrontendQueryPostDto,
    ) {
        return this.service.paginate({
            ...options,
            isPublished: true,
            trashed: SelectTrashMode.NONE,
        });
    }

    /**
     * 分页查询自己发布的文章列表
     * @param options
     */
    @Get('onwer')
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-list'] })
    async listOwner(
        @Query()
        options: OwnerQueryPostDto,
        @ReqUser() author: ClassToPlain<UserEntity>,
    ) {
        return this.service.paginate({
            ...options,
            author: author.id,
        });
    }

    /**
     * 查询文章详情
     * @param id
     */
    @Get(':id')
    @SerializeOptions({ groups: ['post-detail'] })
    @Guest()
    async detail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id, async (qb) =>
            qb.andWhere({ publishedAt: Not(IsNull()), deletedAt: Not(IsNull()) }),
        );
    }

    /**
     * 查询自己发布的文章详情
     * @param id
     */
    @Get('owner/:id')
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permissions.owner)
    async detailOwner(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id, async (qb) => qb.withDeleted());
    }

    /**
     * 新增文章
     * @param data
     */
    @Post()
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permissions.create)
    async store(
        @Body()
        data: FrontendCreatePostDto,
        @ReqUser() author: ClassToPlain<UserEntity>,
    ) {
        return this.service.create(data, author);
    }

    /**
     * 更新自己发布的文章
     * @param data
     */
    @Patch()
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permissions.owner)
    async update(
        @Body()
        data: OnwerUpdatePostDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除自己发布的文章
     * @param data
     */
    @Delete()
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-list'] })
    @Permission(permissions.owner)
    async delete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }

    /**
     * 批量恢复自己发布的文章
     * @param data
     */
    @Patch('restore')
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['post-list'] })
    @Permission(permissions.owner)
    async restore(
        @Body()
        data: RestoreDto,
    ) {
        const { ids } = data;
        return this.service.restore(ids);
    }
}
```

#### 文章管理

```typescript
// src/modules/content/controllers/manage/post.controller.ts
const permission: PermissionChecker = async (ab) =>
    ab.can(PermissionAction.MANAGE, PostEntity.name);

@ApiTags('文章管理')
@ApiBearerAuth()
@Depends(ContentModule)
@Controller('posts')
export class PostController {
    constructor(protected service: PostService) {}

    /**
     * 查询文章列表
     * @param options
     */
    @Get()
    @SerializeOptions({ groups: ['post-list'] })
    @Permission(permission)
    async manageList(
        @Query()
        options: QueryPostDto,
    ) {
        return this.service.paginate(options);
    }

    /**
     * 查询文章详情
     * @param id
     */
    @Get(':id')
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permission)
    async manageDetail(
        @Param('id', new ParseUUIDPipe())
        id: string,
    ) {
        return this.service.detail(id);
    }

    /**
     * 新增文章
     * @param data
     */
    @Post()
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permission)
    async storeManage(
        @Body()
        { author, ...data }: CreatePostDto,
        @ReqUser() user: ClassToPlain<UserEntity>,
    ) {
        return this.service.create(data, {
            id: isNil(author) ? user.id : author,
        } as ClassToPlain<UserEntity>);
    }

    /**
     * 更新文章
     * @param data
     */
    @Patch()
    @SerializeOptions({ groups: ['post-detail'] })
    @Permission(permission)
    async manageUpdate(
        @Body()
        data: UpdatePostDto,
    ) {
        return this.service.update(data);
    }

    /**
     * 批量删除文章
     * @param data
     */
    @Delete()
    @SerializeOptions({ groups: ['post-list'] })
    @Permission(permission)
    async manageDelete(
        @Body()
        data: DeleteWithTrashDto,
    ) {
        const { ids, trash } = data;
        return this.service.delete(ids, trash);
    }

    /**
     * 批量恢复文章
     * @param data
     */
    @Patch('restore')
    @SerializeOptions({ groups: ['post-list'] })
    @Permission(permission)
    async manageRestore(
        @Body()
        data: RestoreDto,
    ) {
        const { ids } = data;
        return this.service.restore(ids);
    }
}
```

#### 评论操作

```typescript
// src/modules/content/controllers/comment.controller.ts
const permissions: Record<'create' | 'owner', PermissionChecker> = {
    create: async (ab) => ab.can(PermissionAction.CREATE, CommentEntity.name),
    owner: async (ab, ref, request) =>
        checkOwnerPermission(ab, {
            request,
            getData: async (items) =>
                ref.get(CommentRepository, { strict: false }).find({
                    relations: ['user'],
                    where: { id: In(items) },
                }),
        }),
};
@ApiTags('评论操作')
@Depends(ContentModule)
@Controller('comments')
export class CommentController {
    constructor(protected service: CommentService) {}

    /**
     * 查询评论树
     * @param query
     */
    @Get('tree')
    @SerializeOptions({ groups: ['comment-tree'] })
    @Guest()
    async tree(
        @Query()
        query: QueryCommentTreeDto,
    ) {
        return this.service.findTrees(query);
    }

    /**
     * 查询评论列表
     * @param query
     */
    @Get()
    @SerializeOptions({ groups: ['comment-list'] })
    @Guest()
    async list(
        @Query()
        query: QueryCommentDto,
    ) {
        return this.service.paginate(query);
    }

    /**
     * 新增评论
     * @param data
     */
    @Post()
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['comment-detail'] })
    @Permission(permissions.create)
    async store(
        @Body()
        data: CreateCommentDto,
        @ReqUser() author: ClassToPlain<UserEntity>,
    ) {
        return this.service.create(data, author);
    }

    /**
     * 批量删除评论
     * @param data
     */
    @Delete()
    @ApiBearerAuth()
    @SerializeOptions({ groups: ['comment-list'] })
    @Permission(permissions.owner)
    async delete(
        @Body()
        data: DeleteDto,
    ) {
        const { ids } = data;
        return this.service.delete(ids);
    }
}
```

#### 评论管理

```typescript
const permission: PermissionChecker = async (ab) =>
    ab.can(PermissionAction.MANAGE, CommentEntity.name);
@ApiTags('评论管理')
@ApiBearerAuth()
@Depends(ContentModule)
@Controller('comments')
export class CommentController {
    constructor(protected service: CommentService) {}

    /**
     * 查询评论列表
     * @param query
     */
    @Get()
    @SerializeOptions({ groups: ['comment-list'] })
    @Permission(permission)
    async list(
        @Query()
        query: QueryCommentDto,
    ) {
        return this.service.paginate(query);
    }

    /**
     * 批量删除评论
     * @param data
     */
    @Delete()
    @SerializeOptions({ groups: ['comment-list'] })
    @Permission(permission)
    async delete(
        @Body()
        data: DeleteDto,
    ) {
        const { ids } = data;
        return this.service.delete(ids);
    }
}
```

#### 路由

```typescript
import * as controllers from './controllers';
import * as manageControllers from './controllers/manage';

export const createContentApi = () => {
    const routes: Record<'app' | 'manage', RouteOption[]> = {
        app: [
            {
                name: 'app.content',
                path: 'content',
                controllers: Object.values(controllers),
            },
        ],
        manage: [
            {
                name: 'manage.content',
                path: 'content',
                controllers: Object.values(manageControllers),
            },
        ],
    };
    const tags: Record<'app' | 'manage', Array<string | TagOption>> = {
        app: [
            { name: '分类查询', description: '查询分类信息' },
            { name: '标签查询', description: '查询标签信息' },
            {
                name: '文章操作',
                description: '查询文章以及对自己的文章进行CRUD操作',
            },
            {
                name: '评论操作',
                description: '查看评论以及对自己的评论进行CRD操作',
            },
        ],
        manage: [
            { name: '分类管理', description: '管理分类信息' },
            { name: '标签管理', description: '管理标签信息' },
            { name: '文章管理', description: '管理文章信息' },
            { name: '评论管理', description: '管理评论信息' },
        ],
    };
    return { routes, tags };
};
```

## 其它修改

### 数据迁移

#### 用户数据工厂

```typescript
// src/database/factories/user.factory.ts
export type IUserFactoryOptions = Partial<{
    [key in keyof UserEntity]: UserEntity[key] & { roles?: RoleEntity[] };
}>;
export const UserFactory = defineFactory(
    UserEntity,
    async (configure: Configure, settings: IUserFactoryOptions = {}) => {
        // ...
        user.roles = settings.roles ?? [];
        return user;
    },
);
```

#### 用户数据填充

```typescript
// src/database/seeders/user.seeder.ts
export default class UserSeeder extends BaseSeeder {
    protected truncates = [
        UserEntity,
        AccessTokenEntity,
        RefreshTokenEntity,
        RoleEntity,
        PermissionEntity,
        'rbac_roles_users_users',
    ];

    protected factorier!: DbFactory;

    async run(_factorier: DbFactory, _dataSource: DataSource, _em: EntityManager): Promise<any> {
        this.factorier = _factorier;
        const rbac = new RbacResolver(this.dataSource, this.configure);
        await rbac.syncRoles(this.em);
        await rbac.syncPermissions(this.em);
        await this.loadSuperUser(rbac);
        await this.loadUsers();
    }

    private async loadSuperUser(rbac: RbacResolver) {
        const repository = getCustomRepository(this.dataSource, UserRepository);
        const creator = await repository.findOneBy({ username: 'pincman' });
        const userFactory = this.factorier(UserEntity);
        if (isNil(creator)) {
            await userFactory<IUserFactoryOptions>({
                username: 'pincman',
                nickname: 'pincman',
                password: '123456aA$',
            }).create({}, 'username');
        }
        await rbac.syncSuperAdmin(this.em);
    }

    private async loadUsers() {
        const userRole = await getCustomRepository(this.dataSource, RoleRepository).findOneBy({
            name: SystemRoles.USER,
        });
        const roles = isNil(userRole) ? [] : [userRole];
        const repository = getCustomRepository(this.dataSource, UserRepository);
        const userFactory = this.factorier(UserEntity);
        const count = await repository.count();
        if (count < 2) {
            await userFactory<IUserFactoryOptions>({
                username: 'xiaoming',
                nickname: '小明',
                phone: '+86.18605853847',
                password: '123456aA$',
                roles,
            }).create({}, 'username');

            await userFactory<IUserFactoryOptions>({
                username: 'lige',
                nickname: '李哥',
                phone: '+86.15955959999',
                password: '123456aA$',
                roles,
            }).create({}, 'username');
            await userFactory<IUserFactoryOptions>().createMany(15, { roles }, 'username');
        }
    }
}
```

#### 内容数据填充

```typescript
// src/database/seeders/content.seeder.ts
export default class ContentSeeder extends BaseSeeder {
    // ...
    private async loadPosts(data: PostData[]) {
        const superRole = await this.em.findOneOrFail(RoleEntity, {
            relations: ['permissions'],
            where: { name: SystemRoles.SUPER_ADMIN },
        });

        const superUser = !isNil(superRole)
            ? await this.em
                  .createQueryBuilder(UserEntity, 'user')
                  .leftJoinAndSelect('user.roles', 'roles')
                  .where('roles.id IN (:...ids)', { ids: [superRole.id] })
                  .getOne()
            : null;
        const author = !isNil(superUser) ? superUser : getRandItemData(this.users);
        const allCategories = await this.em.find(CategoryEntity);
       // ...
    }
}
```

### API配置

```typescript
// src/config/api.config.ts
export const v1 = async (configure: Configure): Promise<VersionOption> => {
    const contentApi = createContentApi();
    const userApi = createUserApi();
    const rbacApi = createRbacApi();
    return {
        routes: [
            {
                name: 'app',
                path: '/',
                controllers: [],
                doc: {
                    // title: '应用接口',
                    description:
                        '3R教室《Nestjs实战开发》课程应用的客户端接口（应用名称随机自动生成）',
                    tags: [...contentApi.tags.app, ...userApi.tags.app, ...rbacApi.tags.app],
                },
                children: [...contentApi.routes.app, ...userApi.routes.app, ...rbacApi.routes.app],
            },
            {
                name: 'manage',
                path: 'manage',
                controllers: [],
                doc: {
                    description:
                        '3R教室《Nestjs实战开发》课程应用的应用的后台管理接口（应用名称随机自动生成）',
                    tags: [
                        ...contentApi.tags.manage,
                        ...userApi.tags.manage,
                        ...rbacApi.tags.manage,
                    ],
                },
                children: [
                    ...contentApi.routes.manage,
                    ...userApi.routes.manage,
                    ...rbacApi.routes.manage,
                ],
            },
        ],
    };
};
```

## 启动应用

老样子，走一下几步

:::warning

再次重复上节课的提升，请尽量在执行命令前删除`metadata.ts`

:::

1. 执行`pnpm cli dbmg -r`命令生成并运行迁移
2. 执行`pnpm dbs -i`命令填充数据
3. 执行`pnpm dev`启动应用
4. 把swagger导入到api测试工具进行测试
