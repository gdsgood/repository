---
title: 常用React Hooks详解
sidebar_label:  常用React Hooks详解
hide_title: true
sidebar_position: 3
---

# 常用React Hooks详解

## 准备
关于react的基础知识，比如jsx等等其新官网已经说的非常明确，指直接查看[官网中文文档](https://zh-hans.reactjs.org/learn/describing-the-ui)即可，本教材不再赘述，我们直接开始学习hooks的灵活使用
先安装以下依赖

- immer: 使用proxy实现了不可变数据类型([文档](https://immerjs.github.io/immer/))
- lodash: 一个js工具函数库([文档](https://lodash.com/))

```bash
pnpm add clsx immer lodash --filter=admin
pnpm add @types/lodash -D --filter=admin
```
本节课在Admin应用下开发，创建一个`demo`组件目录

```bash
mkdir -p src/components/demo
```

在`app.css`下添加一个背景图片

:::info

背景图片的网盘下载路径为："资源 > 图片与视频 > ts全栈课" 

:::

```css
/* src/styles/app.css */
...
body {
    @apply bg-[url(./images/bg-light.png)];
}

```

修改`app.module.css`，去除`.app`的背景颜色

```css
/* src/app.module.css */
.app {
    @apply flex flex-auto flex-wrap items-center justify-center;
}
```

在demo中添加一个`style.module.css`，用于设置本课程案例的css样式

```css
/* src/components/demo/style.module.css */
.container {
    @apply bg-neutral-100/40 shadow-black/20 backdrop-blur-sm shadow-md rounded-md p-5 m-5 min-w-[20rem];
}

body(:global(.dark)) {
    .container {
        @apply bg-neutral-800/40  shadow-slate-100/30;
    }
}
```

## useState

此Hook用于改变组件内的状态

此钩子解构出两个值，并赋值到一个数组内

- 第一个元素代表该状态的值
- 第二个元素用于设置状态的值

编写如下示例

```tsx
// src/components/demo/state.tsx
import { Button } from 'antd';
import { clsx } from 'clsx';
import { useState } from 'react';

import $styles from './style.module.css';

const StateDemo: FC = () => {
    const [count, setCount] = useState(1);
    const [isShow, toggleShow] = useState(true);

    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useState Demo</h2>
            {isShow && <p className="text-center py-5">{count}</p>}
            <div className="flex justify-around">
                <Button onClick={() => setCount(count + 1)} type="dashed">
                    增加
                </Button>
                <Button onClick={() => setCount(count - 1)} type="dashed">
                    减少
                </Button>
                <Button onClick={() => toggleShow(!isShow)} type="dashed">
                    {isShow ? '显示' : '隐藏'}
                </Button>
            </div>
        </div>
    );
};
export default StateDemo;
```
然后在`App.tsx`中引入

:::tip

此处我们清空掉上一节tailwind课的代码，重置为react初始化这节课的`App.tsx`，然后引入`StateDemo`组件

:::

```tsx
// src/App.tsx
import { StyleProvider } from '@ant-design/cssinjs';
import { ConfigProvider, theme, App as AntdApp } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import 'dayjs/locale/zh-cn';

import { FC } from 'react';

import $styles from './app.module.css';
import StateDemo from './components/demo/state';

const App: FC = () => {
    return (
        <ConfigProvider
            locale={zhCN}
            theme={{
                algorithm: [theme.compactAlgorithm],
                token: {},
                components: {
                    Layout: {
                        colorBgBody: '',
                    },
                },
            }}
        >
            <StyleProvider hashPriority="high">
                <AntdApp>
                    <div className={$styles.app}>
                        <StateDemo />
                    </div>
                </AntdApp>
            </StyleProvider>
        </ConfigProvider>
    );
};
export default App;

```

查看一下效果

![](https://img.pincman.com/media/202308201348797.gif)

## `useEffect`

在状态不同的生命周期执行副作用

语法为

```tsx
useEffect(() => {
  当依赖项改变时的执行逻辑
  () => {
    在执行逻辑运行前执行的先行逻辑，用于清理等操作
  }
},[依赖项])
```

### 简单用法

**在没有设置"依赖项"时，任何状态的改变都会导致该`useEffect`执行逻辑的运行**

每次状态更新都会执行`useEffect`里面的函数

- 当点击**ghost按钮**时，由于`ghost`的状态变化了，所以会同时执行两个`useEffect`
- 同样地，当**浏览器宽度发生变化**时，也会同时执行两个`useEffect`

```tsx
// src/components/demo/effect.tsx
import { Button } from 'antd';
import { useEffect, useState } from 'react';

import $styles from './style.module.css';

const EffectDemo: FC = () => {
    const [ghost, setGhost] = useState<boolean>(false);
    const [width, setWidth] = useState(window.innerWidth);
    const toggleGhostBtn = () => setGhost(!ghost);
    const resizeHandle = () => setWidth(window.innerWidth);
    useEffect(() => {
        console.log('浏览器宽度改变');
        window.addEventListener('resize', resizeHandle);
    });
    useEffect(() => {
        console.log('切换幽灵按钮');
    });
    return (
        <div className={$styles.container}>
            <h2 className="text-center">useEffect Demo</h2>
            <p className="text-center py-5">{ghost ? 'ghost' : '普通'}按钮</p>
            <div className="flex justify-center flex-col">
                <Button type="primary" onClick={toggleGhostBtn} ghost={ghost}>
                    切换按钮样式
                </Button>
                <p className="pt-5 text-center">宽度为: {width}</p>
            </div>
        </div>
    );
};
export default EffectDemo;
```
然后把这个组件放到`App.tsx`里面

```tsx
// src/App.tsx
...
<div className={$styles.app}>
    <StateDemo />
    <EffectDemo />
</div>
```



效果如下

![](https://img.pincman.com/media/202308201848562.gif)

### 依赖更新

通过`useEffect`的第二个参数,可以指定其依赖的变量

- 只有此变量的状态更改时才会执行副作用函数
- 如果第二个参数为空,则只在第一次渲染和重新渲染时触发
- 在开发环境并且是严格模式下(`src/main.tsx`)，那么每个`useEffect`中的函数在初始化时会被执行两次，而在非严格模式，或者生产环境下执行一次

```tsx
// src/components/demo/effect.tsx
const EffectDemo: FC = () => {
    ...
    useEffect(() => {
        console.log('浏览器宽度改变');
        window.addEventListener('resize', resizeHandle);
    }, [width]);
    useEffect(() => {
        console.log('切换幽灵按钮');
    }, [ghost]);
    useEffect(() => {
        console.log('只在第一次或重新渲染组件时触发');
    }, []);
};
```
![](https://img.pincman.com/media/202308201933324.gif)

### 清理监听

**通过返回一个函数可以在执行逻辑之前进行一些操作**

在监听`width`的`useEffect`中,每次改变`width`的状态,都会添加一个`resize`事件,这会极大的耗费浏览器占用的内存,通过一个返回值的方式,即可在下一次`width`状态改变后与添加新的`resize`监听前,取消上次添加的`resize`监听事件

:::tip

为了方便查看效果，这里我们把所有的`console.log`清除掉

:::

```tsx
// src/components/demo/effect.tsx
const EffectDemo: FC = () => {
    ...
    const resizeHandle = () => setWidth(window.innerWidth);
    useEffect(() => {
        window.addEventListener('resize', resizeHandle);
        return () => {
            window.removeEventListener('resize', resizeHandle);
        };
    }, [width]);
    return (
        <div className={$styles.container}>
         </div>
    );
};
export default EffectDemo;
};
```
### 异步执行
在`useEffect`中执行异步函数的语法如下,其实就是在原函数里调用一个`async`打头的立即函数
```typescript
// src/components/demo/effect.tsx
useEffect(() => {
    (async () => {})();
});
```
以下示例代码让按钮在变成`ghost`之后1s再变红色
```tsx
// src/components/demo/effect.tsx
const EffectDemo: FC = () => {
    const [red, setRed] = useState<boolean>(false);
    ...
    useEffect(() => {
        (async () => {
            await new Promise((resolve, reject) => {
                setTimeout(() => resolve(true), 1000);
            });
            setRed(ghost);
        })();
    }, [ghost]);
    return (
        ...
        <div className="flex justify-center flex-col">
            <Button type="primary" onClick={toggleGhostBtn} ghost={ghost} danger={red}>
                切换按钮样式
            </Button>
            <p className="pt-5 text-center">宽度为: {width}</p>
        </div>
    );
};
```
效果如图

![](https://img.pincman.com/media/202308210628488.gif)

## useRef

这个钩子用于记忆前一次操作的值

以下示例代表只有在在数据更新时才会调用函数，而第一次渲染不会执行函数

```tsx
// src/components/demo/ref.tsx
import { Button } from 'antd';
import clsx from 'clsx';
import { useEffect, useRef, useState } from 'react';

import $styles from './style.module.css';

const RefDemo: FC = () => {
    const [count, setCount] = useState(0);
    const inited = useRef(count);
    useEffect(() => {
        if (inited.current !== count) {
            inited.current = count
            console.log('changed');
        }
    }, [count]);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useRef Demo</h2>
            <p className="text-center py-5">{count}</p>
            <div className="flex justify-around">
                <Button onClick={() => setCount(Math.ceil(Math.random() * 10))} type="dashed">
                    变化
                </Button>
            </div>
        </div>
    );
};
export default RefDemo;

...
<div className={$styles.app}>
    <StateDemo />
    <EffectDemo />
    <RefDemo />
</div>
```

### forwardRef

结合`forwardRef`我们可以操作子组件

以下代码，我们与子组件建立一个双向通讯的同时，还可以通过`ref`去操作这个组件

```tsx
// src/components/demo/ref.tsx
const MyInput = forwardRef<HTMLInputElement, { value: number; changeValue: (v: number) => void }>(
    ({ value, changeValue }, ref) => {
        const [local, setLocal] = useState<number | string>(value);
        useEffect(() => {
            changeValue(isNaN(Number(local)) ? 0 : Number(local));
        }, [changeValue, local]);
        const handleChange: ChangeEventHandler<HTMLInputElement> = useCallback((e) => {
            setLocal(e.target.value);
        }, []);
        return <input value={value} ref={ref} placeholder="请输入值" onChange={handleChange} />;
    },
);

const RefDemo: FC = () => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLInputElement | null>(null);
    useEffect(() => {
        ref.current.focus();
    }, []);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useRef Demo</h2>
            <p className="text-center py-5">{count}</p>
            <div className="flex justify-around mb-5">
                <Button onClick={() => setCount(Math.ceil(Math.random() * 10))} type="dashed">
                    变化
                </Button>
            </div>
            <div className="flex flex-col">
                <MyInput ref={ref} value={count} changeValue={setCount} />
            </div>
        </div>
    );
};
export default RefDemo;
```

### useImperativeHandle

这个Hook用于在子组件中添加一些函数，然后这些函数可以在父组件中传入的`ref`来绑定，这样就可以在父组件中调用这些子组件中的函数了

此Hook接受三个参数

- ref
- 返回给父组件的对象
- 更新依赖值

编写如下示例

```tsx
// src/components/demo/ref.tsx
...
import { isNil, isNaN } from 'lodash';

interface RefFunc {
    focus: () => void;
    memo: () => number;
}

const MyInput = forwardRef<RefFunc, { value: number; changeValue: (v: number) => void }>(
    ({ value, changeValue }, ref) => {
        const [local, setLocal] = useState<number | string>(value);
        const inputRef = useRef<HTMLInputElement | null>(null);
        useImperativeHandle(
            ref,
            () => ({
                focus: () => inputRef.current.focus(),
                memo: () => value,
            }),
            [value],
        );
        useEffect(() => {
            changeValue(isNaN(Number(local)) ? 0 : Number(local));
        }, [changeValue, local]);
        const handleChange: ChangeEventHandler<HTMLInputElement> = useCallback((e) => {
            setLocal(e.target.value);
        }, []);
        return (
            <input value={value} ref={inputRef} placeholder="请输入值" onChange={handleChange} />
        );
    },
);

const RefDemo: FC = () => {
    const [count, setCount] = useState(0);
    const ref = useRef<RefFunc | null>(null);
    useEffect(() => {
        ref.current.focus();
    }, []);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useRef Demo</h2>
            <p className="text-center py-5">{count}</p>
            <div className="flex justify-around mb-5">
                <Button onClick={() => setCount(Math.ceil(Math.random() * 10))} type="dashed">
                    变化
                </Button>
            </div>
            <div className="flex flex-col">
                {!isNil(ref.current) && <p className="mb-3">前一个值：{ref.current.memo()}</p>}
                <MyInput ref={ref} value={count} changeValue={setCount} />
            </div>
        </div>
    );
};
export default RefDemo;
```

## useMemo

这个Hook用于缓存一些值，只有当它的依赖项改变时才能返回新的值

语法如下

:::info

当依赖项改变时，会自行执行函数返回新的值

:::

```tsx
useMemo(() => {
  返回值
},[依赖项])
```

编写以下示例

:::tip

别忘了在`App.tsx`中导入

:::

```tsx
// src/components/demo/memo.tsx
const ChildCom1: FC<{ value: number }> = () => {
    console.log('渲染子组件1');
    return null;
};
const ChildCom2: FC<{ value: number }> = () => {
    console.log('渲染子组件2');
    return null;
};
const MemoDemo: FC = () => {
    const [count1, setCount1] = useState<number>(0);
    const [count2, setCount2] = useState<number>(0);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useMemo Demo</h2>
            <div className="flex justify-around">
                <Button onClick={() => setCount1(Math.ceil(Math.random() * 10))} type="dashed">
                    变化coun1
                </Button>
                <Button onClick={() => setCount2(Math.ceil(Math.random() * 10))} type="dashed">
                    变化coun2
                </Button>
            </div>
            <div className="flex justify-around">
                <ChildCom1 value={count1} />
                <ChildCom2 value={count2} />
            </div>
        </div>
    );
};
export default MemoDemo;
```

可以看到每次，点击两个按钮中的任何一个，两个子组件都会被渲染

![](https://img.pincman.com/media/202308211931439.gif)

这样子，如果一个组件内有一批子组件，每个子组件又有很多子组件，则会出现大量的重复渲染而导致应用的性能问题

下面我们来改造一下，编变成这样

```tsx
// src/components/demo/memo.tsx
...
const MemoDemo: FC = () => {
    const [count1, setCount1] = useState<number>(0);
    const [count2, setCount2] = useState<number>(0);
    const ChildWrap1 = useMemo(() => <ChildCom1 value={count1} />, [count1]);
    const ChildWrap2 = useMemo(() => <ChildCom2 value={count2} />, [count2]);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useMemo Demo</h2>
            <div className="flex justify-around">
                <Button onClick={() => setCount1(Math.ceil(Math.random() * 10))} type="dashed">
                    变化coun1
                </Button>
                <Button onClick={() => setCount2(Math.ceil(Math.random() * 10))} type="dashed">
                    变化coun2
                </Button>
            </div>
            <div className="flex justify-around">
                {ChildWrap1}
                {ChildWrap2}
            </div>
        </div>
    );
};
```

我们使用`useMemo`把组件包起来，这样的话，只有在它的依赖更新时才会重新渲染这个子组件，于是就出现两个子组件互不影响的效果了

![](https://img.pincman.com/media/202308211938025.gif)

`useMemo`的使用场景非常多，我们将在后续课程中继续深入

#### memo函数

另外，如果只是像上述例子一样，简单的防止子组件重复渲染的话，也可以使用`memo`函数。这会根据传入到子组件的props(参数)的变化来确定是否渲染该子组件，达到的效果跟`useMemo`是一样的

```tsx
// src/components/demo/memo.tsx
const ChildCom1: FC<{ value: number }> = memo(() => {
    console.log('渲染子组件1');
    return null;
});
const ChildCom2: FC<{ value: number }> = memo(() => {
    console.log('渲染子组件2');
    return null;
});
const MemoDemo: FC = () => {
    ...
            <div className="flex justify-around">
                <ChildCom1 value={count1} />
                <ChildCom2 value={count2} />
            </div>
};
export default MemoDemo;
```

## useCallback

这个钩子与`useMemo`类似，只不过`useMemo`缓存的是一个函数中的返回值，而`useCallback`直接缓存函数本身

语法如下

```tsx
useCallback(() => {},[依赖项])
```

例如以下代码，由于在点击按钮时`useState`解析出来的值会发生变化，从而导致组件被重新渲染，这导致`setCount`和`getInfo`这两个函数的堆栈地址发生变化

```tsx
// src/components/demo/callback.tsx
const Info: FC<{ call: () => void }> = memo(() => {
    console.log('渲染消息');
    return null;
});

export const CallbackDemo: FC = () => {
    const [, setCount] = useState<number>(0);
    const changeCount = () => setCount(Math.ceil(Math.random() * 10));
    const getInfo = () => {};
    useEffect(() => {
        console.log('getInfo函数的值改变');
    }, [getInfo]);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">useCallback Demo</h2>
            <div className="flex justify-around">
                <Info call={getInfo} />
                <Button onClick={changeCount} type="dashed">
                    变化coun1
                </Button>
            </div>
        </div>
    );
};
```

效果

![](https://img.pincman.com/media/202308221536783.gif)

由于`Info`组件不依赖于`setCount`而只依赖`getInfo`，所以我们可以用`useCallback`对`getInfo`做个缓存，这样即使`setCount`函数的堆栈发生变化也不影响`getInfo`函数

```tsx
// src/components/demo/callback.tsx
export const CallbackDemo: FC = () => {
    const [, setCount] = useState<number>(0);
    const changeCount = () => setCount(Math.ceil(Math.random() * 10));
    const getInfo = useCallback(() => {}, []);
...
};

```

![](https://img.pincman.com/media/202308221543670.gif)

## useContext

用于向后代组件透传一个值（状态）,以创建一个语言选择器为例
### 定义类型
```typescript
// src/components/demo/types.ts
export type LocaleType = {
    name: string;
    label: string;
};
export type LocaleState = {
    locale: LocaleType;
    setLocale: (locale: LocaleType) => void;
};
```
### 定义语言列表
```typescript
// src/components/demo/constants.ts
import { Locale } from 'antd/es/locale';
import enUS from 'antd/es/locale/en_US';
import zhCN from 'antd/es/locale/zh_CN';
import { createContext } from 'react';

import { LocaleState, LocaleType } from './types';

export const localeData: Record<string, Locale> = {
    en_US: enUS,
    zh_CN: zhCN,
};
export const locales: LocaleType[] = [
    {
        name: 'en_US',
        label: '🇺🇸 english(US)',
    },
    {
        name: 'zh_CN',
        label: '🇨🇳 简体中文',
    },
];
```
### 创建context
```typescript
// src/components/demo/context.tsx
export const LocaleContext = createContext<LocaleState>({
    locale: locales[0],
    setLocale: (_locale: LocaleType) => {},
});
```
### 创建provider包装器
```tsx
// src/components/demo/context.tsx
const LocaleProvider: FC<LocaleState & { children?: ReactNode }> = ({
    locale,
    setLocale,
    children,
}) => {
    const value = useMemo(() => ({ locale, setLocale }), [locale]);
    return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
};
```
### 创建Locale组件
```tsx
// src/components/demo/context.tsx
export const Locale: FC<{ children?: ReactNode }> = ({ children }) => {
    const [locale, setLocale] = useState<LocaleType>(locales[0]);
    const changeLocale = useCallback((value: LocaleType) => {
        if (Object.keys(localeData).find((v) => v === value.name)) {
            setLocale(value);
        }
    }, []);
    return (
        <LocaleProvider locale={locale} setLocale={changeLocale}>
            {children}
        </LocaleProvider>
    );
};
```
### App.tsx包装
首先，把原来的`App`组件改成`Main`组件

然后创建一个新的`App`组件，把`Main`包含于`Locale`组件中，这样就可以使用`useContext`来获取状态了

```tsx
// src/App.tsx
const Main: FC = () => {
    return (
        <ConfigProvider
            locale={zhCN}
            theme={{
                algorithm: [theme.defaultAlgorithm],
                token: {},
                components: {
                    Layout: {
                        colorBgBody: '',
                    },
                },
            }}
        >
            <StyleProvider hashPriority="high">
                <AntdApp>
                    <div className={$styles.app}>
                        {/* <StateDemo />
                        <EffectDemo />
                        <RefDemo />
                        <MemoDemo />
                        <CallbackDemo /> */}
                    </div>
                </AntdApp>
            </StyleProvider>
        </ConfigProvider>
    );
};
const App: FC = () => (
    <Locale>
        <Main />
    </Locale>
);
export default App;
```
### 语言选择组件
```tsx
// src/components/demo/context.tsx
export const LocaleConfig: FC = () => {
    const { locale, setLocale } = useContext(LocaleContext);
    const changeLocale = (value: string) => {
        const current = locales.find((item) => item.name === value);
        current && setLocale(current);
    };
    return (
        <Select defaultValue={locale.name} style={{ width: 120 }} onChange={changeLocale}>
            {locales.map(({ name, label }) => (
                <Select.Option key={name} value={name}>
                    {label}
                </Select.Option>
            ))}
        </Select>
    );
};
```
### Demo组件
```tsx
// src/components/demo/context.tsx
const ContextDemo: FC = () => {
    const { locale } = useContext(LocaleContext);
    return (
        <div className={$styles.container}>
            <h2 className="text-center">useContext Demo</h2>
            <p className="text-center py-5">当前语言: {locale.label}</p>
            <div className="w-full">
                <h3>Antd语言切换测试</h3>
                <div className="w-full my-4">
                    <LocaleConfig />
                </div>
            </div>
            <Pagination defaultCurrent={0} total={500} />
        </div>
    );
};
export default ContextDemo;
```
加入Demo组件
```tsx
// src/App.tsx
const Main: FC = () => {
    const { locale } = useContext(LocaleContext);
    const antdLocaleData = useMemo(() => {
        if (!Object.keys(localeData).find((v) => v === locale.name)) {
            return localeData[0];
        }
        return localeData[locale.name];
    }, [locale.name]);
    return (
        <ConfigProvider
            locale={antdLocaleData}
            theme={{
                algorithm: [theme.defaultAlgorithm],
                token: {},
                components: {
                    Layout: {
                        colorBgBody: '',
                    },
                },
            }}
        >
            <StyleProvider hashPriority="high">
                <AntdApp>
                    <div className={$styles.app}>
                        <ContextDemo />
                    </div>
                </AntdApp>
            </StyleProvider>
        </ConfigProvider>
    );
};
```
![](https://img.pincman.com/media/202308221931352.gif)

## useReducer

使用`Context`+`useReducer`可以实现轻量级的全局状态管理
以实现一个简单的应用配置功能为例(包含标题设置和暗黑模式切换)

### 修改CSS

修改一下全局的css，让应用在暗黑模式下加载不同的背景图片

```css
body {
    @apply bg-[url(./images/bg-light.png)];
}

body.dark {
    @apply bg-[url(./images/bg-dark.png)];
}
```

### 编写类型
```typescript
// src/components/demo/types.ts
export enum ThemeMode {
    LIGHT = 'light',
    DARK = 'dark',
}

export type ThemeState = {
    mode: `${ThemeMode}`;
    compact: boolean;
};

export enum ThemeActionType {
    CHANGE_MODE = 'change_mode',
    CHANGE_COMPACT = 'change_compact',
}

export type ThemeAction =
    | { type: `${ThemeActionType.CHANGE_MODE}`; value: `${ThemeMode}` }
    | { type: `${ThemeActionType.CHANGE_COMPACT}`; value: boolean };

export type ThemeContextType = {
    state: ThemeState;
    dispatch: Dispatch<ThemeAction>;
};
```
### 默认配置
```typescript
// src/components/demo/constants.ts
export const defaultThemeConfig: ThemeState = {
    mode: 'light',
    compact: false,
};
```
### 创建Context
```typescript
// src/components/demo/constants.ts
// 透传配置状态与dispatch
export const ThemeContext = createContext<ThemeContextType | null>(null);
```
### 状态操作
为了确保数据的唯一性不被污染,使用[immer.js][]操作数据
```typescript
// src/components/demo/reducer.tsx
const ThemeReducer: Reducer<ThemeState, ThemeAction> = produce((draft, action) => {
    switch (action.type) {
        case 'change_mode':
            draft.mode = action.value;
            break;
        case 'change_compact':
            draft.compact = action.value;
            break;
        default:
            break;
    }
});
```
### 包装器组件

- 合并默认配置和初始化配置
- 把配置状态和`dispatch`传给`ThemeContext`
```tsx
// src/components/demo/reducer.tsx
export const Theme: FC<{ data?: ThemeState; children?: ReactNode }> = ({ data = {}, children }) => {
    const [state, dispatch] = useReducer(ThemeReducer, data, (initData) => ({
        ...defaultThemeConfig,
        ...initData,
    }));
    useEffect(() => {
        const body = document.getElementsByTagName('body');
        if (body.length) {
            body[0].classList.remove('light');
            body[0].classList.remove('dark');
            body[0].classList.add(state.mode === 'dark' ? 'dark' : 'light');
        }
    }, [state.mode]);
    const value = useMemo(() => ({ state, dispatch }), [state]);
    return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};
```
### 主题选择组件
```tsx
// src/components/demo/reducer.tsx
export const ThemeConfig: FC = () => {
    const context = useContext(ThemeContext);
    if (isNil(context)) return null;
    const { state, dispatch } = context;
    const toggleMode = () =>
        dispatch({ type: 'change_mode', value: state.mode === 'light' ? 'dark' : 'light' });
    const toggleCompact = () => dispatch({ type: 'change_compact', value: !state.compact });
    return (
        <>
            <Switch
                checkedChildren="🌛"
                unCheckedChildren="☀️"
                onChange={toggleMode}
                checked={state.mode === 'dark'}
                defaultChecked={state.mode === 'dark'}
            />
            <Switch
                checkedChildren="紧凑"
                unCheckedChildren="正常"
                onChange={toggleCompact}
                checked={state.compact}
                defaultChecked={state.compact}
            />
        </>
    );
};
```
### Demo组件
```tsx
// src/components/demo/reducer.tsx
const ReducerDemo: FC = () => {
    const context = useContext(ThemeContext);
    if (isNil(context)) return null;
    const {
        state: { mode, compact },
    } = context;
    return (
        <div className={$styles.container}>
            <h2 className="text-center">useReducer Demo</h2>
            <div className="flex items-center flex-col">
                <p>主题模式: 「{mode === 'dark' ? '暗黑' : '明亮'}」</p>
                <p>是否紧凑: 「{compact ? '是' : '否'}」</p>
                <div className="flex-auto mb-5">
                    <ThemeConfig />
                </div>
                <div className="max-w-md">
                    <Calendar fullscreen={false} />
                </div>
            </div>
        </div>
    );
};

export default ReducerDemo;
```
### 在`App.tsx`中包装
```tsx
// src/App.tsx
...
import { ConfigProvider, theme, App as AntdApp } from 'antd';
const Main: FC = () => {
    const { locale } = useContext(LocaleContext);
    const antdLocaleData = useMemo(() => {
        if (!Object.keys(localeData).find((v) => v === locale.name)) {
            return localeData[0];
        }
        return localeData[locale.name];
    }, [locale.name]);
    const { state: themeState } = useContext(ThemeContext);
    const algorithm = useMemo(() => {
        const result = [themeState.compact ? theme.compactAlgorithm : theme.defaultAlgorithm];
        if (themeState.mode === 'dark') result.push(theme.darkAlgorithm);
        return result;
    }, [themeState]);
    return (
        <ConfigProvider
            locale={antdLocaleData}
            theme={{
                algorithm,
                token: {},
                components: {
                    Layout: {
                        colorBgBody: '',
                    },
                },
            }}
        >
            <StyleProvider hashPriority="high">
                <AntdApp>
                    <div className={$styles.app}>
                        {/* <StateDemo />
                        <EffectDemo />
                        <RefDemo />
                        <MemoDemo />
                        <CallbackDemo /> */}
                        <ContextDemo />
                        <ReducerDemo />
                    </div>
                </AntdApp>
            </StyleProvider>
        </ConfigProvider>
    );
};

const App: FC = () => (
    <Locale>
        <Theme>
            <Main />
        </Theme>
    </Locale>
);
export default App;
```
![ooo](https://img.pincman.com/media/202308230028935.gif)

## 自定义Hooks

自定义的Hook必须是以`use`开头的函数

我们先把`useContext(ThemeContext)`以及`useContext(LocaleContext)`改装成自定义Hook

```tsx
// src/components/demo/custom.tsx
export const useTheme = () => {
    const context = useContext(ThemeContext) ?? ({} as Record<string, any>);
    return useMemo(
        () => (isNil(context.state) ? defaultThemeConfig : context.state),
        [context.state],
    );
};

export const useThemeAction = () => {
    const context = useContext(ThemeContext) ?? ({} as Record<string, any>);
    return useCallback(isNil(context.dispatch) ? null : context.dispatch, [context.dispatch]);
};

export const useLocale = () => {
    const context = useContext(LocaleContext) ?? ({} as Record<string, any>);
    return useMemo(() => (isNil(context.locale) ? locales[0] : context.locale), [context.locale]);
};

export const useLocaleAction = () => {
    const context = useContext(LocaleContext) ?? ({} as Record<string, any>);
    return useCallback(isNil(context.setLocale) ? null : context.setLocale, [context.setLocale]);
};
```

然后我们使用这些自定义Hook改变原来的直接`useContext`的方式

```tsx
// src/App.tsx
const Main: FC = () => {
    const locale = useLocale();
    const antdLocaleData = useMemo(() => {
        if (!Object.keys(localeData).find((v) => v === locale.name)) {
            return localeData[0];
        }
        return localeData[locale.name];
    }, [locale.name]);
    const themeState = useTheme();
    const algorithm = useMemo(() => {
        const result = [themeState.compact ? theme.compactAlgorithm : theme.defaultAlgorithm];
        if (themeState.mode === 'dark') result.push(theme.darkAlgorithm);
        return result;
    }, [themeState]);
...
}
```

```tsx
// src/components/demo/context.tsx
export const LocaleConfig: FC = () => {
    const locale = useLocale();
    const setLocale = useLocaleAction();
   ...
};

const ContextDemo: FC = () => {
    const locale = useLocale();
    ...
};
export default ContextDemo;
```

下面，我们再尝试编写一个只在状态更新后执行副作用的`useEffect`(禁用第一次渲染就执行的模式) - `useUpdateEffect`

```tsx
// src/components/demo/context.tsx
export const useUpdateEffect = (effect: EffectCallback, deps?: DependencyList) => {
    const inited = useRef(deps);
    useEffect(() => {
        if (!isEqual(inited.current, deps)) {
            inited.current = deps;
            effect();
        }
    }, [deps]);
};

const CustomDemo: FC = () => {
    const [count, setCount] = useState(0);
    useUpdateEffect(() => {
        console.log('changed');
    }, [count]);
    return (
        <div className={clsx($styles.container, 'w-[20rem]')}>
            <h2 className="text-center">Custom Demo</h2>
            <p className="text-center py-5">{count}</p>
            <div className="flex justify-around">
                <Button onClick={() => setCount(Math.ceil(Math.random() * 10))} type="dashed">
                    变化
                </Button>
            </div>
        </div>
    );
};
export default CustomDemo;
```

至此，本节课完结！
