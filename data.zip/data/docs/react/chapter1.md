---
title: Vite+React18+Eslint+Stylelint+TailwindCSS+Antd应用初始化
sidebar_label: Vite+React18+TailwindCSS应用初始化
hide_title: true
sidebar_position: 1
---

# Vite+React18+Eslint+Stylelint+TailwindCSS+Antd应用初始化

:::caution
本节涉及到非常多的格式化配置,但是对开发应用实际助力不大,所以如果嫌麻烦.
请直接下载[classroom/react](https://git.3rcd.com/classroom/react)模板对着文档学习即可,**不建议手动去配置**
:::

:::info
Node环境的安装与配置请参考[nestjs课程的第一节](../nestjs/chapter1.md)
:::

## 创建应用
使用以下命令来创建一个`vite`+`react`的项目
```bash
pnpm create vite
reactapp # 这里随便取一个应用名称，另外可能出现卡主的现象，但是你按下键盘上任意一个字符就会出现"Project name"，输入你要创建的项目文件夹名称即可，然后按下回车键
# 这一步选择React，按下回车键
# 这一步选择Typescript, 注意不要选择"Typescript-swc"，实测使用swc，后面会有问题，按下回车键
cd reactapp #进入应用目录
pnpm i # 安装依赖
pnpm dev # 启动应用，启动后会提示访问地址，点击打开地址链接
```

打开应用地址后是这样的
![](https://img.pincman.com/media/202304040307260.png#id=NZJAz&originHeight=1888&originWidth=2942&originalType=binary&ratio=1&rotation=0&showTitle=false&status=done&style=none&title=)

## 环境配置

### 使用Commonjs
默认vite使用了ESM模块，为了编码方便，我们需要把它改成Commonjs模块.

首先，把`package.json`中的`"type": "module"`删除.

然后，把`tsconfig.node.json`改成如下这样

```json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "CommonJS",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
```

现在，我们把`.eslintrc.cjs`改成`.eslintrc.js`也可以用了

### Typescript

设置`allowJs`和`esModuleInterop`为`true`,并添加一些其它规则后`tsconfig.json`的配置如下

```json
// tsconfig.json
{
  "compilerOptions": {
    "target": "ESNext",
    "useDefineForClassFields": true,
    "lib": ["DOM", "DOM.Iterable", "ESNext"],
    "module": "ESNext",
    "skipLibCheck": true,

    /* Bundler mode */
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",

    /* Linting */
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,

    /* Others */
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "forceConsistentCasingInFileNames": true,
    "removeComments": true,
    "experimentalDecorators": true,
    "alwaysStrict": true,
    "sourceMap": true,
    "incremental": true,
    "noImplicitReturns": true,
    "pretty": true,
    "noImplicitAny": true,
    "importsNotUsedAsValues": "remove"
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

### Prettier

```bash
pnpm add prettier -D
```

新增`.pretterrc.js`以添加prettier配置

```javascript
// .prettierrc.js
/** @format */
module.exports = {
    singleQuote: true,
    trailingComma: 'all',
    printWidth: 100,
    proseWrap: 'never',
    endOfLine: 'auto',
    semi: true,
    tabWidth: 4,
    vueIndentScriptAndStyle: true,
    htmlWhitespaceSensitivity: 'strict',
    overrides: [
        {
            files: '.prettierrc',
            options: {
                parser: 'json',
            },
        },
        {
            files: 'document.ejs',
            options: {
                parser: 'html',
            },
        },
    ],
};
```

添加.prettierignore，用于忽略不需要prettier处理的文件

```json
dist
node_modules
**/*.svg
**/*.md
**/*.svg
**/*.ejs
**/*.html
**/*.png
**/*.toml
.dockerignore
.DS_Store
.eslintignore
docker
.editorconfig
Dockerfile*
.gitignore
.prettierignore
LICENSE
.eslintcache
*.lock
yarn-error.log
```

### Eslint
我们使用airbnb的编码风格来编写代码，为了支持eslint+prettier来统一代码风格，需要安装以下依赖
其中`eslint-plugin-prettier`与`eslint-config-prettier`用于整合prettier，以防止规则冲突

```bash
pnpm add eslint \
          eslint-config-airbnb \
          eslint-config-airbnb-typescript \
          eslint-config-prettier \
          eslint-plugin-import \
          eslint-plugin-jsx-a11y \
          eslint-plugin-prettier \
          eslint-plugin-react \
          eslint-plugin-react-hooks \
          eslint-plugin-unused-imports \
          @typescript-eslint/eslint-plugin \
          @typescript-eslint/parser -D
```

一个`tsconfig.eslint.json`文件用于设置在eslint在格式化代码时需要额外包含的文件

```json
// tsconfig.eslint.json
{
  "extends": "./tsconfig.json",
  "include": [
    "./src",
    "./test",
    "./typings",
    "./scripts",
    "**.js",
    "**.ts"
  ],
  "exclude": ["node_modules"]
}
```

新增`.eslintrc.js`用于设置eslint的配置。与Nestjs的Eslint配置大体相同，一些不同的地方是

- 在`parserOptions`中启用了`jsx`
- 在`env`中增加了`es6`和`browser`
- `extends`中把airbnb的`airbnb-base`和`airbnb-typescript/base`的`base`给去掉了，因为`base`是不支持react的不完整版
- 增加了`airbnb/hooks`，以支持`react`
- 同时在`ruls`中添加了一些常用的`react`与`jsx-a11y`的规则配置
```javascript
module.exports = {
    root: true,
    parser: '@typescript-eslint/parser',
    parserOptions: {
        // 指定ESLint可以解析JSX语法
        ecmaVersion: 'latest',
        sourceType: 'module',
        project: './tsconfig.eslint.json',
        // React启用jsx
        ecmaFeatures: {
            jsx: true,
        },
    },
    env: { browser: true, es2024: true },
    ignorePatterns: ['dist'],
    plugins: ['@typescript-eslint', 'react-refresh', 'prettier', 'import', 'unused-imports'],
    extends: [
        // airbnb规范
        // https://github.com/airbnb/javascript/tree/master/packages/eslint-config-airbnb
        'airbnb',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript',
        // react hooks的airbnb规范
        'airbnb/hooks',

        // typescript的eslint插件
        // https://github.com/typescript-eslint/typescript-eslint/blob/master/docs/getting-started/linting/README.md
        // https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/eslint-plugin
        'plugin:@typescript-eslint/recommended',
        'plugin:@typescript-eslint/recommended-requiring-type-checking',

        // 使用prettier格式化代码
        // https://github.com/prettier/eslint-config-prettier#readme
        'prettier',
        // 整合typescript-eslint与prettier
        // https://github.com/prettier/eslint-plugin-prettier
        'plugin:prettier/recommended',
    ],
    rules: {
        /* ********************************** ES6+ ********************************** */
        'no-console': 0,
        'no-var-requires': 0,
        'no-restricted-syntax': 0,
        'no-continue': 0,
        'no-await-in-loop': 0,
        'no-return-await': 0,
        'no-multi-assign': 0,
        'no-param-reassign': [2, { props: false }],
        'max-classes-per-file': 0,
        'class-methods-use-this': 0,
        'guard-for-in': 0,
        'no-underscore-dangle': 0,
        'no-plusplus': 0,
        'no-lonely-if': 0,
        'no-bitwise': ['error', { allow: ['~'] }],

        /* ********************************** Module Import ********************************** */

        'import/prefer-default-export': 0,
        'import/no-cycle': 0,
        'import/no-dynamic-require': 0,
        'import/no-absolute-path': 0,
        'import/extensions': 0,

        // 一部分文件在导入devDependencies的依赖时不报错
        'import/no-extraneous-dependencies': [
            1,
            {
                devDependencies: [
                    'scripts/**/*.{ts,js}',
                    '**/*.test.{ts,js,tsx}',
                    '**/*.spec.{ts,js,tsx}',
                    '**.{ts,js}',
                ],
            },
        ],
        // 模块导入顺序规则
        'import/order': [
            1,
            {
                pathGroups: [
                    {
                        pattern: '@/**',
                        group: 'external',
                        position: 'after',
                    },
                ],
                'newlines-between': 'always-and-inside-groups',
                warnOnUnassignedImports: true,
            },
        ],
        // 自动删除未使用的导入
        // https://github.com/sweepline/eslint-plugin-unused-imports
        'no-unused-vars': 0,
        '@typescript-eslint/no-unused-vars': 0,
        'unused-imports/no-unused-imports': 1,
        'unused-imports/no-unused-vars': [
            'error',
            {
                vars: 'all',
                args: 'none',
                ignoreRestSiblings: true,
            },
        ],

        /* ********************************** Typescript ********************************** */
        '@typescript-eslint/no-empty-interface': 0,
        '@typescript-eslint/no-this-alias': 0,
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/no-use-before-define': 0,
        '@typescript-eslint/explicit-member-accessibility': 0,
        '@typescript-eslint/no-non-null-assertion': 0,
        '@typescript-eslint/no-unnecessary-type-assertion': 0,
        '@typescript-eslint/require-await': 0,
        '@typescript-eslint/no-for-in-array': 0,
        '@typescript-eslint/interface-name-prefix': 0,
        '@typescript-eslint/explicit-function-return-type': 0,
        '@typescript-eslint/no-explicit-any': 0,
        '@typescript-eslint/explicit-module-boundary-types': 0,
        '@typescript-eslint/no-floating-promises': 0,
        '@typescript-eslint/restrict-template-expressions': 0,
        '@typescript-eslint/no-unsafe-assignment': 0,
        '@typescript-eslint/no-unsafe-return': 0,
        '@typescript-eslint/no-unused-expressions': 0,
        '@typescript-eslint/no-misused-promises': 0,
        '@typescript-eslint/no-unsafe-member-access': 0,
        '@typescript-eslint/no-unsafe-call': 0,
        '@typescript-eslint/no-unsafe-argument': 0,

        /* ********************************** React and Hooks ********************************** */
        'react/jsx-uses-react': 1,
        'react/jsx-uses-vars': 1,
        'react/jsx-no-useless-fragment': 0,
        'react/display-name': 0,
        'react/button-has-type': 0,
        'react/prop-types': 0,
        'react/jsx-props-no-spreading': 0,
        'react/destructuring-assignment': 0,
        'react/static-property-placement': 0,
        'react/react-in-jsx-scope': 0,
        'react/require-default-props': 0,
        'react/jsx-filename-extension': [1, { extensions: ['.jsx', '.tsx'] }],
        'react/function-component-definition': [
            2,
            { namedComponents: 'arrow-function', unnamedComponents: 'arrow-function' },
        ],
        'react-hooks/exhaustive-deps': 0,
        'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],

        /* ********************************** jax-a11y ********************************** */
        'jsx-a11y/anchor-is-valid': 0,
        'jsx-a11y/no-static-element-interactions': 0,
        'jsx-a11y/click-events-have-key-events': 0,
        'jsx-a11y/label-has-associated-control': [
            'error',
            {
                required: {
                    some: ['nesting', 'id'],
                },
            },
        ],
    },

    settings: {
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.d.ts', '.json'],
    },
};
```

添加一个`.eslintignore`文件，并把以下内容复制进去，这可以忽略不需要eslint格式化的文件

```json
dist
back
public
node_modules
pnpm-lock.yaml
docker
Dockerfile*
LICENSE
yarn-error.log
.history
.vscode
.docusaurus
.dockerignore
.DS_Store
.eslintignore
.editorconfig
.gitignore
.prettierignore
.eslintcache
*.lock
**/*.svg
**/*.md
**/*.svg
**/*.ejs
**/*.html
**/*.png
**/*.toml
```

在`package.json`中修改原来的`lint`命令为`lint:es`命令，并加上`fix`选项

```json
"scripts": {
    "lint:es": "eslint . --ext ts,tsx --fix --report-unused-disable-directives --max-warnings 0",
    ...
},
```

运行`pnpm run lint:es`即可格式化

可以看到在`src/App.tsx`有个`count`错误，这是因为`count`与顶部的变量重名了，我们把它改成`c`等其它名称就可以了

```tsx
// src/App.tsx
<button onClick={() => setCount((c) => c + 1)}>count is {count}</button>
```

### Stylelint
sylelint用于定制和统一css代码的风格
安装以下依赖

```bash
pnpm add stylelint \
          stylelint-config-css-modules \
          stylelint-config-recess-order \
          stylelint-config-standard \
          stylelint-prettier -D
```

新增.stylelintrc.js以配置stylelint
```javascript
// .stylelintrc.js
module.exports = {
    extends: [
        'stylelint-config-standard',
        'stylelint-config-css-modules',
        'stylelint-config-recess-order',
        'stylelint-prettier/recommended',
    ],
    rules: {
        'import-notation': 'string', // 使用string方式引入其它css文件，而不是url()
        'selector-type-no-unknown': null,
        'selector-class-pattern': null,
        'custom-property-pattern': null,
        'no-duplicate-selectors': null, // 取消禁止重复定义,这样可以在css module中单独定义变量
        'block-no-empty': null, // 禁止出现空块
        'declaration-empty-line-before': 'never',
        'declaration-block-no-duplicate-properties': true, // 在声明的块中中禁止出现重复的属性
        'declaration-block-no-redundant-longhand-properties': true, // 禁止使用可以缩写却不缩写的属性
        'shorthand-property-no-redundant-values': true, // 禁止在简写属性中使用冗余值
        'color-hex-length': 'short', // 指定十六进制颜色是否使用缩写
        'comment-no-empty': true, // 禁止空注释
        'font-family-name-quotes': 'always-unless-keyword', // 指定字体名称是否需要使用引号引起来 | 期待每一个不是关键字的字体名都使用引号引起来
        // 'font-weight-notation': 'numeric', // 要求使用数字或命名的 (可能的情况下) font-weight 值
        'function-url-quotes': 'always', // 要求或禁止 url 使用引号
        'property-no-vendor-prefix': true, // 禁止属性使用浏览器引擎前缀
        'value-no-vendor-prefix': true, // 禁止给值添加浏览器引擎前缀
        'selector-no-vendor-prefix': true, // 禁止使用浏览器引擎前缀
        'no-descending-specificity': null, // 禁止低优先级的选择器出现在高优先级的选择器之后
        'at-rule-no-unknown': [
            true,
            {
                ignoreAtRules: ['layer', 'apply', 'screen', 'define-mixin', 'mixin'],
            },
        ],

        'property-no-unknown': [
            true,
            {
                ignoreProperties: [
                    // CSS Modules composition
                    // https://github.com/css-modules/css-modules#composition
                    'composes',
                ],
            },
        ],

        'selector-pseudo-class-no-unknown': [
            true,
            {
                ignorePseudoClasses: [
                    // CSS Modules :global scope
                    // https://github.com/css-modules/css-modules#exceptions
                    'global',
                    'local',
                ],
            },
        ],
        'rule-empty-line-before': [
            // 要求或禁止在规则声明之前有空行
            'always-multi-line',
            {
                except: ['first-nested'],
                ignore: ['after-comment'],
            },
        ],
        'at-rule-empty-line-before': [
            // 要求或禁止在 at 规则之前有空行
            'always',
            {
                except: ['blockless-after-same-name-blockless', 'first-nested'],
                ignore: ['after-comment'],
            },
        ],
        'comment-empty-line-before': [
            // 要求或禁止在注释之前有空行
            'always',
            {
                except: ['first-nested'],
                ignore: ['stylelint-commands'],
            },
        ],
    },
};
```

在根目录新增一个`.stylelintignore`，把以下添加进去，这可以让stylelint忽略的一些不要格式化的文件，内容如下

```json
dist
back
public
node_modules
pnpm-lock.yaml
docker
Dockerfile*
LICENSE
yarn-error.log
.history
.vscode
.docusaurus
.dockerignore
.DS_Store
.eslintignore
.editorconfig
.gitignore
.prettierignore
.eslintcache
*.lock
*.js
*.tsx
*.ts
*.json
*.png
*.eot
*.ttf
*.woff
```

在`package.json`中添加stylelint的格式化命令，并设置一个`lint`命令用于同时格式化eslint和stylelint

```json
"scripts": {
     "lint": "pnpm lint:es && pnpm lint:style",
     "lint:es": "eslint . --ext ts,tsx --fix --report-unused-disable-directives --max-warnings 0",
     "lint:style": "stylelint \"**/*.css\" --fix --cache --cache-location node_modules/.cache/stylelint/",
    ...
},
```

运行`pnpm lint:style`或者`pnpm lint`即可格式化

### VSCode

为了在vscode中保存即自动格式化，我们做如下设置

:::info

请自行安装，eslint,prettier,stylint以及postcss插件

:::

使用以下配置可自动对不满足elsint，stylint以及prettier预设规则的部分代码进行自动修复

- `editor.formatOnSave`关闭vscode的默认的自动代码格式化，`editor.codeActionsOnSave`把`ts/js`与`stylint`自动代码格式化分别托管给`eslint`和`stylint`以及通过它们调用`prettier`进行修复
- `xxx..validate: false`用于禁用`less`等所有样式语言的语法验证，把它们全部托管给`postcss`
- 使用`emmet.includeLanguages`把`postcss`的识别改为`css`，这样我们就可以在写`postcss`时获取`css`的提示了
- 把`less`,`scss`,`css`,`postcss`的所有样式语言的语法语法识别和验证托管给`stylelint`
- 其余的配置相信你自己能看懂，我就不赘述了

```typescript
// .vscode/settings.json
{
    "editor.formatOnSave": false,
    "editor.codeActionsOnSave": {
        "source.fixAll.eslint": true,
        "source.fixAll.stylelint": true
    },
    "css.validate": false,
    "less.validate": false,
    "scss.validate": false,
    "postcss.validate": false,
    "emmet.includeLanguages": {
        "postcss": "css"
    },
    "stylelint.snippet": ["css", "scss", "less", "postcss"],
    "stylelint.validate": ["css", "scss", "less", "postcss"],
    "javascript.preferences.importModuleSpecifier": "project-relative",
    "typescript.suggest.jsdoc.generateReturns": false,
    "stylelint.packageManager": "pnpm",
    "npm.packageManager": "pnpm"
}
```

### Vite

为了后续方便地编写其它vite配置，我们先建立一个专门用于vite构建配置的目录:`scripts`，然后在里面写vite配置

运行`pnpm add @types/node -D`命令添加node类型依赖

我们需要配置一下`tsconfig.node.json`，在`include`中添加`scripts`，以便ts能解析到`scripts`目录中的文件

```json
// tsconfig.node.json
{
    ...
    "include": ["vite.config.ts", "./scripts"]
}
```

**请注意，在配置好后按`cmd + shift + p`重启typescript服务器或者关闭vscode再重新打开(推荐)**

添加一下`deepmerge`这个库用于深度合并对象

```bash
pnpm add deepmerge
```

编写一个用于获取某个目录的绝对路径的函数

```typescript
// scripts/utils.ts
import { resolve } from 'path';

export const pathResolve = (dir: string) => resolve(__dirname, '../', dir);
```

编写一个vite自定义配置生成函数的类型，`isBuild`为是否处于构建环境中（即生产环境）

```typescript
// scripts/types.ts
import { ConfigEnv, UserConfig } from 'vite';

export type Configure = (params: ConfigEnv, isBuild: boolean) => UserConfig;
```

编写一个插件创建函数，用于放置所有的vite插件

```typescript
// scripts/plugins.ts
import { PluginOption } from 'vite';
import react from '@vitejs/plugin-react';

export function createPlugins(isBuild: boolean) {
    const vitePlugins: (PluginOption | PluginOption[])[] = [react()];
    return vitePlugins;
}
```

编写配置构建函数

- 该函数接收两个参数，`params`参数用于接收vite默认的环境参数
- `configure`参数用于接收一个自定义的配置生成函数，是可选的

其逻辑为先设置定一些预定义的配置，比如**路径别名**，然后如果有自定义的配置生成函数传入，则生成自定义的配置，然后没有，把自定义配置设置成控对象，最后合并并覆盖预定义配置，然后返回最终的配置
在此处我们添加了以下配置

- 路径别名，作用是可以使用`@/`为前缀来便捷的导入模块，所以需要分别配置vite和typescript
- 使用`camelCaseOnly`(即驼峰命名法：如`containerMain`)来定义CSS MODULES的类名
- 加载默认的`react`插件

```typescript
// scripts/index.ts
import { ConfigEnv, UserConfig } from 'vite';
import merge from 'deepmerge';

import { Configure } from './types';
import { pathResolve } from './utils';
import { createPlugins } from './plugins';

export const createConfig = (params: ConfigEnv, configure?: Configure): UserConfig => {
    const isBuild = params.command === 'build';
    return merge<UserConfig>(
        {
            resolve: {
                alias: {
                    '@': pathResolve('src'),
                },
            },
            css: {
                modules: {
                    localsConvention: 'camelCaseOnly',
                },
            },
            plugins: createPlugins(isBuild),
        },
        typeof configure === 'function' ? configure(params, isBuild) : {},
        {
            arrayMerge: (_d, s, _o) => Array.from(new Set([..._d, ...s])),
        },
    );
};
```

最后在`vite.config.ts`中构建配置

```typescript
// vite.config.ts
import { ConfigEnv, UserConfig, defineConfig } from 'vite';

import { createConfig } from './scripts';

export default defineConfig((params: ConfigEnv): UserConfig => {
    const config = createConfig(params);
    return config;
});
```

最后我们为`tsconfig.json`添加上别名，根路径以及编译路径的配置

```json
// tsconfig.json
{
    "compilerOptions": {
        ...
        "outDir": "./dist",
        "baseUrl": "./",
        "paths": {
            "@/*": ["src/*"]
        }
    },
    "include": ["src"],
    "references": [{ "path": "./tsconfig.node.json" }]
}
```

## 样式与组件库
### 支持Tailwind
首先安装一下`tailwindCSS`的VSCode插件
安装依赖

```bash
pnpm add tailwindcss postcss autoprefixer postcss-import postcss-mixins postcss-nested postcss-nesting -D
```

生成配置

```bash
pnpx tailwindcss init -p
```

可以看到生成了两个配置文件，分别为`postcss.config.js`与`tailwind.config.js`
首先我们修改一下`postcss.config.js`，增加一些插件，它们的作用如下

- `postcss-import`: 可以让一个css文件导入其它css文件
- `postcss-nesting`: 可以编写`postcss-nesting`规范的嵌套css
- `tailwindcss/nesting`: 可以编写`scss`规范的嵌套css
- `autoprefixer`: 自动为css样式添加浏览器适配前缀
- `postcss-mixins`: 编写css样板代码，使一段css代码供多个地方使用

```javascript
// postcss.config.js
module.exports = {
    plugins: {
        'postcss-import': {},
        'postcss-nesting': {},
        'tailwindcss/nesting': {},
        tailwindcss: {},
        autoprefixer: {},
        'postcss-mixins': {},
    },
};
```

接下来修改一下`tailwind.config.js`

- 手动切换暗黑模式
- 在`index.html`以及通过`glob`匹配的`./src/**/*.{js,ts,jsx,tsx}`这些文件中,tailwind才会生效
- 并通过`theme.screens`自定义一下响应式屏幕界点(为了通用性，我们与[bootstrap](https://getbootstrap.com/)一致)

```javascript
// tailwind.config.js
/** @type {import('tailwindcss').Config} */
module.exports = {
   // prefix: 'tw-',
    darkMode: 'class',
    content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
    theme: {
        screens: {
            xs: '480px',
            sm: '576px',
            md: '768px',
            lg: '992px',
            xl: '1200px',
            '2xl': '1400px',
        },
        extend: {},
    },
    plugins: [],
};
```

接下来我们创建一下css文件
先创建一个用于定义css变量的文件`vars.css`，我们在里面定义一下标准的字体大小，以及标准的字体和一些特殊字体

```css
/* src/styles/vars.css */
:root {
    --font-size-base: 0.875rem;
    --font-family-standard: 'Source Sans Pro', 'Hiragino Sans GB', 'Microsoft Yahei', simsun,
        helvetica, arial, sans-serif, monospace;
    --font-family-firacode: 'Fira Code', 'Source Sans Pro', 'Hiragino Sans GB', 'Microsoft Yahei',
        simsun, helvetica, arial, sans-serif, monospace;
}
```

在`tailwind.config.js`定义这些字体，后面就可以用`字体名`来局部更改字体了

```javascript
// tailwind.config.js
module.exports = {
   ...
        extend: {
            fontFamily: {
                standard: 'var(--font-family-standard)',
                firacode: 'var(--font-family-firacode)',
            },
        },
    },
    plugins: [],
};
```

然后创建一个`styles/tailwind`目录，用于放置tailwind的自定义扩展样式
三个文件`base.css`,`components.css`,`utilities.css`分别用于

- 添加自定义tailwind基础层样式,一般用于覆盖一些tailwind中默认的基础样式
- 添加自定义tailwind组件层样式,一般无特殊需求可以用react组件抽象而不是在这里定义css类
- 添加自定义tailwindg工具层样式,可以在这里添加一些tailwind中不存在的一些样式类

需要注意的是这些文件中

- 如果要引用tailwind自带的值或`tailwind.config.js`的theme中配置的值,可以通过 `@apply`指令或`theme`函数获取
- 在`@layer`中添加的样式如果在程序中没有用到会在编译后被清除,如果需要强制存在于编译后的样式表,请在`@layer`外定义

它们的内容如下

```css
/* src/styles/tailwind/base.css */
@layer base {
    html {
        font-family: var(--font-family-base);
        font-size: var(--font-size-base);
    }
}
/* src/styles/tailwind/components.css */
@layer components {
}
/* src/styles/tailwind/utilities.css */
@layer utilities {
}
```

新建一个`app.css`文件用于放置全局样式，并在这个文件里我们测试一下tailwind的引用

```css
/* src/styles/app.css */
html,
body,
#root,
.ant-app {
    @apply h-[100vh] w-full flex p-0 m-0;
}
```

然后创建一个入口样式文件`index.css`来引用这些样式文件

:::caution

注意引用顺序

:::

```css
/* src/styles/index.css */
@import 'tailwindcss/base';
@import './tailwind/base.css';
@import 'tailwindcss/components';
@import './tailwind/components.css';
@import 'tailwindcss/utilities';
@import './tailwind/utilities.css';
@import './app.css';
```

现在我们不需要`src`目录下的`index.css`以及`App.css`了，直接删除掉，然后在`main.tsx`中导入`@/styles/index.css`

```tsx
// src/main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';

import '@/styles/index.css';

import App from './App.tsx';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
    <React.StrictMode>
        <App />
    </React.StrictMode>,
);
```

然后更改一下`App.tsx`的代码

```tsx
// src/App.tsx
const App = () => {
    return (
        <div className="w-full bg-yellow-300 flex items-center justify-center">
            <div className="shadow-md p-5 bg-black text-center text-white text-lg">
                欢迎来到3R教室，这是<span>React课程第一节</span>
            </div>
        </div>
    );
};

export default App;
```

启动一下应用查看样式是否生效
### 使用CSS MODULES

为了组件名称统一使用小写，我们把`App.tsx`改成`app.tsx`，在`main.tsx`里更改一下导入的名称

创建一个`app.moudule.css`，把`app.tsx`的样式放进去

```css
/* src/app.module.css */
.app {
    @apply bg-yellow-300 flex flex-auto items-center justify-center;

    & > .container {
        @apply shadow-md p-5 bg-black text-center text-white text-lg;
    }
}
```

修改`app.tsx`

```tsx
// src/app.tsx
import $styles from './app.module.css';

const App = () => {
    return (
        <div className={$styles.app}>
            <div className={$styles.container}>
                欢迎来到3R教室，这是<span>React课程第一节</span>
            </div>
        </div>
    );
};

export default App;
```

因为css样式抽象到模块了，控制台会出现“No utility classes were detected in your source files. If this is unexpected, double-check the `content` option in your Tailwind CSS configuration”的警告，不用去理它，后面在`tsx`文件中某些地方直接使用tw的样式则自然会消失！
### 整合Antd
安装依赖

:::info

因为antd的时间组件依赖于dayjs，所以需要安装dayjs

:::

:::caution

请注意: 添加依赖后请重启vscode

:::


```bash
pnpm add antd @ant-design/cssinjs dayjs
```

为了防止tailwind与antd产生样式冲突，需要修改一下tailwind的配置

```javascript
// tailwind.config.js
...
    corePlugins: {
        preflight: false,
    },
    plugins: [],
};
```

包装应用的时候需要使用`StyleProvider`取消Antd的降权（同样是为了防止tailwind与antd产生样式冲突），并且在`ConfigProvider`中把背景取消，然后换个紧凑皮肤`theme.defaultAlgorithm`，代码变成这样

```tsx
// src/app.tsx

import { Button, ConfigProvider, theme, App as AntdApp } from 'antd';
import { StyleProvider } from '@ant-design/cssinjs';
import 'dayjs/locale/zh-cn';
import zhCN from 'antd/locale/zh_CN';

import { FC } from 'react';

import $styles from './app.module.css';

const App: FC = () => {
    return (
        <ConfigProvider
            locale={zhCN}
            theme={{
                algorithm: theme.defaultAlgorithm,
                token: {
                    colorPrimary: '#00B96B',
                },
                components: {
                    Layout: {
                        colorBgBody: '',
                    },
                },
            }}
        >
            <StyleProvider hashPriority="high">
                <AntdApp>
                    <div className={$styles.app}>
                        <div className={$styles.container}>
                            欢迎来到3R教室，这是<span>React课程第一节</span>
                            <Button
                                type="primary"
                                className="!bg-lime-400 !text-emerald-900"
                                href="https://pincman.com/3r"
                                target="_blank"
                            >
                                点此打开
                            </Button>
                        </div>
                    </div>
                </AntdApp>
            </StyleProvider>
        </ConfigProvider>
    );
};
export default App;
```

启动应用看一下是否正常，本节搞定！
![](https://img.pincman.com/media/202304040913399.png#id=Hu5Ej&originHeight=1870&originWidth=2934&originalType=binary&ratio=1&rotation=0&showTitle=false&status=done&style=none&title=)
