---
title: 使用Gitea+Drone自建CICD平台
sidebar_label: 使用Gitea+Drone自建CICD平台
hide_title: true
sidebar_position: 3
---

# 使用Gitea+Drone自建CICD平台

## Gitea

### 启动二进制

gitea有多种方式安装，比如docker或者apt-get等，我们使用最常见的二进制文件来安装

```bash
su -
adduser \
   --system \
   --shell /bin/zsh \
   --gecos 'Git Version Control' \
   --group \
   --home /home/git \
   git
passwd git
wget -O /home/git/gitea/bin/gitea https://dl.gitea.com/gitea/1.20.1/gitea-1.20.1-linux-amd64 
chmod +x /home/git/gitea/bin/gitea
mkdir -p /home/git/gitea/{bin,var,config,data,log}
chown -R git:git /home/git/gitea
su - git
sh -c "$(wget -O- https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
# 如果是国内服务器，可以使用镜像代替：sh -c "$(wget -O- https://gitee.com/mirrors3r/ohmyzsh/raw/master/tools/install.sh)"
chmod -R 750 /home/git/gitea
chmod 770 ~/gitea/config
```

临时启动测试

```bash
GITEA_WORK_DIR=/home/git/gitea/var/ /home/git/gitea/bin/gitea web -c /home/git/gitea/config/app.ini
```

如果有硬件防火墙，请添加`3000`端口通过，如下

![](https://img.pincman.com/media/202308060008873.png)

启动后访问`{服务器IP}:3000`

:::caution

注意：此时不要安装，看到可以正常启动即可

:::

![](https://img.pincman.com/media/202308060010510.png)

### 系统服务

现在我们可以按 **ctrl+c** 退出刚才启动的gitea，因为我们要把gitea设置为系统服务，这样就可以开机启动

设置Gitea为系统服务

```bash
su -
vim /etc/systemd/system/gitea.service
```

把以下内容放进去

```nginx
[Unit]
Description=Gitea (Git with a cup of tea)
After=syslog.target
After=network.target

[Service]
RestartSec=2s
Type=simple
User=git
Group=git
WorkingDirectory=/home/git/gitea/var/
ExecStart=/home/git/gitea/bin/gitea web --config /home/git/gitea/config/app.ini
Restart=always
Environment=USER=git HOME=/home/git GITEA_WORK_DIR=/home/git/gitea/var
[Install]
WantedBy=multi-user.target
```

运行以下命令

```bash
systemctl enable gitea 
systemctl start gitea # 或者 service gitea start 
```

如果看到还是能像上面一样，可以正常打开`{服务器IP}:3000`，证明系统服务工作正常，**同样，不要安装，我们绑定好域名后安装！**

### Nginx反代

首先我们添加一个子域名，比如`git.pincman.com`映射到我们的gitea服务器

![](https://img.pincman.com/media/202308060017625.png)

然后添加一个虚拟主机

![](https://img.pincman.com/media/202308060023982.png)

![](https://img.pincman.com/media/202308060022144.png)

修改虚拟主机为反向代理`3000`端口

```bash
vim /usr/local/nginx/conf/vhost/git.pincman.com.conf
```

输入`:set number`已显示行数，使用`:26,50d`这个命令删除26到50行

:::caution

oneinstack的nginx会变化，行数可能有所变动，自己看下图箭头指向删除这个范围内的配置

:::

![](https://img.pincman.com/media/202308060025466.png)

然后加入`3000`端口的代理

```nginx
location / {
      proxy_pass http://127.0.0.1:3000;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection 'upgrade';
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-Proto $scheme;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_cache_bypass $http_upgrade;
  }
```

如图

![](https://img.pincman.com/media/202308060028526.png)

`wq`报错，并`service nignx restart`重启nginx

如果前面有开启硬件防火墙的端口，现在可以删除

![](https://img.pincman.com/media/202308060030273.png)

### 安装与配置

首先，创建一个数据

浏览器打开`http://{服务器IP}/phpMyAdmin`，创建一个供Gitea使用的数据库

![](https://img.pincman.com/media/202308060040035.png)

然后浏览器打开[git.pincman.com](https://git.pincman.com)来进行安装，下图的信息按自己需要配置即可

![](https://img.pincman.com/media/202308060140476.png)

安装完后取消配置文件写入权限

```bash
su - git
chmod 750 ~/gitea
chmod 640 ~/gitea/config/app.ini
```

你还可以根据[这里](https://docs.gitea.com/zh-cn/administration/customizing-gitea)的说明来自定义很多东西，比如Logo等

## Drone

一般来说，建议drone和gitea不要装在同一台服务器，这样可能会出问题

:::note

如果为了节省成本，那么一台也行，我个人以前用一台服务器架设两者，也没发现什么问题

:::

我们这里使用一台新服务器来运行drone

### 安装docker

drone只能使用docker安装，所以我们必须先安装docker

登录运行drone的服务器，并运行以下命令

```bash
su -
for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do sudo apt-get remove $pkg; done
apt-get update
apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo \
  "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
docker run hello-world
apt-get install docker-compose-plugin
docker compose version
```

### 添加OAuth认证

首先绑定一下域名解析，让域名`ci.pincman.com`指向drone服务器的IP地址

![](https://img.pincman.com/media/202308070058740.png)

打开[git.pincman.com/admin/applications](https://git.pincman.com/admin/applications)，添加OAuth

**注意：在添加后把客户端ID和客户端秘钥记录下来，待会儿在安装drone的使用用来作为连接凭证**

![](https://img.pincman.com/media/202308062044403.png)

### 安装drone

生成秘钥

```bash
openssl rand -hex 16
```

drone由server和runner组成，我们创建一个`docker-compose.yml`通知配置这两个工具，然后启动docker compose即可

```bash
mkdir ~/drone && vim ~/drone/docker-compose.yml
```

![](https://img.pincman.com/media/202308062042080.png)

把以下配置放进去

- 把`https://git.pincman.com`替换成你的gitea地址
- 把`DRONE_GITEA_CLIENT_ID`和`DRONE_GITEA_CLIENT_SECRET`替换成前面**配置OAuth**时生成的客户端ID和客户端秘钥
- 把`DRONE_RPC_SECRET`替换成前面使用`openssl`生成的秘钥
- 把`DRONE_SERVER_HOST`替换成你的Drone的url地址
- 把`DRONE_USER_CREATE`中的`pincman`替换成你的Gitea的管理员用户名

:::info

推荐先把下面的代码放到vscode中替换，替换完毕在黏贴到vim中

:::

```yaml
version: "3.9"

services:
  drone:
    image: drone/drone:2
    volumes:
      - /data/drone:/data
      - /var/run/docker.sock:/var/run/docker.sock
    restart: always
    ports:
      - 8000:80
    networks:
      - cicd_net
    environment:
      - DRONE_GITEA_SERVER={Gitea的URL地址}
      - DRONE_GITEA_CLIENT_ID={客户端ID}
      - DRONE_GITEA_CLIENT_SECRET={客户端秘钥}
      - DRONE_RPC_SECRET={openssl生成的秘钥}
      - DRONE_SERVER_HOST={Drone的url地址}
      - DRONE_SERVER_PROTO=https
      - DRONE_TLS_AUTOCERT=false
      - DRONE_USER_CREATE=username:{Gitea的管理员用户名},admin:true
  drone-runner:
    image: drone/drone-runner-docker:1
    restart: always
    depends_on:
      - drone
    ports:
      - 3333:3000
    networks:
      - cicd_net
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      - DRONE_RPC_PROTO=http
      - DRONE_RPC_HOST=drone
      - DRONE_RPC_SECRET={openssl生成的秘钥}
      - DRONE_LIMIT_TRUSTED=false
      - RONE_RUNNER_CAPACITY=2
      - DRONE_RUNNER_NETWORKS=cicd_net
      - DRONE_RUNNER_NAME=drone-cli
networks:
  cicd_net:
    name: cicd_net
```

报错后使用以下命令启动drone

```bash
cd ~/drone && docker compose up -d
```

### Nginx主机

与**Gitea的反代**一样，先创建一个主机，并绑定`ci.pincman.com`域名

```nginx
location / {
      proxy_pass http://127.0.0.1:8000;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection 'upgrade';
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-Proto $scheme;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_cache_bypass $http_upgrade;
  }
```



![](https://img.pincman.com/media/202308062203465.png)

然后进行反代

```bash
vim /usr/local/nginx/conf/vhost/ci.pincman.com.conf
```

![](https://img.pincman.com/media/202308062211789.png)

重启nginx

```bash
service nginx restart
```

然后打开[ci.pincman.com](https://ci.pincman.com)，点`continue`按钮，再点`应用授权`，然后填写一下注册信息即可

![](https://img.pincman.com/media/202308062215807.png)

## CICD

我们先用前面课程的monorepo的demo编写一下构建配置，测试一下CICD是否通畅

### 创建项目仓库

打开[git.pincman.com](https://git.pincman.com),创建一个组织和项目

![](https://img.pincman.com/media/202308062230045.png)

### 同步仓库

打开`ci.pincman.com`，同步一下仓库

![](https://img.pincman.com/media/202308062231378.png)

### 激活仓库

点一下我们需要进行CICD处理的仓库，比如`tsclass/3rcu`,点`ACTIVATE REPOSITORY`

![](https://img.pincman.com/media/202308062233262.png)

然后做如下设置，并点击保存

![](https://img.pincman.com/media/202308070158057.png)

### 添加仓库

首先把我们的秘钥添加到git中

:::caution

注意：这个秘钥使我们本地的秘钥，如果你是在远程开发，则该秘钥是你开发服务器的用户秘钥

:::

```bash
cat ~/.ssh/id_rsa.pub
```

点击用户头像 > 设置 > SSH/GPG密钥，添加我们的秘钥并保存

![](https://img.pincman.com/media/202308062348695.png)

打开本地应用目录，并提交到我们创建的git仓库

```bash
git init
rm -rf apps/web/.git && rm -rf apps/api/.git
git add .
git commit -m 'init'
git remote add origin git@git.pincman.com:tsclass/3rcu.git
git push -f origin main
```

### Drone登录服务器

我们先要确保，drone能自动生产登录服务器，这样才可以进行接下来的一系列操作

我们把本地电脑的ssh密钥的内容复制一下

:::caution

注意是不带`.pub`得那个文件

:::

```bash
cat ~/.ssh/id_rsa
```

把输出内容复制后，需要在drone的这个仓库里加上一个`secret`，我们自定义一个名称，比如`ssh_key`

:::caution

请确保，这个`ssh_key`对应的公钥，即`id_rsa.pub`的内容已经添加到生产(部署)服务器的` ~/.ssh/authorized_keys`中，如果没有请添加

:::

![](https://img.pincman.com/media/202308070341873.png)

### 环境变量

你也可以再添加一些其它的环境变量，比如nestjs的数据库配置，nextjs和vite在生产环境下对应的api地址等等，也可以放到`secrets`里面，可以为这些变量起一个名称，像是`env_vars`

像这样

![](https://img.pincman.com/media/202308070346825.png)

### 安装PM2

我们使用pm2来启动应用，所以在生产环境下安装一下pm2

```bash
pnpm i pm2@latest -g
```

你还可以使用监控面板

首先去`pm2.io`注册一个账户，然后在服务器运行以下命令

```bash
pm2 plus
```

![](https://img.pincman.com/media/202308070357974.png)

为了服务器能开机启动所有pm2进程，请运行以下命令

```bash
sudo env PATH=$PATH:/home/pincman/.local/share/pnpm/nodejs/18.17.0/bin pm2 startup systemd -u pincman --hp /home/pincman
```

### 编写pm2配置

在应用根目录下增加一个pm2的配置文件`ecosystem.config.js`

- `cwd`代表执行这个命令的工作目录
- `watch`代表文件改变后重启
- `exec_mode`默认是`fork`，但是我们可以使用`cluster`，关于`cluster`和进程的概念我们在后面课程再细节

因为admin是spa面板，所以不需要node启动，我们就不必加载`ecosystem.config.js`里面了

```javascript
module.exports = {
    apps: [
        {
            name: "3rcu-web",
            cwd: './apps/web',
            script: "./node_modules/next/dist/bin/next",
            args: "start -p 8101",
            watch: true,
            autorestart: true,
            ignore_watch: ["node_modules"],
            env: {
                NODE_ENV: "production",
            },
        },
        {
            name: '3rcu-api',
            cwd: './apps/api/dist',
            script: 'main.js -p 3100',
            autorestart: true,
            watch: true,
            ignore_watch: ['node_modules'],
            env: {
                NODE_ENV: 'production',
            },
            exec_mode: 'fork',
        },
    ],
};
```

### 服务器登录Gitea

为了简单起见，我们不使用docker以及编译后部署这种方式，使用像php的cicd一样简单的方式，即直接在生产服务器上克隆源码，自动编译并运行。

我们需要生成一下生产服务器的部署用户(如`pincman`)的公钥，放到我们的应用仓库里，这样才能让服务器跟本地一样克隆应用并部署

在服务器的部署用户下运行以下命令

```bash
ssh-keygen -t rsa -C "pincman1988@gmail.com" # 不停按回车直到生成
cat ~/.ssh/id_rsa.pub # 复制内容
```

复制完公钥的内容后把它黏贴到仓库的部署密钥里

![](https://img.pincman.com/media/202308070418548.png)

### 编写配置

在根目录下添加一个`.drone.yml`文件，用于编写配置

```yaml
kind: pipeline
type: docker
name: default
steps:
    - name: deploy
      image: appleboy/drone-ssh
      environment:
          ENV_VARS:
              from_secret: env_vars
      settings:
          host: 服务器IP
          username: pincman
          key:
              from_secret: ssh_key
          port: 22
          command_timeout: 2m
          envs: [ENV_VARS]
          script:
              - cd /home/pincman/htdocs
              - '[ -d ./3rcu ] && rm -rf ./3rcu'
              # 这一行很重要，因为没有的话，第一次克隆就会失败
              - GIT_SSH_COMMAND="ssh -o StrictHostKeyChecking=no" git clone -q git@git.pincman.com:tsclass/3rcu.git ./3rcu
              - cd 3rcu
              - echo "$${ENV_VARS}" > .env
              - 'source ~/.zshrc; pnpm i && pnpm build && pm2 restart ecosystem.config.js && pm2 save'

```

### 修改代码

为了配合上线后的`api`后缀，在`apps/api/src/main.ts`中添加一句`setGlobalPrefix`设置全局前缀

```typescript
import { NestFactory } from '@nestjs/core';

import { AppModule } from './app.module';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.setGlobalPrefix('api')
    await app.listen(3100);
}
bootstrap();
```

为了让vite后台可以用`admin`后缀，改一下它的`build`命令

```json
// apps/admin/package.json
 "scripts": {
        "dev": "vite",
        "build": "tsc && vite build --base=/admin/",
        ...
    },
```



然后提交代码

```bash
git add . && git commit -m 'update drone config' && git push origin main
```

提交后就会自动部署，如图

![](https://img.pincman.com/media/202308070448986.png)

### Nginx绑定

我们新增一个子域名用来部署我们的网站，比如`3rcu.pincman.com`，在dnspod中把它解析到我们的服务器IP

然后添加一个虚拟机主机

![](https://img.pincman.com/media/202308070453567.png)

编辑主机配置文件

```bash
vim /usr/local/nginx/conf/vhost/3rcu.pincman.com.conf
```

内容如下

```nginx
 location / {
    proxy_pass http://127.0.0.1:8101;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_cache_bypass $http_upgrade;
  }
  location /admin {
    alias /home/pincman/htdocs/3rcu/apps/admin/dist;
    index index.php index.html index.htm;
    try_files $uri $uri/ /admin/index.html;
  }
  location /api {
    proxy_pass http://127.0.0.1:3100;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_cache_bypass $http_upgrade;
  }
```

![](https://img.pincman.com/media/202308070510064.png)

**最后，别忘了重启nginx**

现在我们分别打开[3rcu.pincman.com](https://3rcu.pincman.com),[3rcu.pincman.com/admin](https://3rcu.pincman.com/admin),[3rcu.pincman.com/api](https://3rcu.pincman.com/api)

可以看到和本地开发一样的界面

![](https://img.pincman.com/media/202308070519948.png)

![](https://img.pincman.com/media/202308070519429.png)

![](https://img.pincman.com/media/202308070519132.png)

至此，大功告成！

### 结束语

这节课的`.drone.yml`并没有涉及到在容器内容构建，通过docker部署，服务器数据库迁移等知识，如果有兴趣可自行发散思维尝试，另外也可以参考我们的商业项目中的配置，看看是怎么写的！

不用担心，这个课程做完后，我们还会讲一次部署和优化，届时将有数据库迁移，容器内CI等所有知识！

## 课后任务

下载[goflashdeals](https://git.3rcd.com/goflash)，或者[youni](https://git.3rcd.com/youni)，自己完成一次CICD