---
title: 使用Turborepo构建mono应用
sidebar_label: Turborepo+Nestjs+React18+Nextjs13构建monorepo脚手架
hide_title: true
sidebar_position: 1
---

# Turborepo+Nestjs+React18+Nextjs13构建monorepo脚手架

:::danger
注意本节课为课程最终代码的monorepo版本，正在更新迭代中，短期内请不要用于生产环境。目前只做学习参考使用，如果实在想尝试生产环境上使用，请务必在这个仓库上进行一些细节优化处理！
:::

:::caution
本节涉及到非常多的格式化配置,但是对开发应用实际助力不大,所以如果嫌麻烦.
请直接下载[classroom/monoapp](https://git.3rcd.com/classroom/monoapp)模板对着文档学习即可,**不建议手动去配置**
:::

:::info
本节课不是必须学习的，只作为提升技能所用。由于turborepo目前问题还是比较多，后续可能换成比较传统的lerna或者等turborepo成熟后再作为正式课程发布。
所以目前关于本节课程的一切问题在暂不提供解答，请随时关注本节课程的更新！
:::

## 课程节目标

使用turborepo+pnpm实现一个react+nextjs+nestjs的基础monorepo，以前后端可以同构。

后续的课程我们还将学习

- 如何发布扩展包
- 如何在ci中自动部署不同的应用
- 更加细致化的monorepo项目管理等

## Monorepo的好处

- 代码同构，比如前后端能使用同一个函数或者接口
- 方便管理，因为在一个仓库里了
- 发包方便并且可以降低代码耦合度，很多模块或组件直接可以拆分单独发包，方便循环使用，因为主应用是`private: true`的
- 启动或者编译方便，效率高，因为不需要开几个窗口启动不同应用，并且编译和开发启动时，可以并行
- turorepo独有的缓存可以提高重复执行一个相同任务的速度

## 初始化turborepo

创建一个turborepo项目

```shell
pnpm dlx create-turbo@latest
```

输入项目名称并选择`pnpm`，如下图

![image-20230724133710295](https://img.pincman.com/media/202307241337635.png)

用vscode打开目录后你会发现这样一个结构

![image-20230724133956737](https://img.pincman.com/media/202307241339684.png)

解释一下他们的作用

```shell
.
├── README.md
├── apps                          # 放应用包的目录
│   ├── docs                      # 一个nextjs 应用
│   │   ├── README.md
│   │   ├── app
│   │   ├── next-env.d.ts
│   │   ├── next.config.js
│   │   ├── node_modules
│   │   ├── package.json
│   │   └── tsconfig.json
│   └── web                         # 另一个nextjs 应用
│       ├── README.md
│       ├── app
│       ├── next-env.d.ts
│       ├── next.config.js
│       ├── node_modules
│       ├── package.json
│       └── tsconfig.json
├── package.json                    # 全局的依赖
├── packages                        # 放类库包的目录
│   ├── eslint-config-custom        # eslint配置
│   │   ├── index.js
│   │   ├── node_modules
│   │   └── package.json
│   ├── tsconfig                    # tsconfig配置
│   │   ├── base.json
│   │   ├── nextjs.json
│   │   ├── package.json
│   │   └── react-library.json
│   └── ui                          # 一个自己编写的组件包
│       ├── Button.tsx
│       ├── Header.tsx
│       ├── index.tsx
│       ├── node_modules
│       ├── package.json
│       ├── tsconfig.json
│       └── turbo
├── pnpm-lock.yaml
├── pnpm-workspace.yaml             # pnpm的workspace配置
└── turbo.json                      # turborepo的配置
```

我们可以看到`pnpm-workspace.yaml`文件，它指定了你可以放包的目录，只要指定`apps`和`packages`用来放我们的开发包即可,如下

:::info

关于`pnpm`的`workspace`的更多内容可以查看它的[官网文档](https://pnpm.io/zh/workspaces)

:::

```yaml
packages:
  - "apps/*"
  - "packages/*"
```

可以看到`turbo.json`，这是turborepo的配置

:::info

更多详细的可以看到它的[官方文档](https://turbo.build/repo/docs/reference/configuration)

:::

- `globalDependencies`可以用来指定一些改变全局缓存更改文件，一旦这些文件改变，turbo会自动更新编译等任务的缓存
- `pipeline`用来指定任务（每个包的每个人物都可以单独指定，可以自行查看其官网文档）
- `dependsOn`的设置是，如果是加上`^`的，比如`^build`则在运行该任务前，它依赖的其他包如果有`build`命令则先运行，如果不加`^`，比如在`build`中添加`lint`，则代表在运行当前包的`build`命令时先运行自身的`lint`命令
- `outputs`用于指明该任务换成的文件
- `cache`用于禁用缓存
- `persistent`用来标记常驻内存的任务，比如`dev`

```json
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**"]
    },
    "lint": {},
    "dev": {
      "cache": false,
      "persistent": true
    }
  }
}

```

为了契合我们的应用，我们把它暂时改成如下配置

```json
{
    "$schema": "https://turbo.build/schema.json",
    "globalDependencies": [
        ".env",
        ".env.*",
        "**/.env",
        "**/.env.*",
        "**/tsconfig.json",
        "**/tsconfig.build.json"
    ],
    "globalEnv": ["NODE_ENV"],
    "pipeline": {
        "build": {
            "dependsOn": ["^build"],
            "outputs": ["dist/**"]
        },
        "lint": {},
        "dev": {
            "cache": false,
            "persistent": true
        }
    }
}
```

## 扩展包

先删除无用扩展包`packages/ui`

### Ts配置包

为了配置适合`nestjs`,`vite-react`以及`nextjs`等多个包，我们需要专门做一个`ts-config`包来编写多个配置文件

首先，把默认的`packages/tsconfig`目录删除，并在`packages`中新增一个`ts-config`包

然后，在`packages/ts-config`中添加一个`package.json`文件，内容如下

:::caution

注意：`@3rcu`是所有包的前缀

:::

```json
{
    "name": "@3rcu/ts-config",
    "version": "0.0.0",
    "license": "MIT",
    "publishConfig": {
        "access": "public"
    }
}
```

添加一个`base.json`，用来指定一些基本的tsconfig配置 

```json
{
    "$schema": "https://json.schemastore.org/tsconfig",
    "display": "Default",
    "compilerOptions": {
        "target": "esnext",
        "useDefineForClassFields": true,
        "skipLibCheck": true,
        "moduleResolution": "Node",
        "allowImportingTsExtensions": true,
        "resolveJsonModule": true,
        "isolatedModules": true,
        "noEmit": true,
        "strict": true,
        "strictNullChecks": false,
        "strictBindCallApply": false,
        "noUnusedLocals": true,
        "noUnusedParameters": true,
        "noFallthroughCasesInSwitch": true,
        "allowJs": false,
        "declaration": true,
        "esModuleInterop": true,
        "allowSyntheticDefaultImports": true,
        "forceConsistentCasingInFileNames": true,
        "removeComments": true,
        "experimentalDecorators": true,
        "alwaysStrict": true,
        "sourceMap": true,
        "incremental": true,
        "noImplicitReturns": true,
        "pretty": true,
        "noImplicitAny": true,
        "importsNotUsedAsValues": "remove"
    },
    "exclude": ["node_modules"]
}
```

分别添加`nestjs.json`,`nextjs.json`,`react.json`用于指定这三种应用的ts配置，其中`nextjs.json`由于其特殊性，所以没有继承`base.json`，其它两者均继承自`base.json`

它们的设置如下

nestjs.json

```json
{
    "$schema": "https://json.schemastore.org/tsconfig",
    "display": "Nestjs",
    "extends": "./base.json",
    "compilerOptions": {
        "allowJs": true,
        "noEmit": false,
        "allowImportingTsExtensions": false,
        "declarationMap": true,
        "emitDecoratorMetadata": true,
        "experimentalDecorators": true,
        "target": "esnext",
        "lib": ["esnext", "DOM", "ScriptHost", "WebWorker"],
        "module": "CommonJS"
    },
    "include": ["src"],
    "exclude": ["node_modules"]
}
```

react.json

```json
{
    "$schema": "https://json.schemastore.org/tsconfig",
    "display": "Vite",
    "extends": "./base.json",
    "compilerOptions": {
        "target": "ES2020",
        "declaration": false,
        "declarationMap": false,
        "lib": ["ES2020", "DOM", "DOM.Iterable"],
        "module": "esnext",
        "jsx": "react-jsx",
        "moduleResolution": "bundler"
    },
    "include": ["src"],
    "exclude": ["node_modules"]
}
```

nextjs.json

```json
{
    "$schema": "https://json.schemastore.org/tsconfig",
    "display": "Next.js",
    "compilerOptions": {
        "plugins": [{ "name": "next" }],
        "declaration": false,
        "declarationMap": false,
        "jsx": "preserve",
        "lib": ["dom", "dom.iterable", "esnext"],
        "module": "esnext",
        "target": "es5",
        "allowJs": true,
        "skipLibCheck": true,
        "strict": true,
        "forceConsistentCasingInFileNames": true,
        "noEmit": true,
        "esModuleInterop": true,
        "moduleResolution": "node",
        "resolveJsonModule": true,
        "isolatedModules": true,
        "incremental": true
    },
    "include": ["src", "next-env.d.ts"],
    "exclude": ["node_modules"]
}
```

### Eslint配置包

为了让每个应用都可以使用部分公用的ESlint配置，我们写一个eslint扩展包

在`packages`目录中删除`eslint-config-custom`目录，新建一个`eslint-config`目录，并在该目录中添加一个`package.json`

内容如下

```json
{
  "name": "@3rcu/eslint-config",
  "version": "0.0.0",
  "main": "index.js",
  "files": [
    "base.js",
    "base-ts.js",
    "react.js",
    "nextjs.js",
    "nestjs.js"
  ],
  "license": "MIT",
  "dependencies": {
    "@next/eslint-plugin-next": "^13.4.12",
    "@typescript-eslint/eslint-plugin": "^6.1.0",
    "@typescript-eslint/parser": "^6.1.0",
    "eslint": "^8.45.0",
    "eslint-config-airbnb": "^19.0.4",
    "eslint-config-airbnb-base": "^15.0.0",
    "eslint-config-airbnb-typescript": "^17.1.0",
    "eslint-config-next": "^13.4.12",
    "eslint-config-prettier": "^8.8.0",
    "eslint-config-turbo": "^1.10.9",
    "eslint-plugin-import": "^2.27.5",
    "eslint-plugin-jest": "^27.2.3",
    "eslint-plugin-jsx-a11y": "^6.7.1",
    "eslint-plugin-prettier": "^5.0.0",
    "eslint-plugin-react": "7.33.0",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.4.3",
    "eslint-plugin-unused-imports": "^3.0.0",
    "prettier": "^3.0.0"
  },
  "publishConfig": {
    "access": "public"
  }
}
```

其中`files`字段用于指定外部能访问到的文件，`main`字段指定默认文件

下面，我们创建一个`base.js`文件，用于指定一些基本的规则，这部分从前面章节的代码搬过来，所以就不多做解释了

> 注意，扩展中，我们添加了用于turborepo的`turbo`规则

```javascript
module.exports = {
    parserOptions: {
        // 指定ESLint可以解析JSX语法
        ecmaVersion: 'latest',
        sourceType: 'module',
    },
    plugins: ['prettier', 'import', 'unused-imports'],
    extends: [
        'turbo',
        // 使用prettier格式化代码
        // https://github.com/prettier/eslint-config-prettier#readme
        'prettier',
        // 整合typescript-eslint与prettier
        // https://github.com/prettier/eslint-plugin-prettier
        'plugin:prettier/recommended',
    ],
    rules: {
        /* ********************************** ES6+ ********************************** */
        'no-console': 0,
        'no-var-requires': 0,
        'no-restricted-syntax': 0,
        'no-continue': 0,
        'no-await-in-loop': 0,
        'no-return-await': 0,
        'no-unused-vars': 0,
        'no-multi-assign': 0,
        'no-param-reassign': [2, { props: false }],
        'import/prefer-default-export': 0,
        'import/no-cycle': 0,
        'import/no-dynamic-require': 0,
        'max-classes-per-file': 0,
        'class-methods-use-this': 0,
        'guard-for-in': 0,
        'no-underscore-dangle': 0,
        'no-plusplus': 0,
        'no-lonely-if': 0,
        'no-bitwise': ['error', { allow: ['~'] }],

        /* ********************************** Module Import ********************************** */

        'import/no-absolute-path': 0,
        'import/extensions': 0,
        'import/no-named-default': 0,
        'no-restricted-exports': 0,

        // 一部分文件在导入devDependencies的依赖时不报错
        'import/no-extraneous-dependencies': 0,
        // 模块导入顺序规则
        'import/order': [
            1,
            {
                pathGroups: [
                    {
                        pattern: '@/**',
                        group: 'external',
                        position: 'after',
                    },
                ],
                alphabetize: { order: 'asc', caseInsensitive: false },
                'newlines-between': 'always-and-inside-groups',
                warnOnUnassignedImports: true,
            },
        ],
        // 自动删除未使用的导入
        // https://github.com/sweepline/eslint-plugin-unused-imports
        'unused-imports/no-unused-imports': 1,
        'unused-imports/no-unused-vars': [
            'error',
            {
                vars: 'all',
                args: 'none',
                ignoreRestSiblings: true,
            },
        ],
    },
};
```

添加一个`base-ts.js`文件，该文件指定的规则继承自`base.js`

```javascript
module.exports = {
    parser: '@typescript-eslint/parser',
    plugins: ['@typescript-eslint'],
    extends: [
        // typescript的eslint插件
        // https://github.com/typescript-eslint/typescript-eslint/blob/master/docs/getting-started/linting/README.md
        // https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/eslint-plugin
        'plugin:@typescript-eslint/recommended',
        'plugin:@typescript-eslint/recommended-requiring-type-checking',
        './base',
    ],
    rules: {
        /* ********************************** Typescript ********************************** */
        '@typescript-eslint/no-unused-vars': 0,
        '@typescript-eslint/no-empty-interface': 0,
        '@typescript-eslint/no-this-alias': 0,
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/no-use-before-define': 0,
        '@typescript-eslint/explicit-member-accessibility': 0,
        '@typescript-eslint/no-non-null-assertion': 0,
        '@typescript-eslint/no-unnecessary-type-assertion': 0,
        '@typescript-eslint/require-await': 0,
        '@typescript-eslint/no-for-in-array': 0,
        '@typescript-eslint/interface-name-prefix': 0,
        '@typescript-eslint/explicit-function-return-type': 0,
        '@typescript-eslint/no-explicit-any': 0,
        '@typescript-eslint/explicit-module-boundary-types': 0,
        '@typescript-eslint/no-floating-promises': 0,
        '@typescript-eslint/restrict-template-expressions': 0,
        '@typescript-eslint/no-unsafe-assignment': 0,
        '@typescript-eslint/no-unsafe-return': 0,
        '@typescript-eslint/no-unused-expressions': 0,
        '@typescript-eslint/no-misused-promises': 0,
        '@typescript-eslint/no-unsafe-member-access': 0,
        '@typescript-eslint/no-unsafe-call': 0,
        '@typescript-eslint/no-unsafe-argument': 0,
        '@typescript-eslint/ban-ts-comment': 0,
        'no-redundant-type-constituents': 0,
    },
};
```

我们新增三个规则文件，`nestjs.js`,`nextjs.js`,`react.js`，同样地，由于`nextjs`的特殊性，所以他的规则单独配置，其它两者的规则继承自`base-ts.js`

nestjs.js

```javascript
module.exports = {
    env: {
        node: true,
        jest: true,
    },
    extends: [
        // airbnb规范
        // https://www.npmjs.com/package/eslint-config-airbnb-base
        'airbnb-base',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript/base',
        './base-ts',
    ],
    settings: {
        extensions: ['.ts', '.d.ts', '.cts', '.mts', '.js', '.cjs', 'mjs', '.json'],
    },
};
```

react.js 

```javascript
module.exports = {
    parserOptions: {
        // React启用jsx
        ecmaFeatures: {
            jsx: true,
        },
    },
    env: {
        es6: true,
        browser: true,
        jest: true,
        node: true,
    },
    plugins: ['react-refresh'],
    extends: [
        // airbnb规范
        // airbnb规范
        // https://github.com/airbnb/javascript/tree/master/packages/eslint-config-airbnb
        'airbnb',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript',
        // react hooks的airbnb规范
        'airbnb/hooks',
        './base-ts',
    ],
    rules: {
        /* ********************************** React and Hooks ********************************** */
        'react/jsx-uses-react': 1,
        'react/jsx-uses-vars': 1,
        'react/jsx-no-useless-fragment': 0,
        'react/display-name': 0,
        'react/button-has-type': 0,
        'react/prop-types': 0,
        'react/jsx-props-no-spreading': 0,
        'react/destructuring-assignment': 0,
        'react/static-property-placement': 0,
        'react/react-in-jsx-scope': 0,
        'react/require-default-props': 0,
        'react/jsx-filename-extension': [1, { extensions: ['.jsx', '.tsx'] }],
        'react/function-component-definition': [
            2,
            { namedComponents: 'arrow-function', unnamedComponents: 'arrow-function' },
        ],
        'react-hooks/exhaustive-deps': 0,
        'react-refresh/only-export-components': 0,

        /* ********************************** jax-a11y ********************************** */
        'jsx-a11y/anchor-is-valid': 0,
        'jsx-a11y/no-static-element-interactions': 0,
        'jsx-a11y/click-events-have-key-events': 0,
        'jsx-a11y/label-has-associated-control': [
            'error',
            {
                required: {
                    some: ['nesting', 'id'],
                },
            },
        ],
    },
    settings: {
        extensions: ['.ts', '.tsx', '.d.ts', '.cts', '.mts', '.js', 'jsx', '.cjs', 'mjs', '.json'],
    },
};
```

nextjs.js 

```javascript
module.exports = {
    plugins: ['@typescript-eslint', 'prettier', 'unused-imports', 'prettier'],
    extends: [
        // airbnb规范
        // https://github.com/airbnb/javascript/tree/master/packages/eslint-config-airbnb
        'airbnb',
        // 兼容typescript的airbnb规范
        // https://github.com/iamturns/eslint-config-airbnb-typescript
        'airbnb-typescript',
        // react hooks的airbnb规范
        'airbnb/hooks',

        // typescript的eslint插件
        // https://github.com/typescript-eslint/typescript-eslint/blob/master/docs/getting-started/linting/README.md
        // https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/eslint-plugin
        'plugin:@typescript-eslint/recommended',
        'plugin:@typescript-eslint/recommended-requiring-type-checking',

        // nextjs配置
        // https://nextjs.org/docs/app/building-your-application/configuring/eslint#migrating-existing-config
        'plugin:@next/next/recommended',
        // 'next/core-web-vitals',
        // 使用prettier格式化代码
        // https://github.com/prettier/eslint-config-prettier#readme
        'prettier',
        // 整合typescript-eslint与prettier
        // https://github.com/prettier/eslint-plugin-prettier
        'plugin:prettier/recommended',
    ],
    rules: {
        /* ********************************** ES6+ ********************************** */
        'no-console': 0,
        'no-var-requires': 0,
        'no-restricted-syntax': 0,
        'no-continue': 0,
        'no-await-in-loop': 0,
        'no-return-await': 0,
        'no-multi-assign': 0,
        'no-param-reassign': [2, { props: false }],
        'max-classes-per-file': 0,
        'class-methods-use-this': 0,
        'guard-for-in': 0,
        'no-underscore-dangle': 0,
        'no-plusplus': 0,
        'no-lonely-if': 0,
        'no-bitwise': ['error', { allow: ['~'] }],

        /* ********************************** Module Import ********************************** */

        'import/prefer-default-export': 0,
        'import/no-cycle': 0,
        'import/no-dynamic-require': 0,
        'import/no-absolute-path': 0,
        'import/extensions': 0,

        // 一部分文件在导入devDependencies的依赖时不报错
        'import/no-extraneous-dependencies': [
            1,
            {
                devDependencies: [
                    '**/*.test.{ts,js}',
                    '**/*.spec.{ts,js}',
                    'build/**/*.{ts,js}',
                    'mock/**/*.{ts,js}',
                    '**.{ts,js}',
                ],
            },
        ],
        // 模块导入顺序规则
        'import/order': [
            1,
            {
                pathGroups: [
                    {
                        pattern: '@/**',
                        group: 'external',
                        position: 'after',
                    },
                ],
                'newlines-between': 'always-and-inside-groups',
                warnOnUnassignedImports: true,
            },
        ],
        // 自动删除未使用的导入
        // https://github.com/sweepline/eslint-plugin-unused-imports
        'no-unused-vars': 0,
        '@typescript-eslint/no-unused-vars': 0,
        'unused-imports/no-unused-imports': 1,
        'unused-imports/no-unused-vars': [
            'error',
            {
                vars: 'all',
                args: 'none',
                ignoreRestSiblings: true,
            },
        ],

        /* ********************************** Typescript ********************************** */
        '@typescript-eslint/no-empty-interface': 0,
        '@typescript-eslint/no-this-alias': 0,
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/no-use-before-define': 0,
        '@typescript-eslint/explicit-member-accessibility': 0,
        '@typescript-eslint/no-non-null-assertion': 0,
        '@typescript-eslint/no-unnecessary-type-assertion': 0,
        '@typescript-eslint/require-await': 0,
        '@typescript-eslint/no-for-in-array': 0,
        '@typescript-eslint/interface-name-prefix': 0,
        '@typescript-eslint/explicit-function-return-type': 0,
        '@typescript-eslint/no-explicit-any': 0,
        '@typescript-eslint/explicit-module-boundary-types': 0,
        '@typescript-eslint/no-floating-promises': 0,
        '@typescript-eslint/restrict-template-expressions': 0,
        '@typescript-eslint/no-unsafe-assignment': 0,
        '@typescript-eslint/no-unsafe-return': 0,
        '@typescript-eslint/no-unused-expressions': 0,
        '@typescript-eslint/no-misused-promises': 0,
        '@typescript-eslint/no-unsafe-member-access': 0,
        '@typescript-eslint/no-unsafe-call': 0,
        '@typescript-eslint/no-unsafe-argument': 0,

        /* ********************************** React and Hooks ********************************** */
        'react/jsx-uses-react': 1,
        'react/jsx-uses-vars': 1,
        'react/jsx-no-useless-fragment': 0,
        'react/display-name': 0,
        'react/button-has-type': 0,
        'react/prop-types': 0,
        'react/jsx-props-no-spreading': 0,
        'react/destructuring-assignment': 0,
        'react/static-property-placement': 0,
        'react/react-in-jsx-scope': 0,
        'react/require-default-props': 0,
        'react/jsx-filename-extension': [1, { extensions: ['.jsx', '.tsx'] }],
        'react/function-component-definition': [
            2,
            { namedComponents: 'arrow-function', unnamedComponents: 'arrow-function' },
        ],
        'react-hooks/exhaustive-deps': 0,
        'react/function-component-definition': 0,
        /* ********************************** jax-a11y ********************************** */
        'jsx-a11y/anchor-is-valid': 0,
        'jsx-a11y/no-static-element-interactions': 0,
        'jsx-a11y/click-events-have-key-events': 0,
        'jsx-a11y/label-has-associated-control': [
            'error',
            {
                required: {
                    some: ['nesting', 'id'],
                },
            },
        ],
    },
};
```

增加一个`index.js`用来导出`base.js`作为默认规则

```javascript
import * as base from './base';
module.exports = base;
```

接下来，为了我们这个`eslint-config`包本身可以应用eslint，在该目录下分别添加`.prettierrc.js`，`.prettierignore`,`.eslintrc.js`,`.eslintignore`这几个文件，除了`.eslintrc.js`这个文件外，其它均从前面课程复制过来即可

`.eslintrc.js`则直接使用`base.js`的规则

```javascript
module.exports = {
    root: true,
    extends: ['./base'],
};
```

### Stylelint配置包

为了nextjs,react等前端应用可以共享stylelint配置，我们创建一个`stylelint-config`包

同样，先新增一个`package.json`文件

注意：这里我们就用到了刚才的`eslint-config`包，可以看到引用方式是` "@3rcu/eslint-config": "workspace:*"`。后面我们把`stylint-config`进行发包后，这个`workspace:*`自动会转换为`eslint-config`的版本号

```json
{
    "name": "@3rcu/stylelint-config",
    "version": "0.0.0",
    "main": "index.js",
    "dependencies": {
        "stylelint": "^15.10.2",
        "stylelint-config-css-modules": "^4.3.0",
        "stylelint-config-recess-order": "^4.3.0",
        "stylelint-config-standard": "^34.0.0",
        "stylelint-prettier": "^4.0.0"
    },
    "devDependencies": {
        "@3rcu/eslint-config": "workspace:*"
    }
}
```

新建一个`index.js`文件，把前面课程中的`stylelint`配置放进去

```javascript
module.exports = {
    extends: [
        'stylelint-config-standard',
        'stylelint-config-css-modules',
        'stylelint-config-recess-order',
        'stylelint-prettier/recommended',
    ],
    rules: {
        'import-notation': 'string', // 使用string方式引入其它css文件，而不是url()
        'selector-type-no-unknown': null,
        'selector-class-pattern': null,
        'custom-property-pattern': null,
        'no-duplicate-selectors': null, // 取消禁止重复定义,这样可以在css module中单独定义变量
        'block-no-empty': null, // 禁止出现空块
        'declaration-empty-line-before': 'never',
        'declaration-block-no-duplicate-properties': true, // 在声明的块中中禁止出现重复的属性
        'declaration-block-no-redundant-longhand-properties': true, // 禁止使用可以缩写却不缩写的属性
        'shorthand-property-no-redundant-values': true, // 禁止在简写属性中使用冗余值
        'color-hex-length': 'short', // 指定十六进制颜色是否使用缩写
        'comment-no-empty': true, // 禁止空注释
        'font-family-name-quotes': 'always-unless-keyword', // 指定字体名称是否需要使用引号引起来 | 期待每一个不是关键字的字体名都使用引号引起来
        // 'font-weight-notation': 'numeric', // 要求使用数字或命名的 (可能的情况下) font-weight 值
        'function-url-quotes': 'always', // 要求或禁止 url 使用引号
        'property-no-vendor-prefix': true, // 禁止属性使用浏览器引擎前缀
        'value-no-vendor-prefix': true, // 禁止给值添加浏览器引擎前缀
        'selector-no-vendor-prefix': true, // 禁止使用浏览器引擎前缀
        'no-descending-specificity': null, // 禁止低优先级的选择器出现在高优先级的选择器之后
        'at-rule-no-unknown': [
            true,
            {
                ignoreAtRules: ['layer', 'apply', 'screen', 'define-mixin', 'mixin'],
            },
        ],

        'property-no-unknown': [
            true,
            {
                ignoreProperties: [
                    // CSS Modules composition
                    // https://github.com/css-modules/css-modules#composition
                    'composes',
                ],
            },
        ],

        'selector-pseudo-class-no-unknown': [
            true,
            {
                ignorePseudoClasses: [
                    // CSS Modules :global scope
                    // https://github.com/css-modules/css-modules#exceptions
                    'global',
                    'local',
                ],
            },
        ],
        'rule-empty-line-before': [
            // 要求或禁止在规则声明之前有空行
            'always-multi-line',
            {
                except: ['first-nested'],
                ignore: ['after-comment'],
            },
        ],
        'at-rule-empty-line-before': [
            // 要求或禁止在 at 规则之前有空行
            'always',
            {
                except: ['blockless-after-same-name-blockless', 'first-nested'],
                ignore: ['after-comment'],
            },
        ],
        'comment-empty-line-before': [
            // 要求或禁止在注释之前有空行
            'always',
            {
                except: ['first-nested'],
                ignore: ['stylelint-commands'],
            },
        ],
    },
};
```

最后，我们同样添加`.prettierrc.js`，`.prettierignore`,`.eslintrc.js`,`.eslintignore`这几个文件（除了`.eslintrc.js`外，其它的直接复制`eslint-config`这个包中的文件即可）。现在，在`.eslintrc.js`中可以使用`@3rcu/eslint-config`这个包中的扩展了，像这样

:::caution

注意：这里的`root`很重要

:::

```javascript
// packages/stylelint-config/.eslintrc.js
module.exports = {
    root: true,
    extends: ['@3rcu/eslint-config/base'],
};
```

## 应用包

### React应用

我们把前面React课程的代码给复制到`apps`中，该目录名为`admin`，然后运行`rm -rf ./apps/admin/node_modules && rm -rf ./apps/admin/.vscode`以删除原本的依赖包。

把`package.json`中`eslint`和`stylelint`相关的扩展和插件的依赖项通通删除，而在`devDependencies`依赖中添加我们自己的`eslint-config`,`ts-config`以及`stylelint-config`依赖

:::tip

别忘了改`package.json`的`name`字段

:::

```json
{
    "name": "@3rcu/admin",
    "private": true,
    "version": "0.0.0",
    "scripts": {
        "dev": "vite",
        "build": "tsc && vite build",
        "lint": "pnpm lint:es && pnpm lint:style",
        "lint:es": "eslint . --ext ts,tsx --fix --report-unused-disable-directives --max-warnings 0",
        "lint:style": "stylelint \"**/*.css\" --fix --cache --cache-location node_modules/.cache/stylelint/",
        "preview": "vite preview"
    },
    "dependencies": {
        "@ant-design/cssinjs": "^1.16.1",
        "antd": "^5.8.1",
        "dayjs": "^1.11.9",
        "deepmerge": "^4.3.1",
        "react": "^18.2.0",
        "react-dom": "^18.2.0"
    },
    "devDependencies": {
        "@3rcu/eslint-config": "workspace:*",
        "@3rcu/stylelint-config": "workspace:*",
        "@3rcu/ts-config": "workspace:*",
        "@types/node": "^20.4.6",
        "@types/react": "^18.2.15",
        "@types/react-dom": "^18.2.7",
        "@vitejs/plugin-react": "^4.0.3",
        "autoprefixer": "^10.4.14",
        "eslint": "^8.45.0",
        "postcss": "^8.4.27",
        "postcss-import": "^15.1.0",
        "postcss-mixins": "^9.0.4",
        "postcss-nested": "^6.0.1",
        "postcss-nesting": "^12.0.0",
        "prettier": "^3.0.0",
        "stylelint": "^15.10.2",
        "tailwindcss": "^3.3.3",
        "typescript": "^5.0.2",
        "vite": "^4.4.5"
    }
}
```

修改`tsconfig.json`，让它集成我们的`ts-config`包中的`react.json`

```json
{
    "extends": "@3rcu/ts-config/react.json",
    "compilerOptions": {
        "baseUrl": ".",
        "outDir": "./dist",
        "paths": {
            "@/*": ["src/*"]
        },
        "types": ["@types/node"]
    },
    "include": ["./src", "./typings/**/*.d.ts"],
    "references": [{ "path": "./tsconfig.node.json" }]
}
```

修改`.eslintrc`配置，使其继承`eslint-config`包

```javascript
module.exports = {
    root: true,
    parserOptions: {
        project: './tsconfig.eslint.json',
    },
    extends: ['@3rcu/eslint-config/react'],
};
```

修改`.stylelintrc.js`配置，使其继承`stylelint-config`包

```javascript
module.exports = {
    root: true,
    extends: ['@3rcu/stylelint-config'],
};
```

### Nestjs应用

与React相似

1. 复制Nestjs课程的代码到`apps`，改目录名为`api`
2. 运行`rm -rf ./apps/api/node_modules && rm -rf ./apps/api/.vscode`
3. 然后修改`package.json`,`tsconfig.json`,`.eslintrc.js`

:::info

需要在`package.json`中添加一个`dev`命令，`--preserveWatchOutput`参数代表启动时不刷新命令行窗口

:::

package.json

```json
{
    "name": "@3rcu/api",
    "version": "0.0.1",
    "description": "",
    "author": "",
    "private": true,
    "license": "UNLICENSED",
    "scripts": {
        "build": "nest build",
        "format": "prettier --write \"src/**/*.ts\" \"test/**/*.ts\"",
        "dev": "nest start --watch --preserveWatchOutput",
        "start": "nest start",
        "start:dev": "nest start --watch",
        "start:debug": "nest start --debug --watch",
        "start:prod": "node dist/main",
        "lint": "eslint \"{src,apps,libs,test}/**/*.ts\" --fix",
        "test": "jest",
        "test:watch": "jest --watch",
        "test:cov": "jest --coverage",
        "test:debug": "node --inspect-brk -r tsconfig-paths/register -r ts-node/register node_modules/.bin/jest --runInBand",
        "test:e2e": "jest --config ./test/jest-e2e.json"
    },
    "dependencies": {
        "@nestjs/common": "^10.1.2",
        "@nestjs/core": "^10.1.2",
        "@nestjs/platform-express": "^10.1.2",
        "reflect-metadata": "^0.1.13",
        "rxjs": "^7.8.1"
    },
    "devDependencies": {
        "@3rcu/ts-config": "workspace:*",
        "@3rcu/eslint-config": "workspace:*",
        "@nestjs/cli": "^10.1.10",
        "@nestjs/schematics": "^10.0.1",
        "@nestjs/testing": "^10.1.2",
        "@swc/cli": "^0.1.62",
        "@swc/core": "^1.3.74",
        "@types/express": "^4.17.17",
        "@types/jest": "^29.5.3",
        "@types/node": "^20.4.5",
        "@types/supertest": "^2.0.12",
        "eslint": "^8.46.0",
        "jest": "^29.6.2",
        "prettier": "^3.0.0",
        "source-map-support": "^0.5.21",
        "supertest": "^6.3.3",
        "ts-jest": "^29.1.1",
        "ts-loader": "^9.4.4",
        "ts-node": "^10.9.1",
        "tsconfig-paths": "^4.2.0",
        "typescript": "^5.1.6"
    },
    "jest": {
        "moduleFileExtensions": [
            "js",
            "json",
            "ts"
        ],
        "rootDir": "src",
        "testRegex": ".*\\.spec\\.ts$",
        "transform": {
            "^.+\\.(t|j)s$": "ts-jest"
        },
        "collectCoverageFrom": [
            "**/*.(t|j)s"
        ],
        "coverageDirectory": "../coverage",
        "testEnvironment": "node"
    }
}
```

tsconfig.json

```json
{
    "extends": "@3rcu/ts-config/nestjs.json",
    "compilerOptions": {
        "baseUrl": ".",
        "outDir": "./dist",
        "paths": {
            "@/*": ["./src/*"]
        }
    },
    "include": ["src", "test", "typings/**/*.d.ts", "**.js"]
}
```

.eslintrc.js

```json
module.exports = {
  root: true,
  parserOptions: {
    project: 'tsconfig.json',
    tsconfigRootDir: __dirname,
  },
  extends: ['@3rcu/eslint-config/nestjs'],
};
```

如果`package.json`中有`pnpm`配置，请把它移动到根目录的`package.json`中，比如

```json
 "pnpm": {
        "peerDependencyRules": {
            "ignoreMissing": [
                "webpack"
            ]
        }
    }
```

为了可以使用`nest cli`的命令，在`apps/api/package.json`增加一个script

```json
"scripts": {
    "cli": "nest"
},
```

在根目录下的`package.json`中映射这个命令

```json
"scripts": {
    "api:cli": "turbo run cli --cwd=./apps/api --",
}
```

```json
{
    ...
    "pipeline": {
        "cli": {},
}
```

执行一下`pnpm api:cli`命令，看一下是否正常

![](https://img.pincman.com/media/202308171350322.png)

现在可以通过`pnpm api:cli`在根目录下执行`nest cli`命令了，例如执行`pnpm api:cli g mo modules/content`命令生成模块

为了跟nextjs的端口不冲突，我们修改一下端口

```typescript
// apps/api/src/main.ts
import { NestFactory } from '@nestjs/core';

import { AppModule } from './app.module';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    await app.listen(3100);
}
bootstrap();
```

### Nextjs应用

把`docs`和`web`目录删除，因为这里默认的nextjs应用是我们不需要的。然后把Nestjs课程的代码目录复制进去，并重命名为`web`。

运行`rm -rf ./apps/web/node_modules && rm -rf ./apps/web/.vscode`以删除多余目录

同样，修改`package.json`,`tsconfig.json`,`.eslintrc.js`和`.stylelintrc.js`这几个文件

package.json

```json
{
    "name": "@3rcu/web",
    "version": "0.1.0",
    "private": true,
    "scripts": {
        "dev": "next dev",
        "build": "next build",
        "start": "next start",
        "lint": "pnpm lint:es && pnpm lint:style",
        "lint:es": "next lint --fix",
        "lint:style": "stylelint \"**/*.css\" --fix --cache --cache-location node_modules/.cache/stylelint/"
    },
    "dependencies": {
        "@radix-ui/react-slot": "^1.0.2",
        "@types/node": "20.4.6",
        "@types/react": "18.2.18",
        "@types/react-dom": "18.2.7",
        "class-variance-authority": "^0.7.0",
        "clsx": "^2.0.0",
        "eslint-config-next": "13.4.12",
        "lucide-react": "^0.263.1",
        "next": "13.4.12",
        "react": "18.2.0",
        "react-dom": "18.2.0",
        "tailwind-merge": "^1.14.0",
        "tailwindcss-animate": "^1.0.6",
        "typescript": "5.1.6"
    },
    "devDependencies": {
        "@3rcu/ts-config": "workspace:*",
        "@3rcu/eslint-config": "workspace:*",
        "@3rcu/stylelint-config": "workspace:*",
        "autoprefixer": "^10.4.14",
        "eslint": "8.46.0",
        "postcss": "^8.4.27",
        "postcss-import": "^15.1.0",
        "postcss-mixins": "^9.0.4",
        "postcss-nested": "^6.0.1",
        "postcss-nesting": "^12.0.0",
        "stylelint": "^15.10.2"
    }
}
```

tsconfig.json

```json
{
    "extends": "@3rcu/ts-config/nextjs.json",
    "compilerOptions": {
        "baseUrl": ".",
        "outDir": "./dist",
        "paths": {
            "@/*": ["./src/*"]
        }
    },
    "include": ["next-env.d.ts", "typings/**/*.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
    "exclude": ["node_modules"]
}
```

.eslintrc.js

```javascript
module.exports = {
    root: true,
    parserOptions: {
        project: './tsconfig.eslint.json',
    },
    extends: ['@3rcu/eslint-config/nextjs'],
};
```

## 全局配置

修改根目录下的`package.json`

在运行`devadmin`的同时运行`api`的目的在于，后续我们的`admin`调用的api是nestjs中的api，故同时启动，目前因为我们没有涉及到nextjs，所以其作用与直接运行`dev`等效

```json
{
    "private": true,
    "scripts": {
        "build": "turbo run build",
        "dev": "turbo run dev",
        "api:dev": "turbo run dev --filter=api",
        "admin:dev": "turbo run dev --filter=admin --filter=api",
        "web:dev": "turbo run dev --filter=web --filter=api",
        "lint": "turbo run lint",
        "format": "prettier --write \"**/*.{ts,tsx,md}\"",
        "upall": "pnpm up --filter @3rcu/* --latest && pnpm up --latest"
    },
    "devDependencies": {
        "@3rcu/eslint-config": "workspace:*",
        "@turbo/gen": "^1.10.12",
        "eslint": "^7.32.0",
        "prettier": "^2.8.8",
        "turbo": "latest"
    },
    "packageManager": "pnpm@8.6.10",
    "name": "3rcu"
}
```

为根目录添加`.eslintrc.js`，`.eslintignore`,`.prettierrc.js`和`.prettierignore`以便在根目录下也能使用eslint，除了`.eslintrc.js`外，其它全部随便复制一个包下的文件即可

.eslintrc.js

```javascript
module.exports = {
  root: true,
  extends: ['@3rcu/eslint-config/base'],
  next: {
    rootDir: ["apps/*/"],
  },
};
```

配置一下`.gitignore`

```json
# See https://help.github.com/articles/ignoring-files/ for more about ignoring files.

# dependencies
node_modules
.pnp
.pnp.js

# testing
coverage
.nyc_output

# compiled output
.next/
out/
build
dist

# misc
.DS_Store
*.pem

# debug
npm-debug.log*
logs
*.log
npm-debug.log*
pnpm-debug.log*
yarn-debug.log*
yarn-error.log*
lerna-debug.log*

# local env files
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# turbo
.turbo

# vercel
.vercel

# IDEs and editors
/.idea
.project
.classpath
.c9/
*.launch
.settings/
*.sublime-workspace

# IDE - VSCode
.vscode/*
!.vscode/settings.json
!.vscode/tasks.json
!.vscode/launch.json
!.vscode/extensions.json
```

### 配置vscode

为了让vscode支持eslint的工作目录模式，在根目录下添加`.vscode/settings.json`文件

```json
{
    "editor.formatOnSave": false,
    "editor.codeActionsOnSave": {
        "source.fixAll.eslint": true,
        "source.fixAll.stylelint": true
    },
    "eslint.workingDirectories": [{ "pattern": "./apps/*/" }, { "pattern": "./packages/*/" }],
    "css.validate": false,
    "less.validate": false,
    "scss.validate": false,
    "postcss.validate": false,
    "emmet.includeLanguages": {
        "postcss": "css"
    },
    "stylelint.enable": true,
    "stylelint.snippet": ["css", "scss", "less", "postcss"],
    "stylelint.validate": ["css", "scss", "less", "postcss"],
    "javascript.preferences.importModuleSpecifier": "project-relative",
    "typescript.suggest.jsdoc.generateReturns": false,
    "typescript.tsserver.experimental.enableProjectDiagnostics": true,
    "stylelint.packageManager": "pnpm",
    "npm.packageManager": "pnpm"
}
```

### 使用方法

运行`pnpm i`安装所有依赖（包括自定义扩展包），后续每次新增或删除扩展包，建议`pnpm i`一下。

然后运行

```bash
pnpm up --filter @3rcu/* --latest && pnpm up --latest
```

用于升级所有扩包中和根目录的库到最新版

现在我们尝试`pnpm dev`，看一下效果，可以看到，同时并行启动了nestjs,web和admin

![image-20230724183324763](https://img.pincman.com/media/202307241833949.png)

### 类库扩展包

我们编写一个简单的工具包类库，尝试一下其他库能否调用

在`packages`目录中新增一个`utils`目录，文件如下

package.json

:::note

如果是前端框架，或者使用esm而非commonjs的后端框架的话，`main`和`type`直接使用`src/index.ts`且不需要再在`turbo.json`里添加预先编译了

:::

```json
{
    "name": "@3rcu/utils",
    "version": "0.0.0",
    "main": "dist/index.js",
    "types": "dist/index.d.ts",
    "scripts": {
        "dev": "tsc -w -p tsconfig.build.json",
        "build": "tsc -b tsconfig.build.json",
        "lint": "eslint . --ext ts,tsx"
    },
    "dependencies": {
        "deepmerge": "^4.3.1"
    },
    "devDependencies": {
        "@3rcu/ts-config": "workspace:*",
        "@3rcu/eslint-config": "workspace:*",
        "typescript": "^5.0.2"
    }
}
```

.eslintrc.js

```javascript
module.exports = {
    root: true,
    parserOptions: {
        project: 'tsconfig.json',
        tsconfigRootDir: __dirname,
    },
    extends: ['@3rcu/eslint-config/nestjs'],
};
```

`.eslintignore`,`.prettierrc.js`和`.prettierignore`三个文件直接复制其它包

tsconfig.json

```json
{
    "extends": "@3rcu/ts-config/nestjs.json",
    "compilerOptions": {
        "baseUrl": ".",
        "outDir": "./dist",
        "module": "CommonJS",
        "paths": {
            "@/*": ["src/*"]
        }
    },
    "include": ["src", "test", "typings/**/*.d.ts", "**.js"]
}
```

tsconfig.build.json

```json
{
    "extends": "./tsconfig.json",
    "exclude": ["node_modules", "test", "dist", "**/*spec.ts", "**.js"]
}
```

添加一个`src`目录，里面两个文件内容如下

```typescript
// packages/utils/src/tools.ts
import deepmerge from 'deepmerge';

/**
 * 深度合并对象
 * @param x 初始值
 * @param y 新值
 * @param arrayMode 对于数组采取的策略,`replace`为直接替换,`merge`为合并数组
 */
export const deepMerge = <T1, T2>(
    x: Partial<T1>,
    y: Partial<T2>,
    arrayMode: 'replace' | 'merge' = 'merge',
) => {
    const options: deepmerge.Options = {};
    if (arrayMode === 'replace') {
        options.arrayMerge = (_d, s, _o) => s;
    } else if (arrayMode === 'merge') {
        options.arrayMerge = (_d, s, _o) => Array.from(new Set([..._d, ...s]));
    }
    return deepmerge(x, y, options) as T2 extends T1 ? T1 : T1 & T2;
};

// packages/utils/src/index.ts
export * from './tools';
```

下面，我们在nestjs应用中使用这个库

首先，在api的`package.json`中添加一下这个库

```json
// apps/api/package.json
   "dependencies": {
        "@3rcu/utils": "workspace:*",
       ...
    },
```

运行`pnpm i`安装依赖

第一次这样编写会报错，这是因为`@3rcu/utils`还没编译过，先不用去管它，运行一次之后就好了

```typescript
// apps/api/src/app.controller.ts
import { deepMerge } from '@3rcu/utils';
import { Controller, Get } from '@nestjs/common';

import { AppService } from './app.service';

@Controller()
export class AppController {
    constructor(private readonly appService: AppService) {}

    @Get()
    getHello(): string {
        console.log("Hello! I'am pincman!");
        console.log(deepMerge({ a: 'a' }, { b: 'b' }));
        return this.appService.getHello();
    }
}
```

为了让api在`dev`的时候能直接引用预先编译的依赖，我们在`turbo`中添加一下`api#dev`设置,这让api在启动前先编译一下它依赖的包

:::caution

再次提醒：如果该类库只是用于前端框架，或者使用esm而非commonjs的后端框架的话，则在`package.json`中让`main`和`type`字段直接使用`src/index.ts`即可，不需要再在`turbo.json`里添加预先编译了

:::

如果没有自动编译，请手动执行`pnpm build --filter=utils`，下次就会自动编译了

编译好之后按住`cmd+shift+p`选择"重启typescript服务器"，然后就有自动提示了，类似这样写一下

```json
{
    "$schema": "https://turbo.build/schema.json",
    "globalDependencies": [
        ".env",
        ".env.*",
        "**/.env",
        "**/.env.*",
        "**/tsconfig.json",
        "**/tsconfig.build.json"
    ],
    "globalEnv": ["NODE_ENV"],
    "pipeline": {
        "build": {
            "dependsOn": ["^build"],
            "outputs": ["dist/**"]
        },
        "lint": {},
        "dev": {
            "cache": false,
            "persistent": true
        },
        "api#dev": {
            "dependsOn": ["^build"]
        }
    }
}
```

## 启动应用

运行`pnpm dev:api`，打开[http://localhost:3100](http://localhost:3100)，看到控制台输出了，这就证明我们不仅只是在打包后可以调用其它包的东西，在开发环境中也是可以的！

分别打开

- 前台: [http://localhost:3000](http://localhost:3000)
- 后台: [http://localhost:5173](http://localhost:5173)
- 后端: [http://localhost:3100](http://localhost:3100)

就能看到效果了，其中后端可以使用`@3rcu/utils`这个包

![image-20230804020924007](https://img.pincman.com/media/202308040209280.png)

至此基本的monorepo框架已经搭建完毕，等学习完全部课程的开发篇，我们将会再次把注意力集中在monorepo，实现CI/CD等以使我们的应用上线！

最后我们的目录结构如下

```shell
.
├── README.md
├── apps
│   ├── admin
│   │   ├── README.md
│   │   ├── index.html
│   │   ├── node_modules
│   │   ├── package.json
│   │   ├── pnpm-lock.yaml
│   │   ├── postcss.config.js
│   │   ├── public
│   │   ├── scripts
│   │   ├── src
│   │   ├── tailwind.config.js
│   │   ├── tsconfig.eslint.json
│   │   ├── tsconfig.json
│   │   ├── tsconfig.node.json
│   │   └── vite.config.ts
│   ├── api
│   │   ├── README.md
│   │   ├── dist
│   │   ├── nest-cli.json
│   │   ├── node_modules
│   │   ├── package.json
│   │   ├── pnpm-lock.yaml
│   │   ├── src
│   │   ├── test
│   │   ├── tsconfig.build.json
│   │   └── tsconfig.json
│   └── web
│       ├── README.md
│       ├── components.json
│       ├── next-env.d.ts
│       ├── next.config.js
│       ├── node_modules
│       ├── package.json
│       ├── pnpm-lock.yaml
│       ├── postcss.config.js
│       ├── public
│       ├── src
│       ├── tailwind.config.js
│       ├── tsconfig.eslint.json
│       └── tsconfig.json
├── node_modules
├── package.json
├── packages
│   ├── eslint-config
│   │   ├── base-ts.js
│   │   ├── base.js
│   │   ├── index.js
│   │   ├── nestjs.js
│   │   ├── nextjs.js
│   │   ├── node_modules
│   │   ├── package.json
│   │   └── react.js
│   ├── stylelint-config
│   │   ├── index.js
│   │   ├── node_modules
│   │   └── package.json
│   ├── ts-config
│   │   ├── base.json
│   │   ├── nestjs.json
│   │   ├── nextjs.json
│   │   ├── package.json
│   │   └── react.json
│   └── utils
│       ├── dist
│       ├── node_modules
│       ├── package.json
│       ├── src
│       ├── tsconfig.build.json
│       └── tsconfig.json
├── pnpm-lock.yaml
├── pnpm-workspace.yaml
└── turbo.json
```

