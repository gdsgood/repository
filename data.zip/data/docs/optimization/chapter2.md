---
title: 无懈可击的Linux服务器构建
sidebar_label: 无懈可击的Linux服务器构建
hide_title: true
sidebar_position: 2
---

# 无懈可击的Linux服务器构建

## 初始化

### 连接服务器

一般在购买服务器后，我们不用密码登录，而是直接用ssh key去登录，所以我们生成一个key

使用`ssh-keygen -t rsa -C "你的邮箱"`命令，并一路按回车即可生成，生成的位置在`~/.ssh`目录下

:::info

windows下可以装个[git](https://git-scm.com/download/win)，使用gitbash去生成，生成的key会在`/c/用户名/.ssh`下面

:::

![](https://img.pincman.com/media/202308041655978.png)

有了ssh key之后，我们复制里面的`id_rsa.pub`中的内容到我们的服务器厂商的控制台中，并绑定到你的服务器

![](https://img.pincman.com/media/202308041656438.png)

我们以青云为示例，点创建**SSH秘钥**

![](https://img.pincman.com/media/202308041659286.png)

然后点到服务器管理里**加载SSH秘钥**

![](https://img.pincman.com/media/202308041703711.png)

现在我们可以通过`ssh root@你的ip地址`来连接服务器了

为了更方便地连接服务器，我们可以创建一个config文件并添加一个连接别名，像这样

![](https://img.pincman.com/media/202308041711426.png)

现在，我们可以通过`ssh devroot`命令来连接服务器了

![](https://img.pincman.com/media/202308041714143.png)

### 升级

此项可选择操作，不是必须的

```bash
apt update && apt upgrade -y
```

### 挂载硬盘

如果我们有额外的数据盘，则可以挂载到服务器上，避免重装后的数据丢失

首先先在控制台中把硬盘挂载到服务器

![image-20230804171843918](https://img.pincman.com/media/202308041718845.png)

1、查看挂载的硬盘名

> 此处硬盘名是`vdc`

```bash
fdisk -l
```

![](https://img.pincman.com/media/202308041737532.png)

二、分区

:::tip

如果已经分区，但是数据不需要了，可以使用`mkfs -t ext4 /dev/vdc`全部格式化

:::

我们需要用到两个分区，分别挂载到`/home`(用于存放用户数据，包括网站等)，以及`/data`用于存放数据库数据等

使用以下命令开始分区

```bash
fdisk /dev/vdc
```

下面输入`n`，然后输入`p`(创建主分区),输入`1`(编号为`1`的分区)，按回车(选择默认的起始磁盘柱为`2048`)，尾柱输入`+80G`

然后继续输入`n`重复上面步骤再添加一个分区，这时全部默认即可，因为尾柱默认会到底，也就是第二个分区占用`20G`，这样磁盘就全部利用起来了

分区完毕后，按`p`查看分区信息

最后输入`w`将分区写入分区表中

![image-20230804175231440](https://img.pincman.com/media/202308041752181.png)

接下来格式化两个分区，使用以下命令

```bash
mkfs -t ext4 /dev/vdc1 && mkfs -t ext4 /dev/vdc2
```

![image-20230804175538143](https://img.pincman.com/media/202308041755628.png)

如果`/data`或`/home`目录不存在的话请先创建一下

```bash
mkdir /home
mkdir /data
```

现在编辑`/etc/fstab`文件来挂载分区

:::info

这里我们略过`mount`命令的临时挂载，直接使用永久挂载

:::

```bash
vi /etc/fstab
```

然后在文件中添加如下内容

:::info

vim的基本使用可以查看[这里](https://www.youtube.com/watch?v=mPVwS8gjDVI&list=PLBd8JGCAcUAH56L2CYF7SmWJYKwHQYUDI)的教程

:::

```nginx
/dev/vdc1 /home   ext4 defaults,nofail     0   2
/dev/vdc2 /data   ext4 defaults,nofail     0   2
```

执行`mount -a`命令，如果没有任何输出，则证明已经正常，我们使用`reboot`命令重启一下服务器，用`df -TH`命令看一下，是否已经挂载

![image-20230804180918636](https://img.pincman.com/media/202308041809079.png)

### ZSH

如果你的服务器内存足够，使用zsh可以更好地体验linux的快乐，同时也可以作为开发服务器使用

一、安装并切换到zsh

```bash
touch ~/.hushlogin  # 禁止欢迎消息
apt-get install -y zsh # 安装
chsh -s /bin/zsh # 切换
```

退出在登录一下，可以看到命令行有变化了

二、安装ohmyzsh

先安装一下wget和git

```bash
apt-get install -y wget git
```

使用以下命令安装

:::info

如果是国内服务器，可以使用镜像代替：`sh -c "$(wget -O- https://gitee.com/mirrors3r/ohmyzsh/raw/master/tools/install.sh)"`

:::

```bash
sh -c "$(wget -O- https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
```

![image-20230804210443167](https://img.pincman.com/media/202308042104414.png)

三、安装power10k

使用以下命令安装

```bash
git clone --depth=1 https://github.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k
```

如果是国内服务器可以用镜像

```bash
git clone --depth=1 https://gitee.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k
```

在`.zshrc`中设置主题为`powerlevel10k/powerlevel10k`

![image-20230804210135158](https://img.pincman.com/media/202308042101884.png)

运行`source ~/.zshrc`加载配置，然后根据自己的喜好来配置`p10k`

如果下次需要重新配置，只要运行`p10k configure`即可

![image-20230804210708714](https://img.pincman.com/media/202308042107161.png)

四、设置插件

- `autojump`可以使用`j xxx`来跳转到历史目录
- `extract`可以用`x`命令一键解压
- `zsh-autosuggestions`用于命令行自动补全
- `zsh-syntax-highlighting`用于命令代码高亮

```bash
apt-get install -y autojump extract
git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
# 国内服务器可以使用镜像：git clone https://gitee.com/mirrors3r/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
# 国内服务器可以使用镜像：git clone https://gitee.com/mirrors3r/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
```

在`.zshrc`中设置插件为`git autojump extract zsh-autosuggestions zsh-syntax-highlighting`

![](https://img.pincman.com/media/202308042131836.png)

## LNMP

### 安装配置

我们选择一种比较简单的方式来按照LNMP(Linux+Nginx+PHP+Mysql)环境 - [oneinstack](https://oneinstack.com/)

> 后续视精力而定，可能会单独加一节Docker中的LNMP以及Redis,Mongodb等环境的集成，对这方面有兴趣的同学可以看一下[这个包](https://github.com/khs1994-docker/lnmp)，我一开始学习docker就是从这个包入门的，他已经更新很多年了，十分适合学习以及直接在生产环境使用

一、添加用户

由于全部用`root`用户操作风险太大，所以我们为服务器添加一个新用户，这个用户用于我们日常使用，包括web服务

:::caution

此命令在服务器上运行

:::

```bash 
useradd pincman 
```

二、修改文件

我们在**本地**下载oneinstack，然后解压编辑里面的内容

:::caution

注意：下面的步骤在本地操作

:::

```bash
wget http://mirrors.linuxeye.com/oneinstack-full.tar.gz
tar xzf oneinstack-full.tar.gz
```

把根目录下的`options.conf`的以下几个字段改成如下

**注意，要把`pincman`替换成你自己在上面服务器中添加的用户名**

```nginx
# Nginx Apache and PHP-FPM process is run as $run_user(Default "www"), you can freely specify
run_user=pincman
# Nginx Apache and PHP-FPM process is run as $run_group(Default "www"), you can freely specify
run_group=pincman
# web directory, you can customize
wwwroot_dir=/home/pincman/htdocs
# nginx Generate a log storage directory, you can freely specify.
wwwlogs_dir=/home/pincman/wwwlogs
# Backup Dest directory, change this if you have someother location
backup_dir=/home/pincman/backup
```

全局替换

- 把所有文件的`www www`替换为`pincman pincman`
- 把所有文件的`/data/wwwlogs`替换为`/home/pincman/wwwlogs`
- 把所有文件的`/data/wwwroot`替换为`/home/pincman/htdocs`
- 为了防止php出现502,把所有文件的`/dev/shm`替换为`/var/run`

![](https://img.pincman.com/media/202308050030851.png)

三、打包上传

压缩我们修改的包

```bash
rm oneinstack-full.tar.gz &&  tar -zcvf  oneinstack.tar.gz ./oneinstack
```

然后下载[FileZilla](https://filezilla-project.org/)上传这个包到`root`根目录下（使用SFTP去连接）

![image-20230805004149680](https://img.pincman.com/media/202308050041579.png)

四、安装

**进入服务器**执行以下命令进行安装

:::caution

注意下面的步骤在服务器上运行

:::

```bash
apt-get -y install screen # 安装screen
tar xvf oneinstack.tar.gz # 解压
cd oneinstack
screen -S oneinstack #如果网路出现中断，可以执行命令`screen -R oneinstack`重新连接安装窗口
./install.sh
```

在输入选项时，我们这样选择

:::note

防火墙你可以按自己的需要确认是否安装

:::

![](https://img.pincman.com/media/202308050125222.png)

这里不要装`node`，我们后续自己装，但是可以装一下`redis`. 另外，不用担心装最新版本的php会导致一些程序不兼容，因为oneinstack可以管理多个版本的php

安装完后按`y`重启

![](https://img.pincman.com/media/202308050131369.png)

### 设置web用户

首先，我们为`root`用户设置一个密码，方便用`su`切换

```bash
passwd root
```

下面我们添加用户

:::tip

用户名请自行更改

:::

```bash
chown -Rf pincman:pincman /home/pincman # 设置用户家目录的拥有者为新增用户
passwd pincman # 为新增用户设置密码
```

设置新用户的shell为`zsh`

```bash
sudo vim /etc/passwd
```

![image-20230807160932518](https://img.pincman.com/media/202308071609516.png)

为新增用户设置`sudo`免密码输入

:::tip

这里保存的时候需要使用`:wq!`，请加上**感叹号**

:::

```bash
sudo vim /etc/sudoers
```

![image-20230804214443820](https://img.pincman.com/media/202308042144840.png)

切换到新用户后选择`2`以创建`.zshrc`文件

:::caution

注意，为了shell也同时切换，请在`su`后加上`-`

:::

```bash
su - pincman
```

![image-20230804214705292](https://img.pincman.com/media/202308042147328.png)

接下来，我们把**ZSH**部分的ohmyzsh之后的内容在新用户下重复一遍

:::note

使用`apt-get`装过的包不需要重新再装了，因为这些包是装到系统里的，而不是`root`用户下专有的

:::

注意：后续我们在使用时要特别关注是在新用户下还是在`root`下操作，以避免权限紊乱

![image-20230804220342524](https://img.pincman.com/media/202308042203820.png)

### 配置PHP

添加web和日志目录，并赋予权限

:::caution

注意下面的命令在`pincman`用户下执行

:::

```bash
sudo chown -Rf pincman:pincman /home/pincman
su - # 切换到 root 用户
```

修改一下php配置

:::caution

注意，真实生产环境下，我们可能需要禁用一些非安全函数和类，以及优化一下phpfpm并发和进程数等，这些已经超出本节课范畴，后续有机会我们将会在PHP课专门学习，本课主要目的是为了方便搭建可以快速使用Linux服务器

:::

```bash
vim /usr/local/php/etc/php.ini
```

- 搜索`disable_functions`并在前面加上`;`注释掉，下面的`disable_classes`一并注释掉
- 搜索`post_max_size`和`upload_max_filesize`，全部改成`2048M`
- 搜索`memory_limit`，改成`2048M`（视你自己的服务器内存而定）
- 搜索`max_input_time`和`max_execution_time`，改成`3000`

保存后重启php-fpm和nginx

```bash
service php-fpm restart && service nginx restart
```

### 搭建网站

我们现在尝试搭建一个wordpress网站

一、创建虚拟主机

首先我们需要购买一个域名，推荐[dnspod](https://www.dnspod.cn/)上买

:::info

如果是国内服务器，购买域名后还需要备案

:::

![](https://img.pincman.com/media/202308051324589.png)

进入域名管理，绑定你的服务器IP。一般我们让泛域名`*`以及顶级域名`@`指向你的服务器IP即可

![](https://img.pincman.com/media/202308051327718.png)

选择用户头像下拉菜单 > 点开"API秘钥" > 选择 "DNDPod Token" > "新建秘钥"

然后把新秘钥的的`ID`和`Token`记录下来，并使用以下格式保存

```nginx
export DP_Id={ID} ; export DP_Key={Token}
```

![](https://img.pincman.com/media/202308051332047.png)

![](https://img.pincman.com/media/202308051334222.png)

进入oneinstack目录，运行以下命令创建一个虚拟主机

```bash
cd oneinstack && ./vhost.sh
```

1. 选择`3`创建SSL证书网站
2. 域名填入顶级域名，比如`pincman.com`
3. 目录选择你要创建的网站目录(目录不存在的话会自动创建)，比如`/home/pincman/htdocs/blog`
4. `Do you want to add more domain name?`选择`y`，用于为这个主机添加别的域名
5. 别的域名这一步，我们填入泛域名，比如`*.pincman.com`，这样的话，所有的二三四等各级子域名都会指向这个虚拟主机，比如`www.pincman.com`(除非我们对某个单独子域名绑定其它的IP,或者另外建个虚拟主机绑定)
6. `Do you want to redirect from *.pincman.com to pincman.com?`这一步选择`y`，这样所有泛域名代表的子域名都会自动调整到顶级域名，比如打开`www.pincman.com`，会自动跳转到`pincman.com`
7. `Do you want to redirect all HTTP requests to HTTPS?`选择`y`，这样做是为了在打开网站默认的`http`(80端口)的时候会自动调整到`https`(SSL证书的443端口)
8. `Please select domain cert key length`默认`2048`即可
9. 申请`let's encrypt`证书的邮箱你自己随意填
10. `Please select DNS provider`这一栏输入`dp`，即DNSPod
11. `Please enter your dnsapi parameters`这一栏输入我们刚才记录的秘钥，就是`export DP_Id={ID} ; export DP_Key={Token}`这个格式填入
12. 按回车后就开始创建虚拟主机了（**创建后的网站的SSL证书是会自动续期的**）

![](https://img.pincman.com/media/202308051348030.png)

后续处理

1. `Do you want to add hotlink protection?`这一栏输入`n`，我们不需要热链接保护
2. `Allow Rewrite rule?`这一栏输入`y`，以添加伪静态
3. `Please input the rewrite of programme`这一栏输入`wordpress`
4. `Allow Nginx/Tengine/OpenResty access_log?`这一栏输入`y`，以添加nginx的访问日志

![image-20230805135420899](https://img.pincman.com/media/202308051354475.png)

二，创建数据库

浏览器打开`http://{你的服务器ip}`点击`phpmyadmin`或者直接打开`http://{你的服务器ip}/phpMyAdmin`

用户名输入`root`，密码就是前面你安装oneinstack时输入的数据库密码

然后点"新建"来创建一个数据库，数据库名称按自己需求命名即可，编码选择`utf8mb4_general_ci`，点创建

![image-20230805135930211](https://img.pincman.com/media/202308051359150.png)

三、安装网站

切换到`pincman`用户，下载wordpress并解压(打开[https://wordpress.org/download/](https://wordpress.org/download/)获取下载地址)，然后重命名为你nginx绑定的虚拟主机目录

```bash
apt install -y zip
chown -Rf pincman:pincman /home/pincman  # 因为前面安装oneinstack后它会自动设置目录权限，所以我们重置一下
su - pincman
cd ~/htdocs && rm -rf blog
wget https://wordpress.org/latest.zip && unzip latest.zip
mv wordpress blog
```

现在打开域名(如[pincman.com](https://pincman.com))开始安装网站

1. 语言选择“简体中文”
2. 点击"现在就开始!"
3. 数据名填入你上一步创建的数据库名称（比如`blog`),用户名`root`,密码就是数据库密码，主机和表前缀不用管
4. 点击"运行安装程序"
5. 站点标题，管理员密码这些按自己需要去填

最后确认信息后会自动进入后台，我们现在打开顶级域名，如`pincman.com`或者随意的域名，如`www.pincman.com`(会自动跳转到顶级域名)都可以访问我们的网站了！

![](https://img.pincman.com/media/202308051429436.png)

四、FTP

:::tip

如果内存足够，可以搭建开发服务器，使用vscode的远程SSH进行文件管理

:::

为了更好的管理网站文件，我们可以创建一个FTP

```bash
su - # 切换到root用户
cd ~/oneinstack
./pureftpd_vhost.sh
```

1. 选择`1`，添加FTP账户
2. 输入用户名，比如`pincman`(这里的用户名是随意的，跟你的系统用户不冲突)
3. 输入密码
4. 输入目录，建议直接选择目录的所有站点根目录，比如`/home/pincman/htdocs`，这样方便集中管理

![](https://img.pincman.com/media/202308051436346.png)

我们尝试通过FileZilla来连接一下

> 现在我们需要选择FTP协议，而不是前面的SFTP协议了

![](https://img.pincman.com/media/202308051438443.png)

![](https://img.pincman.com/media/202308051440600.png)

可以看到已经连接成功了！

四、备份

执行以下命令

```bash
sudo /root/oneinstack/backup_setup.sh
```

1. 可以按自己的需求选择备份方式，我这里选择七牛云
2. 一般我们的代码通过git托管，所以备份数据即可，但是这里为了方便，我们选择`3`，同时备份网站和数据库
3. `Please enter a valid backup number of days`，我们输入`7`，每个备份保留7天
4. 数据库我这里就一个，备份默认的`blog`即可
5. 网站目录我们也只备份`blog`，所以这里输入`blog`
6. 接下来是一些七牛云的配置，你也可以根据自己的云存储厂商输入

![](https://img.pincman.com/media/202308051556809.png)

运行一次备份看一下是否正常工作

```bash
sudo /root/oneinstack/backup.sh
```

可以看到已经备份成功

![](https://img.pincman.com/media/202308051605622.png)

下面我们设置一下自动备份

```
sudo echo '30 21 * * 0 sudo /root/oneinstack/backup.sh > /dev/null 2>&1' >> /var/spool/cron/root
```

这样就代表每周日晚上9:30分备份一次，wordpress网站的搭建自此结束！

## Node

这部分内容可以参考[第一节课](./chapter1)的Linux安装与配置Node的流程，最需要注意地是我们要弄清`root`和`pincman`两种权限的区别

:::caution

注意下面命令在 `pincman` 用户下执行

:::

```bash
# 切换用户
su - pincman
# 下载并解压node
sudo wget https://nodejs.org/dist/v18.16.0/node-v18.16.0-linux-x64.tar.xz -O /usr/local/src/node18.tar.xz
# 如果是国内服务器，可以使用镜像：sudo wget https://img.pincman.com/node-v18.16.0-linux-x64.tar.xz -O /usr/local/src/node18.tar.xz
sudo tar -xf /usr/local/src/node18.tar.xz -C /usr/local/
sudo mv /usr/local/node-v18.16.0-linux-x64 /usr/local/node
# 添加到环境变量
echo "export PATH=/usr/local/node/bin:\$PATH" >> ~/.zshrc && source ~/.zshrc

# 用于防止权限问题
npm config set prefix $HOME/.node_modules
# 用以下方法设置路径，不要去用pnpm setup 
echo "export PNPM_HOME=/home/pincman/.local/share/pnpm" >> ~/.zshrc
echo "export PATH=$HOME/.node_modules/bin:\$HOME/.local/share/pnpm:\$PATH" >> ~/.zshrc
source ~/.zshrc
# 如果是国内服务器，请执行这一步以配置npm淘宝镜像
# npm config set registry https://registry.npmmirror.com/
# 安装与配置pnpm
npm install -g pnpm
# 如果是国内服务器，请执行这一步，这样就可以更好的选择适合自己的依赖仓库镜像了
# pnpm add nnrm -g && nnrm use taobao

# 管理多版本node

# 海外服务器: 使用pnpm管理多个Node版本
pnpm env use --global latest && node --version
pnpm env use --global lts && node --version

# 国内服务器: 使用n.js管理多个Node版本
# pnpm add n -g
# echo "\n" >> ~/.zshrc
# echo "export N_NODE_MIRROR=https://npmmirror.com/mirrors/node" >> ~/.zshrc
# echo "export N_PREFIX=\$HOME/.n" >> ~/.zshrc
# echo "export PATH=\$N_PREFIX/bin:\$PATH" >> ~/.zshrc
# source ~/.zshrc
# 如果发现node版本没切换，请再source ~/.zshrc一下
# n latest && node --version
# n lts_latest && node --version
```

## 开发服务器

有时候在win下写代码，尤其node等应用的时候，会有各种莫名的问题，shell也用起来不是很爽。于是，我们会想着用虚拟机或者wsl2去开发，但是虚拟机占用内存和CPU太大，wsl2经常会有这样那样的网络问题，而且文件系统因为共享会比较卡，无法很好的利用宿主机的CPU和IO。这时，如果我们手头有一台性能比较好的远程服务器，就可以使用这个服务器结合vscode进行远程开发了。另外团队内其他连接这台服务器的成员可以拥有一模一样的开发环境和开发体验，因为源码都是一样的，就免去了本地重新设置一次或者装docker导致硬盘被疯狂占据的囧境。但是，远程开发也有缺点，如果服务器性能不行，比如CPU或者内存太小，又或者带宽太小，都会导致写代码的时候出现大量延迟，这方面就需要自己权衡利弊了

一、自动登录

打开本地的`~/.ssh`目录，复制里面的`id_rsa.pub`文件的内容

然后

```bash
touch ~/.hushlogin && mkdir ~/.ssh && vim ~/.ssh/authorized_keys
```

接着把前面复制的`id_rsa.pub`的内容放入`~/.ssh/authorized_keys`中

关闭命令行窗口重新打开，尝试用`ssh pincman@{服务器IP}`登录看是否能自动登录

如果可以自动登录，那么配置一下本地的`~/.ssh/config`文件，对`pincman`这种用户也设置一个登录别名

![](https://img.pincman.com/media/202308051942639.png)

打开vscode，选择"远程资源管理器" > "dev"，然后点击右侧的"文件夹加号"

![](https://img.pincman.com/media/202308051939798.png)

这时，vscode会自己在服务器上(`pincman`用户下)下载`vscode-server`,下载完之后，我们可以打开需要编码的目录，比如前面的`blog`网站	

![](https://img.pincman.com/media/202308051945206.png)

我们启动一个nestjs项目试试

:::caution

以下操作在服务器上的`pincman`用户下进行

:::

```bash
pnpm add @nestjs/cli -g
mkdir ~/code && $_ && nest new nestapp
```

接下来，我们在vscode中打开该远程目录

然后，按 **ctrl+\` **打开vscode的控制台，输入`pnpm start:dev`

:::caution

不要再服务器上运行start，一定要在vscode中运行，否则vscode无法做端口映射

:::

![](https://img.pincman.com/media/202308052006396.png)

然后在控制台中点击"端口"来添加端口映射

![](https://img.pincman.com/media/202308052008847.png)

现在，我们用浏览器打开[localhost:3000](http://localhost:3000)，可以看到已经和服务器端口映射成功了，然后我们改一下代码可以

注意：在退出vscode前一定要按 **ctrl+c** 退出应用服务后，否则后续再开会引起端口冲突

:::info

端口映射好后，为了可以全屏编码，可以再按**ctrl+\`**关闭控制台并不会影响，只有关闭这个项目的vscode窗口才会退出映射

:::

![](https://img.pincman.com/media/202308052012251.png)

## 监控

使用[bpytop](https://github.com/aristocratos/bpytop)可以很好的监控服务器信息

```bash
# 安装Python
sudo apt install bpytop
# 运行bpytop，如果不是在root用户下，需要加上sudo
sudo bpytop
```

![](https://img.pincman.com/media/202308052301072.png)

自此，服务器配置完成！

## 课后实践

其实PHP有许许多多的开源程序，比如nextcloud可以搭建个人网盘系统，magento或者woocommerce可以搭建电商网站等等

这一节课的实践任务是：尝试搭建一个自用的[nextcloud](https://nextcloud.com/)网盘，可以把你的成果分享到社区哦！